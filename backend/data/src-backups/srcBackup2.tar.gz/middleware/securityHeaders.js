import helmet from 'helmet';
import permissionsPolicy from 'permissions-policy';
export default function setupSecurityHeaders(app) {
    // Initial Helmet Configuration
    app.use(helmet({
        frameguard: { action: 'deny' },
        dnsPrefetchControl: { allow: false },
        hidePoweredBy: true,
        hsts: {
            maxAge: 31536000, // 1 year
            includeSubDomains: true,
            preload: true // enable HSTS preload list
        },
        ieNoOpen: true,
        noSniff: true,
        xssFilter: true
    }));
    // Helmet CSP Configuration
    app.use(helmet.contentSecurityPolicy({
        directives: {
            defaultSrc: ["'self'"],
            scriptSrc: [
                "'self'",
                'https://api.haveibeenpwned.com' // allow external script from this domain
            ],
            styleSrc: [
                "'self'", // allow styles from own domain
                "'unsafe-inline'" // *DEV-NOTE* only keep this if using inline styles
            ],
            fontSrc: ["'self'"],
            imgSrc: ["'self'", 'data:'], // allow images own domain and data URIs
            connectSrc: [
                "'self'",
                'https://api.haveibeenpwned.com',
                'https://cdnjs.cloudflare.com'
            ],
            objectSrc: ["'none'"],
            upgradeInsecureRequests: [], // automatically upgrade HTTP to HTTPS
            frameAncestors: ["'none'"]
        },
        reportOnly: false // set "true" to test CSP without enforcement
    }));
    // Enforce Certificate Transparency
    app.use((req, res, next) => {
        res.setHeader('Expect-CT', 'enforce, max-age=86400');
        next();
    });
    // Configure Permissions Policy
    app.use(permissionsPolicy({
        features: {
            fullscreen: ['self'], // allow fullscreen
            geolocation: ['none'], // disallow geolocation
            microphone: ['none'], // disallow microphone access
            camera: ['none'], // disallow camera access
            payment: ['none'] // disallow payment requests
        }
    }));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VjdXJpdHlIZWFkZXJzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vdHMvbWlkZGxld2FyZS9zZWN1cml0eUhlYWRlcnMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0EsT0FBTyxNQUFNLE1BQU0sUUFBUSxDQUFDO0FBQzVCLE9BQU8saUJBQWlCLE1BQU0sb0JBQW9CLENBQUM7QUFFbkQsTUFBTSxDQUFDLE9BQU8sVUFBVSxvQkFBb0IsQ0FBQyxHQUFnQjtJQUM1RCwrQkFBK0I7SUFDL0IsR0FBRyxDQUFDLEdBQUcsQ0FDTixNQUFNLENBQUM7UUFDTixVQUFVLEVBQUUsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFO1FBQzlCLGtCQUFrQixFQUFFLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRTtRQUNwQyxhQUFhLEVBQUUsSUFBSTtRQUNuQixJQUFJLEVBQUU7WUFDTCxNQUFNLEVBQUUsUUFBUSxFQUFFLFNBQVM7WUFDM0IsaUJBQWlCLEVBQUUsSUFBSTtZQUN2QixPQUFPLEVBQUUsSUFBSSxDQUFDLDJCQUEyQjtTQUN6QztRQUNELFFBQVEsRUFBRSxJQUFJO1FBQ2QsT0FBTyxFQUFFLElBQUk7UUFDYixTQUFTLEVBQUUsSUFBSTtLQUNmLENBQUMsQ0FDRixDQUFDO0lBRUYsMkJBQTJCO0lBQzNCLEdBQUcsQ0FBQyxHQUFHLENBQ04sTUFBTSxDQUFDLHFCQUFxQixDQUFDO1FBQzVCLFVBQVUsRUFBRTtZQUNYLFVBQVUsRUFBRSxDQUFDLFFBQVEsQ0FBQztZQUN0QixTQUFTLEVBQUU7Z0JBQ1YsUUFBUTtnQkFDUixnQ0FBZ0MsQ0FBQyx5Q0FBeUM7YUFDMUU7WUFDRCxRQUFRLEVBQUU7Z0JBQ1QsUUFBUSxFQUFFLCtCQUErQjtnQkFDekMsaUJBQWlCLENBQUMsbURBQW1EO2FBQ3JFO1lBQ0QsT0FBTyxFQUFFLENBQUMsUUFBUSxDQUFDO1lBQ25CLE1BQU0sRUFBRSxDQUFDLFFBQVEsRUFBRSxPQUFPLENBQUMsRUFBRSx3Q0FBd0M7WUFDckUsVUFBVSxFQUFFO2dCQUNYLFFBQVE7Z0JBQ1IsZ0NBQWdDO2dCQUNoQyw4QkFBOEI7YUFDOUI7WUFDRCxTQUFTLEVBQUUsQ0FBQyxRQUFRLENBQUM7WUFDckIsdUJBQXVCLEVBQUUsRUFBRSxFQUFFLHNDQUFzQztZQUNuRSxjQUFjLEVBQUUsQ0FBQyxRQUFRLENBQUM7U0FDMUI7UUFDRCxVQUFVLEVBQUUsS0FBSyxDQUFDLDZDQUE2QztLQUMvRCxDQUFDLENBQ0YsQ0FBQztJQUVGLG1DQUFtQztJQUNuQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBWSxFQUFFLEdBQWEsRUFBRSxJQUFrQixFQUFFLEVBQUU7UUFDM0QsR0FBRyxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsd0JBQXdCLENBQUMsQ0FBQztRQUNyRCxJQUFJLEVBQUUsQ0FBQztJQUNSLENBQUMsQ0FBQyxDQUFDO0lBRUgsK0JBQStCO0lBQy9CLEdBQUcsQ0FBQyxHQUFHLENBQ04saUJBQWlCLENBQUM7UUFDakIsUUFBUSxFQUFFO1lBQ1QsVUFBVSxFQUFFLENBQUMsTUFBTSxDQUFDLEVBQUUsbUJBQW1CO1lBQ3pDLFdBQVcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxFQUFFLHVCQUF1QjtZQUM5QyxVQUFVLEVBQUUsQ0FBQyxNQUFNLENBQUMsRUFBRSw2QkFBNkI7WUFDbkQsTUFBTSxFQUFFLENBQUMsTUFBTSxDQUFDLEVBQUUseUJBQXlCO1lBQzNDLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLDRCQUE0QjtTQUM5QztLQUNELENBQUMsQ0FDRixDQUFDO0FBQ0gsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFwcGxpY2F0aW9uLCBOZXh0RnVuY3Rpb24sIFJlcXVlc3QsIFJlc3BvbnNlIH0gZnJvbSAnZXhwcmVzcyc7XG5pbXBvcnQgaGVsbWV0IGZyb20gJ2hlbG1ldCc7XG5pbXBvcnQgcGVybWlzc2lvbnNQb2xpY3kgZnJvbSAncGVybWlzc2lvbnMtcG9saWN5JztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gc2V0dXBTZWN1cml0eUhlYWRlcnMoYXBwOiBBcHBsaWNhdGlvbikge1xuXHQvLyBJbml0aWFsIEhlbG1ldCBDb25maWd1cmF0aW9uXG5cdGFwcC51c2UoXG5cdFx0aGVsbWV0KHtcblx0XHRcdGZyYW1lZ3VhcmQ6IHsgYWN0aW9uOiAnZGVueScgfSxcblx0XHRcdGRuc1ByZWZldGNoQ29udHJvbDogeyBhbGxvdzogZmFsc2UgfSxcblx0XHRcdGhpZGVQb3dlcmVkQnk6IHRydWUsXG5cdFx0XHRoc3RzOiB7XG5cdFx0XHRcdG1heEFnZTogMzE1MzYwMDAsIC8vIDEgeWVhclxuXHRcdFx0XHRpbmNsdWRlU3ViRG9tYWluczogdHJ1ZSxcblx0XHRcdFx0cHJlbG9hZDogdHJ1ZSAvLyBlbmFibGUgSFNUUyBwcmVsb2FkIGxpc3Rcblx0XHRcdH0sXG5cdFx0XHRpZU5vT3BlbjogdHJ1ZSxcblx0XHRcdG5vU25pZmY6IHRydWUsXG5cdFx0XHR4c3NGaWx0ZXI6IHRydWVcblx0XHR9KVxuXHQpO1xuXG5cdC8vIEhlbG1ldCBDU1AgQ29uZmlndXJhdGlvblxuXHRhcHAudXNlKFxuXHRcdGhlbG1ldC5jb250ZW50U2VjdXJpdHlQb2xpY3koe1xuXHRcdFx0ZGlyZWN0aXZlczoge1xuXHRcdFx0XHRkZWZhdWx0U3JjOiBbXCInc2VsZidcIl0sXG5cdFx0XHRcdHNjcmlwdFNyYzogW1xuXHRcdFx0XHRcdFwiJ3NlbGYnXCIsXG5cdFx0XHRcdFx0J2h0dHBzOi8vYXBpLmhhdmVpYmVlbnB3bmVkLmNvbScgLy8gYWxsb3cgZXh0ZXJuYWwgc2NyaXB0IGZyb20gdGhpcyBkb21haW5cblx0XHRcdFx0XSxcblx0XHRcdFx0c3R5bGVTcmM6IFtcblx0XHRcdFx0XHRcIidzZWxmJ1wiLCAvLyBhbGxvdyBzdHlsZXMgZnJvbSBvd24gZG9tYWluXG5cdFx0XHRcdFx0XCIndW5zYWZlLWlubGluZSdcIiAvLyAqREVWLU5PVEUqIG9ubHkga2VlcCB0aGlzIGlmIHVzaW5nIGlubGluZSBzdHlsZXNcblx0XHRcdFx0XSxcblx0XHRcdFx0Zm9udFNyYzogW1wiJ3NlbGYnXCJdLFxuXHRcdFx0XHRpbWdTcmM6IFtcIidzZWxmJ1wiLCAnZGF0YTonXSwgLy8gYWxsb3cgaW1hZ2VzIG93biBkb21haW4gYW5kIGRhdGEgVVJJc1xuXHRcdFx0XHRjb25uZWN0U3JjOiBbXG5cdFx0XHRcdFx0XCInc2VsZidcIixcblx0XHRcdFx0XHQnaHR0cHM6Ly9hcGkuaGF2ZWliZWVucHduZWQuY29tJyxcblx0XHRcdFx0XHQnaHR0cHM6Ly9jZG5qcy5jbG91ZGZsYXJlLmNvbSdcblx0XHRcdFx0XSxcblx0XHRcdFx0b2JqZWN0U3JjOiBbXCInbm9uZSdcIl0sXG5cdFx0XHRcdHVwZ3JhZGVJbnNlY3VyZVJlcXVlc3RzOiBbXSwgLy8gYXV0b21hdGljYWxseSB1cGdyYWRlIEhUVFAgdG8gSFRUUFNcblx0XHRcdFx0ZnJhbWVBbmNlc3RvcnM6IFtcIidub25lJ1wiXVxuXHRcdFx0fSxcblx0XHRcdHJlcG9ydE9ubHk6IGZhbHNlIC8vIHNldCBcInRydWVcIiB0byB0ZXN0IENTUCB3aXRob3V0IGVuZm9yY2VtZW50XG5cdFx0fSlcblx0KTtcblxuXHQvLyBFbmZvcmNlIENlcnRpZmljYXRlIFRyYW5zcGFyZW5jeVxuXHRhcHAudXNlKChyZXE6IFJlcXVlc3QsIHJlczogUmVzcG9uc2UsIG5leHQ6IE5leHRGdW5jdGlvbikgPT4ge1xuXHRcdHJlcy5zZXRIZWFkZXIoJ0V4cGVjdC1DVCcsICdlbmZvcmNlLCBtYXgtYWdlPTg2NDAwJyk7XG5cdFx0bmV4dCgpO1xuXHR9KTtcblxuXHQvLyBDb25maWd1cmUgUGVybWlzc2lvbnMgUG9saWN5XG5cdGFwcC51c2UoXG5cdFx0cGVybWlzc2lvbnNQb2xpY3koe1xuXHRcdFx0ZmVhdHVyZXM6IHtcblx0XHRcdFx0ZnVsbHNjcmVlbjogWydzZWxmJ10sIC8vIGFsbG93IGZ1bGxzY3JlZW5cblx0XHRcdFx0Z2VvbG9jYXRpb246IFsnbm9uZSddLCAvLyBkaXNhbGxvdyBnZW9sb2NhdGlvblxuXHRcdFx0XHRtaWNyb3Bob25lOiBbJ25vbmUnXSwgLy8gZGlzYWxsb3cgbWljcm9waG9uZSBhY2Nlc3Ncblx0XHRcdFx0Y2FtZXJhOiBbJ25vbmUnXSwgLy8gZGlzYWxsb3cgY2FtZXJhIGFjY2Vzc1xuXHRcdFx0XHRwYXltZW50OiBbJ25vbmUnXSAvLyBkaXNhbGxvdyBwYXltZW50IHJlcXVlc3RzXG5cdFx0XHR9XG5cdFx0fSlcblx0KTtcbn1cbiJdfQ==