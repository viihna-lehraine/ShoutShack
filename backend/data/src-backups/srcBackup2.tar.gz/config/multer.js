import multer from 'multer';
import path from 'path';
// Define the storage location and filename
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, path.join(__dirname, '../../uploads')); // save files to 'uploads' directory
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
        cb(null, `${uniqueSuffix}-${file.originalname}`);
    }
});
// File filter definition with type declarations
const fileFilter = (req, file, cb) => {
    const allowedMimeTypes = [
        'application/json',
        'application/x-x509-ca-cert',
        'application/pgp-keys',
        'application/pgp-signature',
        'application/xml',
        'application/x-gpg-key',
        'application/x-pkcs7-certificates',
        'audio/mp4',
        'audio/mpeg',
        'audio/ogg',
        'audio/wav',
        'audio/webm',
        'image/bmp',
        'image/jpeg',
        'image/jpg',
        'image/gif',
        'image/png',
        'image/svg+xml',
        'image/tiff',
        'image/webp',
        'text/html',
        'text/css',
        'text/csv',
        'text/markdown',
        'text/plain',
        'video/mp4',
        'video/mpeg',
        'video/quicktime',
        'video/x-msvideo'
    ];
    const allowedExtensions = [
        '.avi',
        '.json',
        '.gpg',
        '.asc',
        '.xml',
        '.mp4',
        '.mp3',
        '.ogg',
        '.wav',
        '.webm',
        '.bmp',
        '.jpeg',
        '.jpg',
        '.gif',
        '.png',
        '.svg',
        '.tiff',
        '.webp',
        '.html',
        '.css',
        '.csv',
        '.md',
        '.txt',
        '.mpeg',
        '.mov',
        '.crt'
    ];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowedMimeTypes.includes(file.mimetype) &&
        allowedExtensions.includes(ext)) {
        cb(null, true);
    }
    else {
        cb(null, false);
    }
};
// Set limits for the uploaded filesconst multerLimits = {
const multerLimits = {
    fileSize: 1024 * 1024 * 5
}; // Limit files to 5MB
// Create the multer instance with the storage, fileFilter, and limits
const multerConfiguredUpload = multer({
    storage: storage,
    fileFilter: fileFilter,
    limits: multerLimits
});
export default multerConfiguredUpload;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibXVsdGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vdHMvY29uZmlnL211bHRlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQSxPQUFPLE1BQThCLE1BQU0sUUFBUSxDQUFDO0FBQ3BELE9BQU8sSUFBSSxNQUFNLE1BQU0sQ0FBQztBQUV4QiwyQ0FBMkM7QUFDM0MsTUFBTSxPQUFPLEdBQUcsTUFBTSxDQUFDLFdBQVcsQ0FBQztJQUNsQyxXQUFXLEVBQUUsQ0FBQyxHQUFHLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxFQUFFO1FBQzlCLEVBQUUsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLG9DQUFvQztJQUN0RixDQUFDO0lBQ0QsUUFBUSxFQUFFLENBQUMsR0FBRyxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsRUFBRTtRQUMzQixNQUFNLFlBQVksR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsRUFBRSxDQUFDO1FBQ3hFLEVBQUUsQ0FBQyxJQUFJLEVBQUUsR0FBRyxZQUFZLElBQUksSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDLENBQUM7SUFDbEQsQ0FBQztDQUNELENBQUMsQ0FBQztBQUVILGdEQUFnRDtBQUNoRCxNQUFNLFVBQVUsR0FBRyxDQUNsQixHQUFZLEVBQ1osSUFBeUIsRUFDekIsRUFBc0IsRUFDckIsRUFBRTtJQUNILE1BQU0sZ0JBQWdCLEdBQUc7UUFDeEIsa0JBQWtCO1FBQ2xCLDRCQUE0QjtRQUM1QixzQkFBc0I7UUFDdEIsMkJBQTJCO1FBQzNCLGlCQUFpQjtRQUNqQix1QkFBdUI7UUFDdkIsa0NBQWtDO1FBQ2xDLFdBQVc7UUFDWCxZQUFZO1FBQ1osV0FBVztRQUNYLFdBQVc7UUFDWCxZQUFZO1FBQ1osV0FBVztRQUNYLFlBQVk7UUFDWixXQUFXO1FBQ1gsV0FBVztRQUNYLFdBQVc7UUFDWCxlQUFlO1FBQ2YsWUFBWTtRQUNaLFlBQVk7UUFDWixXQUFXO1FBQ1gsVUFBVTtRQUNWLFVBQVU7UUFDVixlQUFlO1FBQ2YsWUFBWTtRQUNaLFdBQVc7UUFDWCxZQUFZO1FBQ1osaUJBQWlCO1FBQ2pCLGlCQUFpQjtLQUNqQixDQUFDO0lBRUYsTUFBTSxpQkFBaUIsR0FBRztRQUN6QixNQUFNO1FBQ04sT0FBTztRQUNQLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixPQUFPO1FBQ1AsTUFBTTtRQUNOLE9BQU87UUFDUCxNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sT0FBTztRQUNQLE9BQU87UUFDUCxPQUFPO1FBQ1AsTUFBTTtRQUNOLE1BQU07UUFDTixLQUFLO1FBQ0wsTUFBTTtRQUNOLE9BQU87UUFDUCxNQUFNO1FBQ04sTUFBTTtLQUNOLENBQUM7SUFFRixNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUMxRCxJQUNDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO1FBQ3hDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFDOUIsQ0FBQztRQUNGLEVBQUUsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDaEIsQ0FBQztTQUFNLENBQUM7UUFDUCxFQUFFLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ2pCLENBQUM7QUFDRixDQUFDLENBQUM7QUFFRiwwREFBMEQ7QUFDMUQsTUFBTSxZQUFZLEdBQUc7SUFDcEIsUUFBUSxFQUFFLElBQUksR0FBRyxJQUFJLEdBQUcsQ0FBQztDQUN6QixDQUFDLENBQUMscUJBQXFCO0FBRXhCLHNFQUFzRTtBQUN0RSxNQUFNLHNCQUFzQixHQUFHLE1BQU0sQ0FBQztJQUNyQyxPQUFPLEVBQUUsT0FBTztJQUNoQixVQUFVLEVBQUUsVUFBVTtJQUN0QixNQUFNLEVBQUUsWUFBWTtDQUNwQixDQUFDLENBQUM7QUFFSCxlQUFlLHNCQUFzQixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUmVxdWVzdCB9IGZyb20gJ2V4cHJlc3MnO1xuaW1wb3J0IG11bHRlciwgeyBGaWxlRmlsdGVyQ2FsbGJhY2sgfSBmcm9tICdtdWx0ZXInO1xuaW1wb3J0IHBhdGggZnJvbSAncGF0aCc7XG5cbi8vIERlZmluZSB0aGUgc3RvcmFnZSBsb2NhdGlvbiBhbmQgZmlsZW5hbWVcbmNvbnN0IHN0b3JhZ2UgPSBtdWx0ZXIuZGlza1N0b3JhZ2Uoe1xuXHRkZXN0aW5hdGlvbjogKHJlcSwgZmlsZSwgY2IpID0+IHtcblx0XHRjYihudWxsLCBwYXRoLmpvaW4oX19kaXJuYW1lLCAnLi4vLi4vdXBsb2FkcycpKTsgLy8gc2F2ZSBmaWxlcyB0byAndXBsb2FkcycgZGlyZWN0b3J5XG5cdH0sXG5cdGZpbGVuYW1lOiAocmVxLCBmaWxlLCBjYikgPT4ge1xuXHRcdGNvbnN0IHVuaXF1ZVN1ZmZpeCA9IGAke0RhdGUubm93KCl9LSR7TWF0aC5yb3VuZChNYXRoLnJhbmRvbSgpICogMWU5KX1gO1xuXHRcdGNiKG51bGwsIGAke3VuaXF1ZVN1ZmZpeH0tJHtmaWxlLm9yaWdpbmFsbmFtZX1gKTtcblx0fVxufSk7XG5cbi8vIEZpbGUgZmlsdGVyIGRlZmluaXRpb24gd2l0aCB0eXBlIGRlY2xhcmF0aW9uc1xuY29uc3QgZmlsZUZpbHRlciA9IChcblx0cmVxOiBSZXF1ZXN0LFxuXHRmaWxlOiBFeHByZXNzLk11bHRlci5GaWxlLFxuXHRjYjogRmlsZUZpbHRlckNhbGxiYWNrXG4pID0+IHtcblx0Y29uc3QgYWxsb3dlZE1pbWVUeXBlcyA9IFtcblx0XHQnYXBwbGljYXRpb24vanNvbicsXG5cdFx0J2FwcGxpY2F0aW9uL3gteDUwOS1jYS1jZXJ0Jyxcblx0XHQnYXBwbGljYXRpb24vcGdwLWtleXMnLFxuXHRcdCdhcHBsaWNhdGlvbi9wZ3Atc2lnbmF0dXJlJyxcblx0XHQnYXBwbGljYXRpb24veG1sJyxcblx0XHQnYXBwbGljYXRpb24veC1ncGcta2V5Jyxcblx0XHQnYXBwbGljYXRpb24veC1wa2NzNy1jZXJ0aWZpY2F0ZXMnLFxuXHRcdCdhdWRpby9tcDQnLFxuXHRcdCdhdWRpby9tcGVnJyxcblx0XHQnYXVkaW8vb2dnJyxcblx0XHQnYXVkaW8vd2F2Jyxcblx0XHQnYXVkaW8vd2VibScsXG5cdFx0J2ltYWdlL2JtcCcsXG5cdFx0J2ltYWdlL2pwZWcnLFxuXHRcdCdpbWFnZS9qcGcnLFxuXHRcdCdpbWFnZS9naWYnLFxuXHRcdCdpbWFnZS9wbmcnLFxuXHRcdCdpbWFnZS9zdmcreG1sJyxcblx0XHQnaW1hZ2UvdGlmZicsXG5cdFx0J2ltYWdlL3dlYnAnLFxuXHRcdCd0ZXh0L2h0bWwnLFxuXHRcdCd0ZXh0L2NzcycsXG5cdFx0J3RleHQvY3N2Jyxcblx0XHQndGV4dC9tYXJrZG93bicsXG5cdFx0J3RleHQvcGxhaW4nLFxuXHRcdCd2aWRlby9tcDQnLFxuXHRcdCd2aWRlby9tcGVnJyxcblx0XHQndmlkZW8vcXVpY2t0aW1lJyxcblx0XHQndmlkZW8veC1tc3ZpZGVvJ1xuXHRdO1xuXG5cdGNvbnN0IGFsbG93ZWRFeHRlbnNpb25zID0gW1xuXHRcdCcuYXZpJyxcblx0XHQnLmpzb24nLFxuXHRcdCcuZ3BnJyxcblx0XHQnLmFzYycsXG5cdFx0Jy54bWwnLFxuXHRcdCcubXA0Jyxcblx0XHQnLm1wMycsXG5cdFx0Jy5vZ2cnLFxuXHRcdCcud2F2Jyxcblx0XHQnLndlYm0nLFxuXHRcdCcuYm1wJyxcblx0XHQnLmpwZWcnLFxuXHRcdCcuanBnJyxcblx0XHQnLmdpZicsXG5cdFx0Jy5wbmcnLFxuXHRcdCcuc3ZnJyxcblx0XHQnLnRpZmYnLFxuXHRcdCcud2VicCcsXG5cdFx0Jy5odG1sJyxcblx0XHQnLmNzcycsXG5cdFx0Jy5jc3YnLFxuXHRcdCcubWQnLFxuXHRcdCcudHh0Jyxcblx0XHQnLm1wZWcnLFxuXHRcdCcubW92Jyxcblx0XHQnLmNydCdcblx0XTtcblxuXHRjb25zdCBleHQgPSBwYXRoLmV4dG5hbWUoZmlsZS5vcmlnaW5hbG5hbWUpLnRvTG93ZXJDYXNlKCk7XG5cdGlmIChcblx0XHRhbGxvd2VkTWltZVR5cGVzLmluY2x1ZGVzKGZpbGUubWltZXR5cGUpICYmXG5cdFx0YWxsb3dlZEV4dGVuc2lvbnMuaW5jbHVkZXMoZXh0KVxuXHQpIHtcblx0XHRjYihudWxsLCB0cnVlKTtcblx0fSBlbHNlIHtcblx0XHRjYihudWxsLCBmYWxzZSk7XG5cdH1cbn07XG5cbi8vIFNldCBsaW1pdHMgZm9yIHRoZSB1cGxvYWRlZCBmaWxlc2NvbnN0IG11bHRlckxpbWl0cyA9IHtcbmNvbnN0IG11bHRlckxpbWl0cyA9IHtcblx0ZmlsZVNpemU6IDEwMjQgKiAxMDI0ICogNVxufTsgLy8gTGltaXQgZmlsZXMgdG8gNU1CXG5cbi8vIENyZWF0ZSB0aGUgbXVsdGVyIGluc3RhbmNlIHdpdGggdGhlIHN0b3JhZ2UsIGZpbGVGaWx0ZXIsIGFuZCBsaW1pdHNcbmNvbnN0IG11bHRlckNvbmZpZ3VyZWRVcGxvYWQgPSBtdWx0ZXIoe1xuXHRzdG9yYWdlOiBzdG9yYWdlLFxuXHRmaWxlRmlsdGVyOiBmaWxlRmlsdGVyLFxuXHRsaW1pdHM6IG11bHRlckxpbWl0c1xufSk7XG5cbmV4cG9ydCBkZWZhdWx0IG11bHRlckNvbmZpZ3VyZWRVcGxvYWQ7XG4iXX0=