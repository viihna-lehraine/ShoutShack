import { __awaiter } from "tslib";
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import getSecrets from '../../config/secrets.js';
let secrets;
function getSecretsOrThrow() {
    return __awaiter(this, void 0, void 0, function* () {
        if (!secrets) {
            secrets = yield getSecrets();
            if (!secrets) {
                throw new Error('Secrets could not be loaded');
            }
        }
        return secrets;
    });
}
function generateEmail2FACode() {
    return __awaiter(this, void 0, void 0, function* () {
        const secrets = yield getSecretsOrThrow();
        const email2FACode = yield bcrypt.genSalt(6); // generates a 6-character hex code
        const email2FAToken = jwt.sign({ email2FACode }, secrets.EMAIL_2FA_KEY, {
            expiresIn: '30m'
        });
        return {
            email2FACode, // raw 2FA code
            email2FAToken // JWT containing the 2FA code
        };
    });
}
function verifyEmail2FACode(token, email2FACode) {
    return __awaiter(this, void 0, void 0, function* () {
        const secrets = yield getSecretsOrThrow();
        try {
            const decodedEmail2FACode = jwt.verify(token, secrets.EMAIL_2FA_KEY);
            // ensue the decoded 2FA code matches the one provided
            return decodedEmail2FACode.code === email2FACode;
        }
        catch (err) {
            console.error(err);
            return false;
        }
    });
}
export { generateEmail2FACode, verifyEmail2FACode };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZW1haWwyRkFVdGlsLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vdHMvdXRpbHMvYXV0aC9lbWFpbDJGQVV0aWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sTUFBTSxNQUFNLFFBQVEsQ0FBQztBQUM1QixPQUFPLEdBQW1CLE1BQU0sY0FBYyxDQUFDO0FBQy9DLE9BQU8sVUFBVSxNQUFNLHlCQUF5QixDQUFDO0FBTWpELElBQUksT0FBNEIsQ0FBQztBQUVqQyxTQUFlLGlCQUFpQjs7UUFDL0IsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ2QsT0FBTyxHQUFHLE1BQU0sVUFBVSxFQUFFLENBQUM7WUFDN0IsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO2dCQUNkLE1BQU0sSUFBSSxLQUFLLENBQUMsNkJBQTZCLENBQUMsQ0FBQztZQUNoRCxDQUFDO1FBQ0YsQ0FBQztRQUVELE9BQU8sT0FBTyxDQUFDO0lBQ2hCLENBQUM7Q0FBQTtBQUVELFNBQWUsb0JBQW9COztRQUNsQyxNQUFNLE9BQU8sR0FBRyxNQUFNLGlCQUFpQixFQUFFLENBQUM7UUFFMUMsTUFBTSxZQUFZLEdBQUcsTUFBTSxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsbUNBQW1DO1FBQ2pGLE1BQU0sYUFBYSxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxZQUFZLEVBQUUsRUFBRSxPQUFPLENBQUMsYUFBYSxFQUFFO1lBQ3ZFLFNBQVMsRUFBRSxLQUFLO1NBQ2hCLENBQUMsQ0FBQztRQUNILE9BQU87WUFDTixZQUFZLEVBQUUsZUFBZTtZQUM3QixhQUFhLENBQUMsOEJBQThCO1NBQzVDLENBQUM7SUFDSCxDQUFDO0NBQUE7QUFFRCxTQUFlLGtCQUFrQixDQUFDLEtBQWEsRUFBRSxZQUFvQjs7UUFDcEUsTUFBTSxPQUFPLEdBQUcsTUFBTSxpQkFBaUIsRUFBRSxDQUFDO1FBRTFDLElBQUksQ0FBQztZQUNKLE1BQU0sbUJBQW1CLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FDckMsS0FBSyxFQUNMLE9BQU8sQ0FBQyxhQUFhLENBQ1AsQ0FBQztZQUVoQixzREFBc0Q7WUFDdEQsT0FBTyxtQkFBbUIsQ0FBQyxJQUFJLEtBQUssWUFBWSxDQUFDO1FBQ2xELENBQUM7UUFBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO1lBQ2QsT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNuQixPQUFPLEtBQUssQ0FBQztRQUNkLENBQUM7SUFDRixDQUFDO0NBQUE7QUFFRCxPQUFPLEVBQUUsb0JBQW9CLEVBQUUsa0JBQWtCLEVBQUUsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBiY3J5cHQgZnJvbSAnYmNyeXB0JztcbmltcG9ydCBqd3QsIHsgSnd0UGF5bG9hZCB9IGZyb20gJ2pzb253ZWJ0b2tlbic7XG5pbXBvcnQgZ2V0U2VjcmV0cyBmcm9tICcuLi8uLi9jb25maWcvc2VjcmV0cy5qcyc7XG5cbmludGVyZmFjZSBTZWNyZXRzIHtcblx0RU1BSUxfMkZBX0tFWTogc3RyaW5nO1xufVxuXG5sZXQgc2VjcmV0czogU2VjcmV0cyB8IHVuZGVmaW5lZDtcblxuYXN5bmMgZnVuY3Rpb24gZ2V0U2VjcmV0c09yVGhyb3coKTogUHJvbWlzZTxTZWNyZXRzPiB7XG5cdGlmICghc2VjcmV0cykge1xuXHRcdHNlY3JldHMgPSBhd2FpdCBnZXRTZWNyZXRzKCk7XG5cdFx0aWYgKCFzZWNyZXRzKSB7XG5cdFx0XHR0aHJvdyBuZXcgRXJyb3IoJ1NlY3JldHMgY291bGQgbm90IGJlIGxvYWRlZCcpO1xuXHRcdH1cblx0fVxuXG5cdHJldHVybiBzZWNyZXRzO1xufVxuXG5hc3luYyBmdW5jdGlvbiBnZW5lcmF0ZUVtYWlsMkZBQ29kZSgpIHtcblx0Y29uc3Qgc2VjcmV0cyA9IGF3YWl0IGdldFNlY3JldHNPclRocm93KCk7XG5cblx0Y29uc3QgZW1haWwyRkFDb2RlID0gYXdhaXQgYmNyeXB0LmdlblNhbHQoNik7IC8vIGdlbmVyYXRlcyBhIDYtY2hhcmFjdGVyIGhleCBjb2RlXG5cdGNvbnN0IGVtYWlsMkZBVG9rZW4gPSBqd3Quc2lnbih7IGVtYWlsMkZBQ29kZSB9LCBzZWNyZXRzLkVNQUlMXzJGQV9LRVksIHtcblx0XHRleHBpcmVzSW46ICczMG0nXG5cdH0pO1xuXHRyZXR1cm4ge1xuXHRcdGVtYWlsMkZBQ29kZSwgLy8gcmF3IDJGQSBjb2RlXG5cdFx0ZW1haWwyRkFUb2tlbiAvLyBKV1QgY29udGFpbmluZyB0aGUgMkZBIGNvZGVcblx0fTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gdmVyaWZ5RW1haWwyRkFDb2RlKHRva2VuOiBzdHJpbmcsIGVtYWlsMkZBQ29kZTogc3RyaW5nKSB7XG5cdGNvbnN0IHNlY3JldHMgPSBhd2FpdCBnZXRTZWNyZXRzT3JUaHJvdygpO1xuXG5cdHRyeSB7XG5cdFx0Y29uc3QgZGVjb2RlZEVtYWlsMkZBQ29kZSA9IGp3dC52ZXJpZnkoXG5cdFx0XHR0b2tlbixcblx0XHRcdHNlY3JldHMuRU1BSUxfMkZBX0tFWVxuXHRcdCkgYXMgSnd0UGF5bG9hZDtcblxuXHRcdC8vIGVuc3VlIHRoZSBkZWNvZGVkIDJGQSBjb2RlIG1hdGNoZXMgdGhlIG9uZSBwcm92aWRlZFxuXHRcdHJldHVybiBkZWNvZGVkRW1haWwyRkFDb2RlLmNvZGUgPT09IGVtYWlsMkZBQ29kZTtcblx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0Y29uc29sZS5lcnJvcihlcnIpO1xuXHRcdHJldHVybiBmYWxzZTtcblx0fVxufVxuXG5leHBvcnQgeyBnZW5lcmF0ZUVtYWlsMkZBQ29kZSwgdmVyaWZ5RW1haWwyRkFDb2RlIH07XG4iXX0=