import { createClient } from 'redis';
import setupLogger from './logger.mjs';
import { getFeatureFlags } from './featureFlags.mjs';
const logger = setupLogger();
const REDIS_FLAG = getFeatureFlags().enableRedisFlag;
let redisClient = null;
export async function connectRedis() {
    if (!REDIS_FLAG || REDIS_FLAG !== true) {
        logger.info('Redis is disabled based on REDIS_FLAG');
        return null; // return null if REDIS_FLAG is false
    }
    try {
        const client = createClient({
            url: 'redis://localhost:6379',
            socket: {
                reconnectStrategy: retries => {
                    logger.warn(`Redis retry attempt: ${retries}`);
                    if (retries >= 10) {
                        logger.error('Max retries reached. Could not connect to Redis.');
                        return new Error('Max retries reached');
                    }
                    return Math.min(retries * 100, 3000); // reconnect after increasing intervals up to 3 seconds
                }
            }
        });
        client.on('error', err => {
            logger.error('Redis client error:', err);
        });
        await client.connect();
        logger.info('Connected to Redis');
        redisClient = client;
        return client;
    }
    catch (err) {
        logger.error('Failed to connect to Redis:', err);
        return null; // Ensure no further Redis operations are attempted
    }
}
export function getRedisClient() {
    return redisClient;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVkaXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvY29uZmlnL3JlZGlzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxZQUFZLEVBQW1CLE1BQU0sT0FBTyxDQUFDO0FBQ3RELE9BQU8sV0FBVyxNQUFNLFVBQVUsQ0FBQztBQUNuQyxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFFakQsTUFBTSxNQUFNLEdBQUcsV0FBVyxFQUFFLENBQUM7QUFDN0IsTUFBTSxVQUFVLEdBQUcsZUFBZSxFQUFFLENBQUMsZUFBZSxDQUFDO0FBRXJELElBQUksV0FBVyxHQUEyQixJQUFJLENBQUM7QUFFL0MsTUFBTSxDQUFDLEtBQUssVUFBVSxZQUFZO0lBQ2pDLElBQUksQ0FBQyxVQUFVLElBQUksVUFBVSxLQUFLLElBQUksRUFBRSxDQUFDO1FBQ3hDLE1BQU0sQ0FBQyxJQUFJLENBQUMsdUNBQXVDLENBQUMsQ0FBQztRQUNyRCxPQUFPLElBQUksQ0FBQyxDQUFDLHFDQUFxQztJQUNuRCxDQUFDO0lBRUQsSUFBSSxDQUFDO1FBQ0osTUFBTSxNQUFNLEdBQW9CLFlBQVksQ0FBQztZQUM1QyxHQUFHLEVBQUUsd0JBQXdCO1lBQzdCLE1BQU0sRUFBRTtnQkFDUCxpQkFBaUIsRUFBRSxPQUFPLENBQUMsRUFBRTtvQkFDNUIsTUFBTSxDQUFDLElBQUksQ0FBQyx3QkFBd0IsT0FBTyxFQUFFLENBQUMsQ0FBQztvQkFDL0MsSUFBSSxPQUFPLElBQUksRUFBRSxFQUFFLENBQUM7d0JBQ25CLE1BQU0sQ0FBQyxLQUFLLENBQ1gsa0RBQWtELENBQ2xELENBQUM7d0JBQ0YsT0FBTyxJQUFJLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO29CQUN6QyxDQUFDO29CQUNELE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLEdBQUcsR0FBRyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsdURBQXVEO2dCQUM5RixDQUFDO2FBQ0Q7U0FDRCxDQUFDLENBQUM7UUFFSCxNQUFNLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsRUFBRTtZQUN4QixNQUFNLENBQUMsS0FBSyxDQUFDLHFCQUFxQixFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQzFDLENBQUMsQ0FBQyxDQUFDO1FBRUgsTUFBTSxNQUFNLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDdkIsTUFBTSxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1FBRWxDLFdBQVcsR0FBRyxNQUFNLENBQUM7UUFDckIsT0FBTyxNQUFNLENBQUM7SUFDZixDQUFDO0lBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztRQUNkLE1BQU0sQ0FBQyxLQUFLLENBQUMsNkJBQTZCLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDakQsT0FBTyxJQUFJLENBQUMsQ0FBQyxtREFBbUQ7SUFDakUsQ0FBQztBQUNGLENBQUM7QUFFRCxNQUFNLFVBQVUsY0FBYztJQUM3QixPQUFPLFdBQVcsQ0FBQztBQUNwQixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlQ2xpZW50LCBSZWRpc0NsaWVudFR5cGUgfSBmcm9tICdyZWRpcyc7XG5pbXBvcnQgc2V0dXBMb2dnZXIgZnJvbSAnLi9sb2dnZXInO1xuaW1wb3J0IHsgZ2V0RmVhdHVyZUZsYWdzIH0gZnJvbSAnLi9mZWF0dXJlRmxhZ3MnO1xuXG5jb25zdCBsb2dnZXIgPSBzZXR1cExvZ2dlcigpO1xuY29uc3QgUkVESVNfRkxBRyA9IGdldEZlYXR1cmVGbGFncygpLmVuYWJsZVJlZGlzRmxhZztcblxubGV0IHJlZGlzQ2xpZW50OiBSZWRpc0NsaWVudFR5cGUgfCBudWxsID0gbnVsbDtcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNvbm5lY3RSZWRpcygpOiBQcm9taXNlPFJlZGlzQ2xpZW50VHlwZSB8IG51bGw+IHtcblx0aWYgKCFSRURJU19GTEFHIHx8IFJFRElTX0ZMQUcgIT09IHRydWUpIHtcblx0XHRsb2dnZXIuaW5mbygnUmVkaXMgaXMgZGlzYWJsZWQgYmFzZWQgb24gUkVESVNfRkxBRycpO1xuXHRcdHJldHVybiBudWxsOyAvLyByZXR1cm4gbnVsbCBpZiBSRURJU19GTEFHIGlzIGZhbHNlXG5cdH1cblxuXHR0cnkge1xuXHRcdGNvbnN0IGNsaWVudDogUmVkaXNDbGllbnRUeXBlID0gY3JlYXRlQ2xpZW50KHtcblx0XHRcdHVybDogJ3JlZGlzOi8vbG9jYWxob3N0OjYzNzknLFxuXHRcdFx0c29ja2V0OiB7XG5cdFx0XHRcdHJlY29ubmVjdFN0cmF0ZWd5OiByZXRyaWVzID0+IHtcblx0XHRcdFx0XHRsb2dnZXIud2FybihgUmVkaXMgcmV0cnkgYXR0ZW1wdDogJHtyZXRyaWVzfWApO1xuXHRcdFx0XHRcdGlmIChyZXRyaWVzID49IDEwKSB7XG5cdFx0XHRcdFx0XHRsb2dnZXIuZXJyb3IoXG5cdFx0XHRcdFx0XHRcdCdNYXggcmV0cmllcyByZWFjaGVkLiBDb3VsZCBub3QgY29ubmVjdCB0byBSZWRpcy4nXG5cdFx0XHRcdFx0XHQpO1xuXHRcdFx0XHRcdFx0cmV0dXJuIG5ldyBFcnJvcignTWF4IHJldHJpZXMgcmVhY2hlZCcpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRyZXR1cm4gTWF0aC5taW4ocmV0cmllcyAqIDEwMCwgMzAwMCk7IC8vIHJlY29ubmVjdCBhZnRlciBpbmNyZWFzaW5nIGludGVydmFscyB1cCB0byAzIHNlY29uZHNcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH0pO1xuXG5cdFx0Y2xpZW50Lm9uKCdlcnJvcicsIGVyciA9PiB7XG5cdFx0XHRsb2dnZXIuZXJyb3IoJ1JlZGlzIGNsaWVudCBlcnJvcjonLCBlcnIpO1xuXHRcdH0pO1xuXG5cdFx0YXdhaXQgY2xpZW50LmNvbm5lY3QoKTtcblx0XHRsb2dnZXIuaW5mbygnQ29ubmVjdGVkIHRvIFJlZGlzJyk7XG5cblx0XHRyZWRpc0NsaWVudCA9IGNsaWVudDtcblx0XHRyZXR1cm4gY2xpZW50O1xuXHR9IGNhdGNoIChlcnIpIHtcblx0XHRsb2dnZXIuZXJyb3IoJ0ZhaWxlZCB0byBjb25uZWN0IHRvIFJlZGlzOicsIGVycik7XG5cdFx0cmV0dXJuIG51bGw7IC8vIEVuc3VyZSBubyBmdXJ0aGVyIFJlZGlzIG9wZXJhdGlvbnMgYXJlIGF0dGVtcHRlZFxuXHR9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRSZWRpc0NsaWVudCgpOiBSZWRpc0NsaWVudFR5cGUgfCBudWxsIHtcblx0cmV0dXJuIHJlZGlzQ2xpZW50O1xufVxuIl19