import helmet from 'helmet';
import permissionsPolicy from 'permissions-policy';
export default function setupSecurityHeaders(app) {
    // Initial Helmet Configuration
    app.use(helmet({
        frameguard: { action: 'deny' },
        dnsPrefetchControl: { allow: false },
        hidePoweredBy: true,
        hsts: {
            maxAge: 31536000, // 1 year
            includeSubDomains: true,
            preload: true // enable HSTS preload list
        },
        ieNoOpen: true,
        noSniff: true,
        xssFilter: true
    }));
    // Helmet CSP Configuration
    app.use(helmet.contentSecurityPolicy({
        directives: {
            defaultSrc: ["'self'"],
            scriptSrc: [
                "'self'",
                'https://api.haveibeenpwned.com' // allow external script from this domain
            ],
            styleSrc: [
                "'self'", // allow styles from own domain
                "'unsafe-inline'" // *DEV-NOTE* only keep this if using inline styles
            ],
            fontSrc: ["'self'"],
            imgSrc: ["'self'", 'data:'], // allow images own domain and data URIs
            connectSrc: [
                "'self'",
                'https://api.haveibeenpwned.com',
                'https://cdnjs.cloudflare.com'
            ],
            objectSrc: ["'none'"],
            upgradeInsecureRequests: [], // automatically upgrade HTTP to HTTPS
            frameAncestors: ["'none'"]
        },
        reportOnly: false // set "true" to test CSP without enforcement
    }));
    // Enforce Certificate Transparency
    app.use((req, res, next) => {
        res.setHeader('Expect-CT', 'enforce, max-age=86400');
        next();
    });
    // Configure Permissions Policy
    app.use(permissionsPolicy({
        features: {
            fullscreen: ['self'], // allow fullscreen
            geolocation: ['none'], // disallow geolocation
            microphone: ['none'], // disallow microphone access
            camera: ['none'], // disallow camera access
            payment: ['none'] // disallow payment requests
        }
    }));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VjdXJpdHlIZWFkZXJzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL21pZGRsZXdhcmUvc2VjdXJpdHlIZWFkZXJzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBLE9BQU8sTUFBTSxNQUFNLFFBQVEsQ0FBQztBQUM1QixPQUFPLGlCQUFpQixNQUFNLG9CQUFvQixDQUFDO0FBRW5ELE1BQU0sQ0FBQyxPQUFPLFVBQVUsb0JBQW9CLENBQUMsR0FBZ0I7SUFDNUQsK0JBQStCO0lBQy9CLEdBQUcsQ0FBQyxHQUFHLENBQ04sTUFBTSxDQUFDO1FBQ04sVUFBVSxFQUFFLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRTtRQUM5QixrQkFBa0IsRUFBRSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUU7UUFDcEMsYUFBYSxFQUFFLElBQUk7UUFDbkIsSUFBSSxFQUFFO1lBQ0wsTUFBTSxFQUFFLFFBQVEsRUFBRSxTQUFTO1lBQzNCLGlCQUFpQixFQUFFLElBQUk7WUFDdkIsT0FBTyxFQUFFLElBQUksQ0FBQywyQkFBMkI7U0FDekM7UUFDRCxRQUFRLEVBQUUsSUFBSTtRQUNkLE9BQU8sRUFBRSxJQUFJO1FBQ2IsU0FBUyxFQUFFLElBQUk7S0FDZixDQUFDLENBQ0YsQ0FBQztJQUVGLDJCQUEyQjtJQUMzQixHQUFHLENBQUMsR0FBRyxDQUNOLE1BQU0sQ0FBQyxxQkFBcUIsQ0FBQztRQUM1QixVQUFVLEVBQUU7WUFDWCxVQUFVLEVBQUUsQ0FBQyxRQUFRLENBQUM7WUFDdEIsU0FBUyxFQUFFO2dCQUNWLFFBQVE7Z0JBQ1IsZ0NBQWdDLENBQUMseUNBQXlDO2FBQzFFO1lBQ0QsUUFBUSxFQUFFO2dCQUNULFFBQVEsRUFBRSwrQkFBK0I7Z0JBQ3pDLGlCQUFpQixDQUFDLG1EQUFtRDthQUNyRTtZQUNELE9BQU8sRUFBRSxDQUFDLFFBQVEsQ0FBQztZQUNuQixNQUFNLEVBQUUsQ0FBQyxRQUFRLEVBQUUsT0FBTyxDQUFDLEVBQUUsd0NBQXdDO1lBQ3JFLFVBQVUsRUFBRTtnQkFDWCxRQUFRO2dCQUNSLGdDQUFnQztnQkFDaEMsOEJBQThCO2FBQzlCO1lBQ0QsU0FBUyxFQUFFLENBQUMsUUFBUSxDQUFDO1lBQ3JCLHVCQUF1QixFQUFFLEVBQUUsRUFBRSxzQ0FBc0M7WUFDbkUsY0FBYyxFQUFFLENBQUMsUUFBUSxDQUFDO1NBQzFCO1FBQ0QsVUFBVSxFQUFFLEtBQUssQ0FBQyw2Q0FBNkM7S0FDL0QsQ0FBQyxDQUNGLENBQUM7SUFFRixtQ0FBbUM7SUFDbkMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQVksRUFBRSxHQUFhLEVBQUUsSUFBa0IsRUFBRSxFQUFFO1FBQzNELEdBQUcsQ0FBQyxTQUFTLENBQUMsV0FBVyxFQUFFLHdCQUF3QixDQUFDLENBQUM7UUFDckQsSUFBSSxFQUFFLENBQUM7SUFDUixDQUFDLENBQUMsQ0FBQztJQUVILCtCQUErQjtJQUMvQixHQUFHLENBQUMsR0FBRyxDQUNOLGlCQUFpQixDQUFDO1FBQ2pCLFFBQVEsRUFBRTtZQUNULFVBQVUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxFQUFFLG1CQUFtQjtZQUN6QyxXQUFXLEVBQUUsQ0FBQyxNQUFNLENBQUMsRUFBRSx1QkFBdUI7WUFDOUMsVUFBVSxFQUFFLENBQUMsTUFBTSxDQUFDLEVBQUUsNkJBQTZCO1lBQ25ELE1BQU0sRUFBRSxDQUFDLE1BQU0sQ0FBQyxFQUFFLHlCQUF5QjtZQUMzQyxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyw0QkFBNEI7U0FDOUM7S0FDRCxDQUFDLENBQ0YsQ0FBQztBQUNILENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBcHBsaWNhdGlvbiwgTmV4dEZ1bmN0aW9uLCBSZXF1ZXN0LCBSZXNwb25zZSB9IGZyb20gJ2V4cHJlc3MnO1xuaW1wb3J0IGhlbG1ldCBmcm9tICdoZWxtZXQnO1xuaW1wb3J0IHBlcm1pc3Npb25zUG9saWN5IGZyb20gJ3Blcm1pc3Npb25zLXBvbGljeSc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIHNldHVwU2VjdXJpdHlIZWFkZXJzKGFwcDogQXBwbGljYXRpb24pOiB2b2lkIHtcblx0Ly8gSW5pdGlhbCBIZWxtZXQgQ29uZmlndXJhdGlvblxuXHRhcHAudXNlKFxuXHRcdGhlbG1ldCh7XG5cdFx0XHRmcmFtZWd1YXJkOiB7IGFjdGlvbjogJ2RlbnknIH0sXG5cdFx0XHRkbnNQcmVmZXRjaENvbnRyb2w6IHsgYWxsb3c6IGZhbHNlIH0sXG5cdFx0XHRoaWRlUG93ZXJlZEJ5OiB0cnVlLFxuXHRcdFx0aHN0czoge1xuXHRcdFx0XHRtYXhBZ2U6IDMxNTM2MDAwLCAvLyAxIHllYXJcblx0XHRcdFx0aW5jbHVkZVN1YkRvbWFpbnM6IHRydWUsXG5cdFx0XHRcdHByZWxvYWQ6IHRydWUgLy8gZW5hYmxlIEhTVFMgcHJlbG9hZCBsaXN0XG5cdFx0XHR9LFxuXHRcdFx0aWVOb09wZW46IHRydWUsXG5cdFx0XHRub1NuaWZmOiB0cnVlLFxuXHRcdFx0eHNzRmlsdGVyOiB0cnVlXG5cdFx0fSlcblx0KTtcblxuXHQvLyBIZWxtZXQgQ1NQIENvbmZpZ3VyYXRpb25cblx0YXBwLnVzZShcblx0XHRoZWxtZXQuY29udGVudFNlY3VyaXR5UG9saWN5KHtcblx0XHRcdGRpcmVjdGl2ZXM6IHtcblx0XHRcdFx0ZGVmYXVsdFNyYzogW1wiJ3NlbGYnXCJdLFxuXHRcdFx0XHRzY3JpcHRTcmM6IFtcblx0XHRcdFx0XHRcIidzZWxmJ1wiLFxuXHRcdFx0XHRcdCdodHRwczovL2FwaS5oYXZlaWJlZW5wd25lZC5jb20nIC8vIGFsbG93IGV4dGVybmFsIHNjcmlwdCBmcm9tIHRoaXMgZG9tYWluXG5cdFx0XHRcdF0sXG5cdFx0XHRcdHN0eWxlU3JjOiBbXG5cdFx0XHRcdFx0XCInc2VsZidcIiwgLy8gYWxsb3cgc3R5bGVzIGZyb20gb3duIGRvbWFpblxuXHRcdFx0XHRcdFwiJ3Vuc2FmZS1pbmxpbmUnXCIgLy8gKkRFVi1OT1RFKiBvbmx5IGtlZXAgdGhpcyBpZiB1c2luZyBpbmxpbmUgc3R5bGVzXG5cdFx0XHRcdF0sXG5cdFx0XHRcdGZvbnRTcmM6IFtcIidzZWxmJ1wiXSxcblx0XHRcdFx0aW1nU3JjOiBbXCInc2VsZidcIiwgJ2RhdGE6J10sIC8vIGFsbG93IGltYWdlcyBvd24gZG9tYWluIGFuZCBkYXRhIFVSSXNcblx0XHRcdFx0Y29ubmVjdFNyYzogW1xuXHRcdFx0XHRcdFwiJ3NlbGYnXCIsXG5cdFx0XHRcdFx0J2h0dHBzOi8vYXBpLmhhdmVpYmVlbnB3bmVkLmNvbScsXG5cdFx0XHRcdFx0J2h0dHBzOi8vY2RuanMuY2xvdWRmbGFyZS5jb20nXG5cdFx0XHRcdF0sXG5cdFx0XHRcdG9iamVjdFNyYzogW1wiJ25vbmUnXCJdLFxuXHRcdFx0XHR1cGdyYWRlSW5zZWN1cmVSZXF1ZXN0czogW10sIC8vIGF1dG9tYXRpY2FsbHkgdXBncmFkZSBIVFRQIHRvIEhUVFBTXG5cdFx0XHRcdGZyYW1lQW5jZXN0b3JzOiBbXCInbm9uZSdcIl1cblx0XHRcdH0sXG5cdFx0XHRyZXBvcnRPbmx5OiBmYWxzZSAvLyBzZXQgXCJ0cnVlXCIgdG8gdGVzdCBDU1Agd2l0aG91dCBlbmZvcmNlbWVudFxuXHRcdH0pXG5cdCk7XG5cblx0Ly8gRW5mb3JjZSBDZXJ0aWZpY2F0ZSBUcmFuc3BhcmVuY3lcblx0YXBwLnVzZSgocmVxOiBSZXF1ZXN0LCByZXM6IFJlc3BvbnNlLCBuZXh0OiBOZXh0RnVuY3Rpb24pID0+IHtcblx0XHRyZXMuc2V0SGVhZGVyKCdFeHBlY3QtQ1QnLCAnZW5mb3JjZSwgbWF4LWFnZT04NjQwMCcpO1xuXHRcdG5leHQoKTtcblx0fSk7XG5cblx0Ly8gQ29uZmlndXJlIFBlcm1pc3Npb25zIFBvbGljeVxuXHRhcHAudXNlKFxuXHRcdHBlcm1pc3Npb25zUG9saWN5KHtcblx0XHRcdGZlYXR1cmVzOiB7XG5cdFx0XHRcdGZ1bGxzY3JlZW46IFsnc2VsZiddLCAvLyBhbGxvdyBmdWxsc2NyZWVuXG5cdFx0XHRcdGdlb2xvY2F0aW9uOiBbJ25vbmUnXSwgLy8gZGlzYWxsb3cgZ2VvbG9jYXRpb25cblx0XHRcdFx0bWljcm9waG9uZTogWydub25lJ10sIC8vIGRpc2FsbG93IG1pY3JvcGhvbmUgYWNjZXNzXG5cdFx0XHRcdGNhbWVyYTogWydub25lJ10sIC8vIGRpc2FsbG93IGNhbWVyYSBhY2Nlc3Ncblx0XHRcdFx0cGF5bWVudDogWydub25lJ10gLy8gZGlzYWxsb3cgcGF5bWVudCByZXF1ZXN0c1xuXHRcdFx0fVxuXHRcdH0pXG5cdCk7XG59XG4iXX0=