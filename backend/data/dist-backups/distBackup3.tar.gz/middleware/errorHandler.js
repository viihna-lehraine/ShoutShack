import AppError from '../errors/AppError.mjs';
import setupLogger from '../config/logger.mjs';
const logger = setupLogger();
function errorHandler(err, req, res, next) {
    if (err instanceof AppError) {
        // operational, trusted error: send message to client
        logger.error(`Operational error occurred: ${err.message}`);
        res.status(err.statusCode).json({
            status: 'error',
            message: err.message
        });
        next();
    }
    else {
        // programming or other unknown error: don't leak error details
        logger.error(`Unexpected error occured: ${err.message}`);
        res.status(500).json({
            status: 'error',
            message: 'Internal server error'
        });
        next();
    }
}
export default errorHandler;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXJyb3JIYW5kbGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL21pZGRsZXdhcmUvZXJyb3JIYW5kbGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBLE9BQU8sUUFBUSxNQUFNLG9CQUFvQixDQUFDO0FBQzFDLE9BQU8sV0FBVyxNQUFNLGtCQUFrQixDQUFDO0FBRTNDLE1BQU0sTUFBTSxHQUFHLFdBQVcsRUFBRSxDQUFDO0FBRTdCLFNBQVMsWUFBWSxDQUNwQixHQUFxQixFQUNyQixHQUFZLEVBQ1osR0FBYSxFQUNiLElBQWtCO0lBRWxCLElBQUksR0FBRyxZQUFZLFFBQVEsRUFBRSxDQUFDO1FBQzdCLHFEQUFxRDtRQUNyRCxNQUFNLENBQUMsS0FBSyxDQUFDLCtCQUErQixHQUFHLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztRQUMzRCxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDL0IsTUFBTSxFQUFFLE9BQU87WUFDZixPQUFPLEVBQUUsR0FBRyxDQUFDLE9BQU87U0FDcEIsQ0FBQyxDQUFDO1FBQ0gsSUFBSSxFQUFFLENBQUM7SUFDUixDQUFDO1NBQU0sQ0FBQztRQUNQLCtEQUErRDtRQUMvRCxNQUFNLENBQUMsS0FBSyxDQUFDLDZCQUE2QixHQUFHLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztRQUN6RCxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNwQixNQUFNLEVBQUUsT0FBTztZQUNmLE9BQU8sRUFBRSx1QkFBdUI7U0FDaEMsQ0FBQyxDQUFDO1FBQ0gsSUFBSSxFQUFFLENBQUM7SUFDUixDQUFDO0FBQ0YsQ0FBQztBQUVELGVBQWUsWUFBWSxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUmVxdWVzdCwgUmVzcG9uc2UsIE5leHRGdW5jdGlvbiB9IGZyb20gJ2V4cHJlc3MnO1xuaW1wb3J0IEFwcEVycm9yIGZyb20gJy4uL2Vycm9ycy9BcHBFcnJvcic7XG5pbXBvcnQgc2V0dXBMb2dnZXIgZnJvbSAnLi4vY29uZmlnL2xvZ2dlcic7XG5cbmNvbnN0IGxvZ2dlciA9IHNldHVwTG9nZ2VyKCk7XG5cbmZ1bmN0aW9uIGVycm9ySGFuZGxlcihcblx0ZXJyOiBBcHBFcnJvciB8IEVycm9yLFxuXHRyZXE6IFJlcXVlc3QsXG5cdHJlczogUmVzcG9uc2UsXG5cdG5leHQ6IE5leHRGdW5jdGlvblxuKTogdm9pZCB7XG5cdGlmIChlcnIgaW5zdGFuY2VvZiBBcHBFcnJvcikge1xuXHRcdC8vIG9wZXJhdGlvbmFsLCB0cnVzdGVkIGVycm9yOiBzZW5kIG1lc3NhZ2UgdG8gY2xpZW50XG5cdFx0bG9nZ2VyLmVycm9yKGBPcGVyYXRpb25hbCBlcnJvciBvY2N1cnJlZDogJHtlcnIubWVzc2FnZX1gKTtcblx0XHRyZXMuc3RhdHVzKGVyci5zdGF0dXNDb2RlKS5qc29uKHtcblx0XHRcdHN0YXR1czogJ2Vycm9yJyxcblx0XHRcdG1lc3NhZ2U6IGVyci5tZXNzYWdlXG5cdFx0fSk7XG5cdFx0bmV4dCgpO1xuXHR9IGVsc2Uge1xuXHRcdC8vIHByb2dyYW1taW5nIG9yIG90aGVyIHVua25vd24gZXJyb3I6IGRvbid0IGxlYWsgZXJyb3IgZGV0YWlsc1xuXHRcdGxvZ2dlci5lcnJvcihgVW5leHBlY3RlZCBlcnJvciBvY2N1cmVkOiAke2Vyci5tZXNzYWdlfWApO1xuXHRcdHJlcy5zdGF0dXMoNTAwKS5qc29uKHtcblx0XHRcdHN0YXR1czogJ2Vycm9yJyxcblx0XHRcdG1lc3NhZ2U6ICdJbnRlcm5hbCBzZXJ2ZXIgZXJyb3InXG5cdFx0fSk7XG5cdFx0bmV4dCgpO1xuXHR9XG59XG5cbmV4cG9ydCBkZWZhdWx0IGVycm9ySGFuZGxlcjtcbiJdfQ==