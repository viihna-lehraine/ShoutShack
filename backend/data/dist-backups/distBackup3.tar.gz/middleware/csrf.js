import csrf from 'csrf';
// Create a new CSRF protection instance
const csrfProtection = new csrf({ secretLength: 32 });
// Middleware to add CSRF token to the response and validate incoming CSRF tokens
export function csrfMiddleware(req, res, next) {
    try {
        // Generate and set a CSRFm token in the response locals
        res.locals.csrfToken = csrfProtection.create(req.sessionID || ''); // Generate CSRF token based on session ID or some unique identifier
        // If the request method is not GET, validate the CSRF token
        if (req.method !== 'GET') {
            const token = req.body.csrfToken || req.headers['x-xsrf-token'];
            if (!token || !csrfProtection.verify(req.sessionID || '', token)) {
                res.status(403).send('Invalid CSRF token');
                return;
            }
        }
        next(); // if validation passes, proceed to the next middleware
    }
    catch (err) {
        next(err); // pass any errors to the error handling middleware
    }
    return;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3NyZi5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9taWRkbGV3YXJlL2NzcmYudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxJQUFJLE1BQU0sTUFBTSxDQUFDO0FBR3hCLHdDQUF3QztBQUN4QyxNQUFNLGNBQWMsR0FBRyxJQUFJLElBQUksQ0FBQyxFQUFFLFlBQVksRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBRXRELGlGQUFpRjtBQUNqRixNQUFNLFVBQVUsY0FBYyxDQUM3QixHQUFZLEVBQ1osR0FBYSxFQUNiLElBQWtCO0lBRWxCLElBQUksQ0FBQztRQUNKLHdEQUF3RDtRQUN4RCxHQUFHLENBQUMsTUFBTSxDQUFDLFNBQVMsR0FBRyxjQUFjLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxTQUFTLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxvRUFBb0U7UUFFdkksNERBQTREO1FBQzVELElBQUksR0FBRyxDQUFDLE1BQU0sS0FBSyxLQUFLLEVBQUUsQ0FBQztZQUMxQixNQUFNLEtBQUssR0FDVixHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsSUFBSyxHQUFHLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBWSxDQUFDO1lBQy9ELElBQUksQ0FBQyxLQUFLLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxTQUFTLElBQUksRUFBRSxFQUFFLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ2xFLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLENBQUM7Z0JBQzNDLE9BQU87WUFDUixDQUFDO1FBQ0YsQ0FBQztRQUVELElBQUksRUFBRSxDQUFDLENBQUMsdURBQXVEO0lBQ2hFLENBQUM7SUFBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO1FBQ2QsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsbURBQW1EO0lBQy9ELENBQUM7SUFFRCxPQUFPO0FBQ1IsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBjc3JmIGZyb20gJ2NzcmYnO1xuaW1wb3J0IHsgUmVxdWVzdCwgUmVzcG9uc2UsIE5leHRGdW5jdGlvbiB9IGZyb20gJ2V4cHJlc3MnO1xuXG4vLyBDcmVhdGUgYSBuZXcgQ1NSRiBwcm90ZWN0aW9uIGluc3RhbmNlXG5jb25zdCBjc3JmUHJvdGVjdGlvbiA9IG5ldyBjc3JmKHsgc2VjcmV0TGVuZ3RoOiAzMiB9KTtcblxuLy8gTWlkZGxld2FyZSB0byBhZGQgQ1NSRiB0b2tlbiB0byB0aGUgcmVzcG9uc2UgYW5kIHZhbGlkYXRlIGluY29taW5nIENTUkYgdG9rZW5zXG5leHBvcnQgZnVuY3Rpb24gY3NyZk1pZGRsZXdhcmUoXG5cdHJlcTogUmVxdWVzdCxcblx0cmVzOiBSZXNwb25zZSxcblx0bmV4dDogTmV4dEZ1bmN0aW9uXG4pOiB2b2lkIHtcblx0dHJ5IHtcblx0XHQvLyBHZW5lcmF0ZSBhbmQgc2V0IGEgQ1NSRm0gdG9rZW4gaW4gdGhlIHJlc3BvbnNlIGxvY2Fsc1xuXHRcdHJlcy5sb2NhbHMuY3NyZlRva2VuID0gY3NyZlByb3RlY3Rpb24uY3JlYXRlKHJlcS5zZXNzaW9uSUQgfHwgJycpOyAvLyBHZW5lcmF0ZSBDU1JGIHRva2VuIGJhc2VkIG9uIHNlc3Npb24gSUQgb3Igc29tZSB1bmlxdWUgaWRlbnRpZmllclxuXG5cdFx0Ly8gSWYgdGhlIHJlcXVlc3QgbWV0aG9kIGlzIG5vdCBHRVQsIHZhbGlkYXRlIHRoZSBDU1JGIHRva2VuXG5cdFx0aWYgKHJlcS5tZXRob2QgIT09ICdHRVQnKSB7XG5cdFx0XHRjb25zdCB0b2tlbiA9XG5cdFx0XHRcdHJlcS5ib2R5LmNzcmZUb2tlbiB8fCAocmVxLmhlYWRlcnNbJ3gteHNyZi10b2tlbiddIGFzIHN0cmluZyk7XG5cdFx0XHRpZiAoIXRva2VuIHx8ICFjc3JmUHJvdGVjdGlvbi52ZXJpZnkocmVxLnNlc3Npb25JRCB8fCAnJywgdG9rZW4pKSB7XG5cdFx0XHRcdHJlcy5zdGF0dXMoNDAzKS5zZW5kKCdJbnZhbGlkIENTUkYgdG9rZW4nKTtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdG5leHQoKTsgLy8gaWYgdmFsaWRhdGlvbiBwYXNzZXMsIHByb2NlZWQgdG8gdGhlIG5leHQgbWlkZGxld2FyZVxuXHR9IGNhdGNoIChlcnIpIHtcblx0XHRuZXh0KGVycik7IC8vIHBhc3MgYW55IGVycm9ycyB0byB0aGUgZXJyb3IgaGFuZGxpbmcgbWlkZGxld2FyZVxuXHR9XG5cblx0cmV0dXJuO1xufVxuIl19