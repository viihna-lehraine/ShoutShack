import '../../types/custom/express-session';
function slowdownMiddleware(req, res, next) {
    const requestTime = new Date().getTime();
    // Check if we already stored a request time for this IP
    if (!req.session.lastRequestTime) {
        req.session.lastRequestTime = requestTime;
        next();
    }
    else {
        const timeDiff = requestTime - req.session.lastRequestTime;
        const slowdownThreshold = 100; // *DEV-NOTE* Adjust this value as needed (in ms)
        if (timeDiff < slowdownThreshold) {
            const waitTime = slowdownThreshold - timeDiff;
            setTimeout(next, waitTime);
        }
        else {
            req.session.lastRequestTime = requestTime;
            next();
        }
    }
}
export default slowdownMiddleware;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2xvd2Rvd24uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvbWlkZGxld2FyZS9zbG93ZG93bi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQSxPQUFPLG9DQUFvQyxDQUFDO0FBRTVDLFNBQVMsa0JBQWtCLENBQzFCLEdBQVksRUFDWixHQUFhLEVBQ2IsSUFBa0I7SUFFbEIsTUFBTSxXQUFXLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQztJQUV6Qyx3REFBd0Q7SUFDeEQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsZUFBZSxFQUFFLENBQUM7UUFDbEMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxlQUFlLEdBQUcsV0FBVyxDQUFDO1FBQzFDLElBQUksRUFBRSxDQUFDO0lBQ1IsQ0FBQztTQUFNLENBQUM7UUFDUCxNQUFNLFFBQVEsR0FBRyxXQUFXLEdBQUcsR0FBRyxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUM7UUFDM0QsTUFBTSxpQkFBaUIsR0FBRyxHQUFHLENBQUMsQ0FBQyxpREFBaUQ7UUFFaEYsSUFBSSxRQUFRLEdBQUcsaUJBQWlCLEVBQUUsQ0FBQztZQUNsQyxNQUFNLFFBQVEsR0FBRyxpQkFBaUIsR0FBRyxRQUFRLENBQUM7WUFDOUMsVUFBVSxDQUFDLElBQUksRUFBRSxRQUFRLENBQUMsQ0FBQztRQUM1QixDQUFDO2FBQU0sQ0FBQztZQUNQLEdBQUcsQ0FBQyxPQUFPLENBQUMsZUFBZSxHQUFHLFdBQVcsQ0FBQztZQUMxQyxJQUFJLEVBQUUsQ0FBQztRQUNSLENBQUM7SUFDRixDQUFDO0FBQ0YsQ0FBQztBQUVELGVBQWUsa0JBQWtCLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOZXh0RnVuY3Rpb24sIFJlcXVlc3QsIFJlc3BvbnNlIH0gZnJvbSAnZXhwcmVzcyc7XG5pbXBvcnQgJy4uLy4uL3R5cGVzL2N1c3RvbS9leHByZXNzLXNlc3Npb24nO1xuXG5mdW5jdGlvbiBzbG93ZG93bk1pZGRsZXdhcmUoXG5cdHJlcTogUmVxdWVzdCxcblx0cmVzOiBSZXNwb25zZSxcblx0bmV4dDogTmV4dEZ1bmN0aW9uXG4pOiB2b2lkIHtcblx0Y29uc3QgcmVxdWVzdFRpbWUgPSBuZXcgRGF0ZSgpLmdldFRpbWUoKTtcblxuXHQvLyBDaGVjayBpZiB3ZSBhbHJlYWR5IHN0b3JlZCBhIHJlcXVlc3QgdGltZSBmb3IgdGhpcyBJUFxuXHRpZiAoIXJlcS5zZXNzaW9uLmxhc3RSZXF1ZXN0VGltZSkge1xuXHRcdHJlcS5zZXNzaW9uLmxhc3RSZXF1ZXN0VGltZSA9IHJlcXVlc3RUaW1lO1xuXHRcdG5leHQoKTtcblx0fSBlbHNlIHtcblx0XHRjb25zdCB0aW1lRGlmZiA9IHJlcXVlc3RUaW1lIC0gcmVxLnNlc3Npb24ubGFzdFJlcXVlc3RUaW1lO1xuXHRcdGNvbnN0IHNsb3dkb3duVGhyZXNob2xkID0gMTAwOyAvLyAqREVWLU5PVEUqIEFkanVzdCB0aGlzIHZhbHVlIGFzIG5lZWRlZCAoaW4gbXMpXG5cblx0XHRpZiAodGltZURpZmYgPCBzbG93ZG93blRocmVzaG9sZCkge1xuXHRcdFx0Y29uc3Qgd2FpdFRpbWUgPSBzbG93ZG93blRocmVzaG9sZCAtIHRpbWVEaWZmO1xuXHRcdFx0c2V0VGltZW91dChuZXh0LCB3YWl0VGltZSk7XG5cdFx0fSBlbHNlIHtcblx0XHRcdHJlcS5zZXNzaW9uLmxhc3RSZXF1ZXN0VGltZSA9IHJlcXVlc3RUaW1lO1xuXHRcdFx0bmV4dCgpO1xuXHRcdH1cblx0fVxufVxuXG5leHBvcnQgZGVmYXVsdCBzbG93ZG93bk1pZGRsZXdhcmU7XG4iXX0=