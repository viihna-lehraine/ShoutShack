import multer from 'multer';
import path from 'path';
// Define the storage location and filename
let storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, path.join(__dirname, '../../uploads'));
    },
    filename: (req, file, cb) => {
        let uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
        cb(null, `${uniqueSuffix}-${file.originalname}`);
    }
});
// File filter definition with type declarations
let fileFilter = (req, file, cb) => {
    let allowedMimeTypes = [
        'application/json',
        'application/x-x509-ca-cert',
        'application/pgp-keys',
        'application/pgp-signature',
        'application/xml',
        'application/x-gpg-key',
        'application/x-pkcs7-certificates',
        'audio/mp4',
        'audio/mpeg',
        'audio/ogg',
        'audio/wav',
        'audio/webm',
        'image/bmp',
        'image/jpeg',
        'image/jpg',
        'image/gif',
        'image/png',
        'image/svg+xml',
        'image/tiff',
        'image/webp',
        'text/html',
        'text/css',
        'text/csv',
        'text/markdown',
        'text/plain',
        'video/mp4',
        'video/mpeg',
        'video/quicktime',
        'video/x-msvideo'
    ];
    let allowedExtensions = [
        '.avi',
        '.json',
        '.gpg',
        '.asc',
        '.xml',
        '.mp4',
        '.mp3',
        '.ogg',
        '.wav',
        '.webm',
        '.bmp',
        '.jpeg',
        '.jpg',
        '.gif',
        '.png',
        '.svg',
        '.tiff',
        '.webp',
        '.html',
        '.css',
        '.csv',
        '.md',
        '.txt',
        '.mpeg',
        '.mov',
        '.crt'
    ];
    let ext = path.extname(file.originalname).toLowerCase();
    if (allowedMimeTypes.includes(file.mimetype) &&
        allowedExtensions.includes(ext)) {
        cb(null, true);
    }
    else {
        cb(null, false);
    }
};
// Set limits for the uploaded fileslet multerLimits = {
let multerLimits = {
    fileSize: 1024 * 1024 * 5
}; // Limit files to 5MB
// Create the multer instance with the storage, fileFilter, and limits
let multerConfiguredUpload = multer({
    storage: storage,
    fileFilter: fileFilter,
    limits: multerLimits
});
export default multerConfiguredUpload;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibXVsdGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL2NvbmZpZy9tdWx0ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0EsT0FBTyxNQUE4QixNQUFNLFFBQVEsQ0FBQztBQUNwRCxPQUFPLElBQUksTUFBTSxNQUFNLENBQUM7QUFFeEIsMkNBQTJDO0FBQzNDLElBQUksT0FBTyxHQUFHLE1BQU0sQ0FBQyxXQUFXLENBQUM7SUFDaEMsV0FBVyxFQUFFLENBQUMsR0FBRyxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsRUFBRTtRQUM5QixFQUFFLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLGVBQWUsQ0FBQyxDQUFDLENBQUM7SUFDakQsQ0FBQztJQUNELFFBQVEsRUFBRSxDQUFDLEdBQUcsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLEVBQUU7UUFDM0IsSUFBSSxZQUFZLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsR0FBRyxDQUFDLEVBQUUsQ0FBQztRQUN0RSxFQUFFLENBQUMsSUFBSSxFQUFFLEdBQUcsWUFBWSxJQUFJLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQyxDQUFDO0lBQ2xELENBQUM7Q0FDRCxDQUFDLENBQUM7QUFFSCxnREFBZ0Q7QUFDaEQsSUFBSSxVQUFVLEdBQUcsQ0FDaEIsR0FBWSxFQUNaLElBQXlCLEVBQ3pCLEVBQXNCLEVBQ3JCLEVBQUU7SUFDSCxJQUFJLGdCQUFnQixHQUFHO1FBQ3RCLGtCQUFrQjtRQUNsQiw0QkFBNEI7UUFDNUIsc0JBQXNCO1FBQ3RCLDJCQUEyQjtRQUMzQixpQkFBaUI7UUFDakIsdUJBQXVCO1FBQ3ZCLGtDQUFrQztRQUNsQyxXQUFXO1FBQ1gsWUFBWTtRQUNaLFdBQVc7UUFDWCxXQUFXO1FBQ1gsWUFBWTtRQUNaLFdBQVc7UUFDWCxZQUFZO1FBQ1osV0FBVztRQUNYLFdBQVc7UUFDWCxXQUFXO1FBQ1gsZUFBZTtRQUNmLFlBQVk7UUFDWixZQUFZO1FBQ1osV0FBVztRQUNYLFVBQVU7UUFDVixVQUFVO1FBQ1YsZUFBZTtRQUNmLFlBQVk7UUFDWixXQUFXO1FBQ1gsWUFBWTtRQUNaLGlCQUFpQjtRQUNqQixpQkFBaUI7S0FDakIsQ0FBQztJQUVGLElBQUksaUJBQWlCLEdBQUc7UUFDdkIsTUFBTTtRQUNOLE9BQU87UUFDUCxNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sT0FBTztRQUNQLE1BQU07UUFDTixPQUFPO1FBQ1AsTUFBTTtRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE9BQU87UUFDUCxPQUFPO1FBQ1AsT0FBTztRQUNQLE1BQU07UUFDTixNQUFNO1FBQ04sS0FBSztRQUNMLE1BQU07UUFDTixPQUFPO1FBQ1AsTUFBTTtRQUNOLE1BQU07S0FDTixDQUFDO0lBRUYsSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7SUFDeEQsSUFDQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztRQUN4QyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQzlCLENBQUM7UUFDRixFQUFFLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ2hCLENBQUM7U0FBTSxDQUFDO1FBQ1AsRUFBRSxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNqQixDQUFDO0FBQ0YsQ0FBQyxDQUFDO0FBRUYsd0RBQXdEO0FBQ3hELElBQUksWUFBWSxHQUFHO0lBQ2xCLFFBQVEsRUFBRSxJQUFJLEdBQUcsSUFBSSxHQUFHLENBQUM7Q0FDekIsQ0FBQyxDQUFDLHFCQUFxQjtBQUV4QixzRUFBc0U7QUFDdEUsSUFBSSxzQkFBc0IsR0FBRyxNQUFNLENBQUM7SUFDbkMsT0FBTyxFQUFFLE9BQU87SUFDaEIsVUFBVSxFQUFFLFVBQVU7SUFDdEIsTUFBTSxFQUFFLFlBQVk7Q0FDcEIsQ0FBQyxDQUFDO0FBRUgsZUFBZSxzQkFBc0IsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFJlcXVlc3QgfSBmcm9tICdleHByZXNzJztcbmltcG9ydCBtdWx0ZXIsIHsgRmlsZUZpbHRlckNhbGxiYWNrIH0gZnJvbSAnbXVsdGVyJztcbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnO1xuXG4vLyBEZWZpbmUgdGhlIHN0b3JhZ2UgbG9jYXRpb24gYW5kIGZpbGVuYW1lXG5sZXQgc3RvcmFnZSA9IG11bHRlci5kaXNrU3RvcmFnZSh7XG5cdGRlc3RpbmF0aW9uOiAocmVxLCBmaWxlLCBjYikgPT4ge1xuXHRcdGNiKG51bGwsIHBhdGguam9pbihfX2Rpcm5hbWUsICcuLi8uLi91cGxvYWRzJykpO1xuXHR9LFxuXHRmaWxlbmFtZTogKHJlcSwgZmlsZSwgY2IpID0+IHtcblx0XHRsZXQgdW5pcXVlU3VmZml4ID0gYCR7RGF0ZS5ub3coKX0tJHtNYXRoLnJvdW5kKE1hdGgucmFuZG9tKCkgKiAxZTkpfWA7XG5cdFx0Y2IobnVsbCwgYCR7dW5pcXVlU3VmZml4fS0ke2ZpbGUub3JpZ2luYWxuYW1lfWApO1xuXHR9XG59KTtcblxuLy8gRmlsZSBmaWx0ZXIgZGVmaW5pdGlvbiB3aXRoIHR5cGUgZGVjbGFyYXRpb25zXG5sZXQgZmlsZUZpbHRlciA9IChcblx0cmVxOiBSZXF1ZXN0LFxuXHRmaWxlOiBFeHByZXNzLk11bHRlci5GaWxlLFxuXHRjYjogRmlsZUZpbHRlckNhbGxiYWNrXG4pID0+IHtcblx0bGV0IGFsbG93ZWRNaW1lVHlwZXMgPSBbXG5cdFx0J2FwcGxpY2F0aW9uL2pzb24nLFxuXHRcdCdhcHBsaWNhdGlvbi94LXg1MDktY2EtY2VydCcsXG5cdFx0J2FwcGxpY2F0aW9uL3BncC1rZXlzJyxcblx0XHQnYXBwbGljYXRpb24vcGdwLXNpZ25hdHVyZScsXG5cdFx0J2FwcGxpY2F0aW9uL3htbCcsXG5cdFx0J2FwcGxpY2F0aW9uL3gtZ3BnLWtleScsXG5cdFx0J2FwcGxpY2F0aW9uL3gtcGtjczctY2VydGlmaWNhdGVzJyxcblx0XHQnYXVkaW8vbXA0Jyxcblx0XHQnYXVkaW8vbXBlZycsXG5cdFx0J2F1ZGlvL29nZycsXG5cdFx0J2F1ZGlvL3dhdicsXG5cdFx0J2F1ZGlvL3dlYm0nLFxuXHRcdCdpbWFnZS9ibXAnLFxuXHRcdCdpbWFnZS9qcGVnJyxcblx0XHQnaW1hZ2UvanBnJyxcblx0XHQnaW1hZ2UvZ2lmJyxcblx0XHQnaW1hZ2UvcG5nJyxcblx0XHQnaW1hZ2Uvc3ZnK3htbCcsXG5cdFx0J2ltYWdlL3RpZmYnLFxuXHRcdCdpbWFnZS93ZWJwJyxcblx0XHQndGV4dC9odG1sJyxcblx0XHQndGV4dC9jc3MnLFxuXHRcdCd0ZXh0L2NzdicsXG5cdFx0J3RleHQvbWFya2Rvd24nLFxuXHRcdCd0ZXh0L3BsYWluJyxcblx0XHQndmlkZW8vbXA0Jyxcblx0XHQndmlkZW8vbXBlZycsXG5cdFx0J3ZpZGVvL3F1aWNrdGltZScsXG5cdFx0J3ZpZGVvL3gtbXN2aWRlbydcblx0XTtcblxuXHRsZXQgYWxsb3dlZEV4dGVuc2lvbnMgPSBbXG5cdFx0Jy5hdmknLFxuXHRcdCcuanNvbicsXG5cdFx0Jy5ncGcnLFxuXHRcdCcuYXNjJyxcblx0XHQnLnhtbCcsXG5cdFx0Jy5tcDQnLFxuXHRcdCcubXAzJyxcblx0XHQnLm9nZycsXG5cdFx0Jy53YXYnLFxuXHRcdCcud2VibScsXG5cdFx0Jy5ibXAnLFxuXHRcdCcuanBlZycsXG5cdFx0Jy5qcGcnLFxuXHRcdCcuZ2lmJyxcblx0XHQnLnBuZycsXG5cdFx0Jy5zdmcnLFxuXHRcdCcudGlmZicsXG5cdFx0Jy53ZWJwJyxcblx0XHQnLmh0bWwnLFxuXHRcdCcuY3NzJyxcblx0XHQnLmNzdicsXG5cdFx0Jy5tZCcsXG5cdFx0Jy50eHQnLFxuXHRcdCcubXBlZycsXG5cdFx0Jy5tb3YnLFxuXHRcdCcuY3J0J1xuXHRdO1xuXG5cdGxldCBleHQgPSBwYXRoLmV4dG5hbWUoZmlsZS5vcmlnaW5hbG5hbWUpLnRvTG93ZXJDYXNlKCk7XG5cdGlmIChcblx0XHRhbGxvd2VkTWltZVR5cGVzLmluY2x1ZGVzKGZpbGUubWltZXR5cGUpICYmXG5cdFx0YWxsb3dlZEV4dGVuc2lvbnMuaW5jbHVkZXMoZXh0KVxuXHQpIHtcblx0XHRjYihudWxsLCB0cnVlKTtcblx0fSBlbHNlIHtcblx0XHRjYihudWxsLCBmYWxzZSk7XG5cdH1cbn07XG5cbi8vIFNldCBsaW1pdHMgZm9yIHRoZSB1cGxvYWRlZCBmaWxlc2xldCBtdWx0ZXJMaW1pdHMgPSB7XG5sZXQgbXVsdGVyTGltaXRzID0ge1xuXHRmaWxlU2l6ZTogMTAyNCAqIDEwMjQgKiA1XG59OyAvLyBMaW1pdCBmaWxlcyB0byA1TUJcblxuLy8gQ3JlYXRlIHRoZSBtdWx0ZXIgaW5zdGFuY2Ugd2l0aCB0aGUgc3RvcmFnZSwgZmlsZUZpbHRlciwgYW5kIGxpbWl0c1xubGV0IG11bHRlckNvbmZpZ3VyZWRVcGxvYWQgPSBtdWx0ZXIoe1xuXHRzdG9yYWdlOiBzdG9yYWdlLFxuXHRmaWxlRmlsdGVyOiBmaWxlRmlsdGVyLFxuXHRsaW1pdHM6IG11bHRlckxpbWl0c1xufSk7XG5cbmV4cG9ydCBkZWZhdWx0IG11bHRlckNvbmZpZ3VyZWRVcGxvYWQ7XG4iXX0=