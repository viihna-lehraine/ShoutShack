import { __awaiter } from "tslib";
import { generateToken } from '../utils/auth/jwtUtil.js';
import UserModelPromise from '../models/User.js';
export let login = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        let User = yield UserModelPromise;
        let { username, password } = req.body;
        // Correctly type `user` and ensure the correct model is used
        let user = yield User.findOne({ where: { username } });
        if (!user) {
            return res
                .status(401)
                .json({ message: 'Login failed - invalid credentials' });
        }
        // Use the comparePassword method from the User model
        let isPasswordValid = yield user.comparePassword(password);
        if (!isPasswordValid) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }
        // Generate JWT token
        let token = yield generateToken(user);
        // Respond with the token
        res.json({ token });
    }
    catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
    return; // unreachable code, but it satisfies TypeScript *shrug*
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXV0aENvbnRyb2xsZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvY29udHJvbGxlcnMvYXV0aENvbnRyb2xsZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUNBLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSx1QkFBdUIsQ0FBQztBQUN0RCxPQUFPLGdCQUFnQixNQUFNLGdCQUFnQixDQUFDO0FBRTlDLE1BQU0sQ0FBQyxJQUFJLEtBQUssR0FBRyxDQUFPLEdBQVksRUFBRSxHQUFhLEVBQUUsRUFBRTtJQUN4RCxJQUFJLENBQUM7UUFDSixJQUFJLElBQUksR0FBRyxNQUFNLGdCQUFnQixDQUFDO1FBRWxDLElBQUksRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQztRQUV0Qyw2REFBNkQ7UUFDN0QsSUFBSSxJQUFJLEdBQUcsTUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsS0FBSyxFQUFFLEVBQUUsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBRXZELElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNYLE9BQU8sR0FBRztpQkFDUixNQUFNLENBQUMsR0FBRyxDQUFDO2lCQUNYLElBQUksQ0FBQyxFQUFFLE9BQU8sRUFBRSxvQ0FBb0MsRUFBRSxDQUFDLENBQUM7UUFDM0QsQ0FBQztRQUVELHFEQUFxRDtRQUNyRCxJQUFJLGVBQWUsR0FBRyxNQUFNLElBQUksQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFM0QsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1lBQ3RCLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxPQUFPLEVBQUUscUJBQXFCLEVBQUUsQ0FBQyxDQUFDO1FBQ2pFLENBQUM7UUFFRCxxQkFBcUI7UUFDckIsSUFBSSxLQUFLLEdBQUcsTUFBTSxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFdEMseUJBQXlCO1FBQ3pCLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDO0lBQ3JCLENBQUM7SUFBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO1FBQ2QsT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNuQixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sRUFBRSxjQUFjLEVBQUUsQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFFRCxPQUFPLENBQUMsd0RBQXdEO0FBQ2pFLENBQUMsQ0FBQSxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUmVxdWVzdCwgUmVzcG9uc2UgfSBmcm9tICdleHByZXNzJztcbmltcG9ydCB7IGdlbmVyYXRlVG9rZW4gfSBmcm9tICcuLi91dGlscy9hdXRoL2p3dFV0aWwnO1xuaW1wb3J0IFVzZXJNb2RlbFByb21pc2UgZnJvbSAnLi4vbW9kZWxzL1VzZXInO1xuXG5leHBvcnQgbGV0IGxvZ2luID0gYXN5bmMgKHJlcTogUmVxdWVzdCwgcmVzOiBSZXNwb25zZSkgPT4ge1xuXHR0cnkge1xuXHRcdGxldCBVc2VyID0gYXdhaXQgVXNlck1vZGVsUHJvbWlzZTtcblxuXHRcdGxldCB7IHVzZXJuYW1lLCBwYXNzd29yZCB9ID0gcmVxLmJvZHk7XG5cblx0XHQvLyBDb3JyZWN0bHkgdHlwZSBgdXNlcmAgYW5kIGVuc3VyZSB0aGUgY29ycmVjdCBtb2RlbCBpcyB1c2VkXG5cdFx0bGV0IHVzZXIgPSBhd2FpdCBVc2VyLmZpbmRPbmUoeyB3aGVyZTogeyB1c2VybmFtZSB9IH0pO1xuXG5cdFx0aWYgKCF1c2VyKSB7XG5cdFx0XHRyZXR1cm4gcmVzXG5cdFx0XHRcdC5zdGF0dXMoNDAxKVxuXHRcdFx0XHQuanNvbih7IG1lc3NhZ2U6ICdMb2dpbiBmYWlsZWQgLSBpbnZhbGlkIGNyZWRlbnRpYWxzJyB9KTtcblx0XHR9XG5cblx0XHQvLyBVc2UgdGhlIGNvbXBhcmVQYXNzd29yZCBtZXRob2QgZnJvbSB0aGUgVXNlciBtb2RlbFxuXHRcdGxldCBpc1Bhc3N3b3JkVmFsaWQgPSBhd2FpdCB1c2VyLmNvbXBhcmVQYXNzd29yZChwYXNzd29yZCk7XG5cblx0XHRpZiAoIWlzUGFzc3dvcmRWYWxpZCkge1xuXHRcdFx0cmV0dXJuIHJlcy5zdGF0dXMoNDAxKS5qc29uKHsgbWVzc2FnZTogJ0ludmFsaWQgY3JlZGVudGlhbHMnIH0pO1xuXHRcdH1cblxuXHRcdC8vIEdlbmVyYXRlIEpXVCB0b2tlblxuXHRcdGxldCB0b2tlbiA9IGF3YWl0IGdlbmVyYXRlVG9rZW4odXNlcik7XG5cblx0XHQvLyBSZXNwb25kIHdpdGggdGhlIHRva2VuXG5cdFx0cmVzLmpzb24oeyB0b2tlbiB9KTtcblx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0Y29uc29sZS5lcnJvcihlcnIpO1xuXHRcdHJlcy5zdGF0dXMoNTAwKS5qc29uKHsgbWVzc2FnZTogJ1NlcnZlciBlcnJvcicgfSk7XG5cdH1cblxuXHRyZXR1cm47IC8vIHVucmVhY2hhYmxlIGNvZGUsIGJ1dCBpdCBzYXRpc2ZpZXMgVHlwZVNjcmlwdCAqc2hydWcqXG59O1xuIl19