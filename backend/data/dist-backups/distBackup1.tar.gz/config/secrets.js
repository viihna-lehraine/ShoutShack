import { __awaiter } from "tslib";
import { execSync } from 'child_process';
import path from 'path';
let __dirname = process.cwd();
function getDirectoryPath() {
    // Return the absolute path to the directory containing secrets.js
    return path.resolve(__dirname);
}
function getSecrets() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            let secretsPath = path.join(getDirectoryPath(), '../backend/config/secrets.json.gpg');
            console.log('Resolved secrets path:', secretsPath); // debugging line to verify the correct path
            let decryptedSecrets = execSync(`sops -d --output-type json ${secretsPath}`).toString();
            return JSON.parse(decryptedSecrets);
        }
        catch (err) {
            console.error('Error retrieving secrets from SOPS: ', err);
            throw err;
        }
    });
}
export default getSecrets;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VjcmV0cy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9jb25maWcvc2VjcmV0cy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUN6QyxPQUFPLElBQUksTUFBTSxNQUFNLENBQUM7QUFFeEIsSUFBSSxTQUFTLEdBQUcsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDO0FBRTlCLFNBQVMsZ0JBQWdCO0lBQ3hCLGtFQUFrRTtJQUNsRSxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDaEMsQ0FBQztBQUVELFNBQWUsVUFBVTs7UUFDeEIsSUFBSSxDQUFDO1lBQ0osSUFBSSxXQUFXLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FDMUIsZ0JBQWdCLEVBQUUsRUFDbEIsb0NBQW9DLENBQ3BDLENBQUM7WUFDRixPQUFPLENBQUMsR0FBRyxDQUFDLHdCQUF3QixFQUFFLFdBQVcsQ0FBQyxDQUFDLENBQUMsNENBQTRDO1lBQ2hHLElBQUksZ0JBQWdCLEdBQUcsUUFBUSxDQUM5Qiw4QkFBOEIsV0FBVyxFQUFFLENBQzNDLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDYixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztRQUNyQyxDQUFDO1FBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztZQUNkLE9BQU8sQ0FBQyxLQUFLLENBQUMsc0NBQXNDLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDM0QsTUFBTSxHQUFHLENBQUM7UUFDWCxDQUFDO0lBQ0YsQ0FBQztDQUFBO0FBRUQsZUFBZSxVQUFVLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBleGVjU3luYyB9IGZyb20gJ2NoaWxkX3Byb2Nlc3MnO1xuaW1wb3J0IHBhdGggZnJvbSAncGF0aCc7XG5cbmxldCBfX2Rpcm5hbWUgPSBwcm9jZXNzLmN3ZCgpO1xuXG5mdW5jdGlvbiBnZXREaXJlY3RvcnlQYXRoKCkge1xuXHQvLyBSZXR1cm4gdGhlIGFic29sdXRlIHBhdGggdG8gdGhlIGRpcmVjdG9yeSBjb250YWluaW5nIHNlY3JldHMuanNcblx0cmV0dXJuIHBhdGgucmVzb2x2ZShfX2Rpcm5hbWUpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBnZXRTZWNyZXRzKCkge1xuXHR0cnkge1xuXHRcdGxldCBzZWNyZXRzUGF0aCA9IHBhdGguam9pbihcblx0XHRcdGdldERpcmVjdG9yeVBhdGgoKSxcblx0XHRcdCcuLi9iYWNrZW5kL2NvbmZpZy9zZWNyZXRzLmpzb24uZ3BnJ1xuXHRcdCk7XG5cdFx0Y29uc29sZS5sb2coJ1Jlc29sdmVkIHNlY3JldHMgcGF0aDonLCBzZWNyZXRzUGF0aCk7IC8vIGRlYnVnZ2luZyBsaW5lIHRvIHZlcmlmeSB0aGUgY29ycmVjdCBwYXRoXG5cdFx0bGV0IGRlY3J5cHRlZFNlY3JldHMgPSBleGVjU3luYyhcblx0XHRcdGBzb3BzIC1kIC0tb3V0cHV0LXR5cGUganNvbiAke3NlY3JldHNQYXRofWBcblx0XHQpLnRvU3RyaW5nKCk7XG5cdFx0cmV0dXJuIEpTT04ucGFyc2UoZGVjcnlwdGVkU2VjcmV0cyk7XG5cdH0gY2F0Y2ggKGVycikge1xuXHRcdGNvbnNvbGUuZXJyb3IoJ0Vycm9yIHJldHJpZXZpbmcgc2VjcmV0cyBmcm9tIFNPUFM6ICcsIGVycik7XG5cdFx0dGhyb3cgZXJyO1xuXHR9XG59XG5cbmV4cG9ydCBkZWZhdWx0IGdldFNlY3JldHM7XG4iXX0=