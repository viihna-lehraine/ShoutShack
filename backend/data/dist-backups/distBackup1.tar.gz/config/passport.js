import { __awaiter } from "tslib";
import { Strategy as JwtStrategy, ExtractJwt } from 'passport-jwt';
import { Strategy as LocalStrategy } from 'passport-local';
import setupLogger from '../middleware/logger.js';
import getSecrets from './secrets.js';
import UserModelPromise from '../models/User.js';
export default function configurePassport(passport) {
    return __awaiter(this, void 0, void 0, function* () {
        let secrets = yield getSecrets();
        let logger = yield setupLogger();
        let UserModel = yield UserModelPromise;
        let opts = {
            jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
            secretOrKey: secrets.JWT_SECRET
        };
        passport.use(new JwtStrategy(opts, (jwt_payload, done) => __awaiter(this, void 0, void 0, function* () {
            try {
                let user = yield UserModel.findByPk(jwt_payload.id);
                if (user) {
                    logger.info('JWT authentication successful for user ID: ', jwt_payload.id);
                    return done(null, user);
                }
                else {
                    logger.warn('JWT authentication failed for user ID: ', jwt_payload.id);
                    return done(null, false);
                }
            }
            catch (err) {
                logger.error('JWT authentication error: ', err);
                return done(err, false);
            }
        })));
        passport.use(new LocalStrategy((username, password, done) => __awaiter(this, void 0, void 0, function* () {
            try {
                let user = yield UserModel.findOne({ where: { username } });
                if (!user) {
                    logger.warn('Local authentication failed: User not found: ', username);
                    return done(null, false, { message: 'User not found' });
                }
                let isMatch = yield user.comparePassword(password);
                if (isMatch) {
                    logger.info('Local authentication successful for user: ', username);
                    return done(null, user);
                }
                else {
                    logger.warn('Local authentication failed: incorrect password for user: ', username);
                    return done(null, false, { message: 'Incorrect password' });
                }
            }
            catch (err) {
                logger.error('Local authenticaton error for user: ', username, ' : Error: ', err);
                return done(err);
            }
        })));
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFzc3BvcnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvY29uZmlnL3Bhc3Nwb3J0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFDQSxPQUFPLEVBQ04sUUFBUSxJQUFJLFdBQVcsRUFDdkIsVUFBVSxFQUVWLE1BQU0sY0FBYyxDQUFDO0FBQ3RCLE9BQU8sRUFBRSxRQUFRLElBQUksYUFBYSxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDM0QsT0FBTyxXQUFXLE1BQU0sc0JBQXNCLENBQUM7QUFDL0MsT0FBTyxVQUFVLE1BQU0sV0FBVyxDQUFDO0FBQ25DLE9BQU8sZ0JBQWdCLE1BQU0sZ0JBQWdCLENBQUM7QUFTOUMsTUFBTSxDQUFDLE9BQU8sVUFBZ0IsaUJBQWlCLENBQUMsUUFBd0I7O1FBQ3ZFLElBQUksT0FBTyxHQUFHLE1BQU0sVUFBVSxFQUFFLENBQUM7UUFDakMsSUFBSSxNQUFNLEdBQUcsTUFBTSxXQUFXLEVBQUUsQ0FBQztRQUNqQyxJQUFJLFNBQVMsR0FBRyxNQUFNLGdCQUFnQixDQUFDO1FBRXZDLElBQUksSUFBSSxHQUFvQjtZQUMzQixjQUFjLEVBQUUsVUFBVSxDQUFDLDJCQUEyQixFQUFFO1lBQ3hELFdBQVcsRUFBRSxPQUFPLENBQUMsVUFBVTtTQUMvQixDQUFDO1FBRUYsUUFBUSxDQUFDLEdBQUcsQ0FDWCxJQUFJLFdBQVcsQ0FDZCxJQUFJLEVBQ0osQ0FDQyxXQUEyQixFQUMzQixJQUlTLEVBQ1IsRUFBRTtZQUNILElBQUksQ0FBQztnQkFDSixJQUFJLElBQUksR0FBRyxNQUFNLFNBQVMsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUNwRCxJQUFJLElBQUksRUFBRSxDQUFDO29CQUNWLE1BQU0sQ0FBQyxJQUFJLENBQ1YsNkNBQTZDLEVBQzdDLFdBQVcsQ0FBQyxFQUFFLENBQ2QsQ0FBQztvQkFDRixPQUFPLElBQUksQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3pCLENBQUM7cUJBQU0sQ0FBQztvQkFDUCxNQUFNLENBQUMsSUFBSSxDQUNWLHlDQUF5QyxFQUN6QyxXQUFXLENBQUMsRUFBRSxDQUNkLENBQUM7b0JBQ0YsT0FBTyxJQUFJLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO2dCQUMxQixDQUFDO1lBQ0YsQ0FBQztZQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7Z0JBQ2QsTUFBTSxDQUFDLEtBQUssQ0FBQyw0QkFBNEIsRUFBRSxHQUFHLENBQUMsQ0FBQztnQkFDaEQsT0FBTyxJQUFJLENBQUMsR0FBWSxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ2xDLENBQUM7UUFDRixDQUFDLENBQUEsQ0FDRCxDQUNELENBQUM7UUFFRixRQUFRLENBQUMsR0FBRyxDQUNYLElBQUksYUFBYSxDQUFDLENBQU8sUUFBUSxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsRUFBRTtZQUNwRCxJQUFJLENBQUM7Z0JBQ0osSUFBSSxJQUFJLEdBQUcsTUFBTSxTQUFTLENBQUMsT0FBTyxDQUFDLEVBQUUsS0FBSyxFQUFFLEVBQUUsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dCQUM1RCxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ1gsTUFBTSxDQUFDLElBQUksQ0FDViwrQ0FBK0MsRUFDL0MsUUFBUSxDQUNSLENBQUM7b0JBQ0YsT0FBTyxJQUFJLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxFQUFFLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxDQUFDLENBQUM7Z0JBQ3pELENBQUM7Z0JBRUQsSUFBSSxPQUFPLEdBQUcsTUFBTSxJQUFJLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUNuRCxJQUFJLE9BQU8sRUFBRSxDQUFDO29CQUNiLE1BQU0sQ0FBQyxJQUFJLENBQ1YsNENBQTRDLEVBQzVDLFFBQVEsQ0FDUixDQUFDO29CQUNGLE9BQU8sSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDekIsQ0FBQztxQkFBTSxDQUFDO29CQUNQLE1BQU0sQ0FBQyxJQUFJLENBQ1YsNERBQTRELEVBQzVELFFBQVEsQ0FDUixDQUFDO29CQUNGLE9BQU8sSUFBSSxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsRUFBRSxPQUFPLEVBQUUsb0JBQW9CLEVBQUUsQ0FBQyxDQUFDO2dCQUM3RCxDQUFDO1lBQ0YsQ0FBQztZQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7Z0JBQ2QsTUFBTSxDQUFDLEtBQUssQ0FDWCxzQ0FBc0MsRUFDdEMsUUFBUSxFQUNSLFlBQVksRUFDWixHQUFHLENBQ0gsQ0FBQztnQkFDRixPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNsQixDQUFDO1FBQ0YsQ0FBQyxDQUFBLENBQUMsQ0FDRixDQUFDO0lBQ0gsQ0FBQztDQUFBIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUGFzc3BvcnRTdGF0aWMgfSBmcm9tICdwYXNzcG9ydCc7XG5pbXBvcnQge1xuXHRTdHJhdGVneSBhcyBKd3RTdHJhdGVneSxcblx0RXh0cmFjdEp3dCxcblx0U3RyYXRlZ3lPcHRpb25zXG59IGZyb20gJ3Bhc3Nwb3J0LWp3dCc7XG5pbXBvcnQgeyBTdHJhdGVneSBhcyBMb2NhbFN0cmF0ZWd5IH0gZnJvbSAncGFzc3BvcnQtbG9jYWwnO1xuaW1wb3J0IHNldHVwTG9nZ2VyIGZyb20gJy4uL21pZGRsZXdhcmUvbG9nZ2VyJztcbmltcG9ydCBnZXRTZWNyZXRzIGZyb20gJy4vc2VjcmV0cyc7XG5pbXBvcnQgVXNlck1vZGVsUHJvbWlzZSBmcm9tICcuLi9tb2RlbHMvVXNlcic7XG5cbi8vIERlZmluZSB0aGUgc2hhcGUgb2YgYSB1c2VyIGluc3RhbmNlIGJhc2VkIG9uIFVzZXIgbW9kZWxcbmludGVyZmFjZSBVc2VySW5zdGFuY2Uge1xuXHRpZDogc3RyaW5nO1xuXHR1c2VybmFtZTogc3RyaW5nO1xuXHRjb21wYXJlUGFzc3dvcmQ6IChwYXNzd29yZDogc3RyaW5nKSA9PiBQcm9taXNlPGJvb2xlYW4+O1xufVxuXG5leHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbiBjb25maWd1cmVQYXNzcG9ydChwYXNzcG9ydDogUGFzc3BvcnRTdGF0aWMpIHtcblx0bGV0IHNlY3JldHMgPSBhd2FpdCBnZXRTZWNyZXRzKCk7XG5cdGxldCBsb2dnZXIgPSBhd2FpdCBzZXR1cExvZ2dlcigpO1xuXHRsZXQgVXNlck1vZGVsID0gYXdhaXQgVXNlck1vZGVsUHJvbWlzZTtcblxuXHRsZXQgb3B0czogU3RyYXRlZ3lPcHRpb25zID0ge1xuXHRcdGp3dEZyb21SZXF1ZXN0OiBFeHRyYWN0Snd0LmZyb21BdXRoSGVhZGVyQXNCZWFyZXJUb2tlbigpLFxuXHRcdHNlY3JldE9yS2V5OiBzZWNyZXRzLkpXVF9TRUNSRVRcblx0fTtcblxuXHRwYXNzcG9ydC51c2UoXG5cdFx0bmV3IEp3dFN0cmF0ZWd5KFxuXHRcdFx0b3B0cyxcblx0XHRcdGFzeW5jIChcblx0XHRcdFx0and0X3BheWxvYWQ6IHsgaWQ6IHN0cmluZyB9LFxuXHRcdFx0XHRkb25lOiAoXG5cdFx0XHRcdFx0ZXJyb3I6IEVycm9yIHwgbnVsbCxcblx0XHRcdFx0XHR1c2VyPzogVXNlckluc3RhbmNlIHwgZmFsc2UsXG5cdFx0XHRcdFx0aW5mbz86IHVua25vd25cblx0XHRcdFx0KSA9PiB2b2lkXG5cdFx0XHQpID0+IHtcblx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRsZXQgdXNlciA9IGF3YWl0IFVzZXJNb2RlbC5maW5kQnlQayhqd3RfcGF5bG9hZC5pZCk7XG5cdFx0XHRcdFx0aWYgKHVzZXIpIHtcblx0XHRcdFx0XHRcdGxvZ2dlci5pbmZvKFxuXHRcdFx0XHRcdFx0XHQnSldUIGF1dGhlbnRpY2F0aW9uIHN1Y2Nlc3NmdWwgZm9yIHVzZXIgSUQ6ICcsXG5cdFx0XHRcdFx0XHRcdGp3dF9wYXlsb2FkLmlkXG5cdFx0XHRcdFx0XHQpO1xuXHRcdFx0XHRcdFx0cmV0dXJuIGRvbmUobnVsbCwgdXNlcik7XG5cdFx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRcdGxvZ2dlci53YXJuKFxuXHRcdFx0XHRcdFx0XHQnSldUIGF1dGhlbnRpY2F0aW9uIGZhaWxlZCBmb3IgdXNlciBJRDogJyxcblx0XHRcdFx0XHRcdFx0and0X3BheWxvYWQuaWRcblx0XHRcdFx0XHRcdCk7XG5cdFx0XHRcdFx0XHRyZXR1cm4gZG9uZShudWxsLCBmYWxzZSk7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9IGNhdGNoIChlcnIpIHtcblx0XHRcdFx0XHRsb2dnZXIuZXJyb3IoJ0pXVCBhdXRoZW50aWNhdGlvbiBlcnJvcjogJywgZXJyKTtcblx0XHRcdFx0XHRyZXR1cm4gZG9uZShlcnIgYXMgRXJyb3IsIGZhbHNlKTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdClcblx0KTtcblxuXHRwYXNzcG9ydC51c2UoXG5cdFx0bmV3IExvY2FsU3RyYXRlZ3koYXN5bmMgKHVzZXJuYW1lLCBwYXNzd29yZCwgZG9uZSkgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0bGV0IHVzZXIgPSBhd2FpdCBVc2VyTW9kZWwuZmluZE9uZSh7IHdoZXJlOiB7IHVzZXJuYW1lIH0gfSk7XG5cdFx0XHRcdGlmICghdXNlcikge1xuXHRcdFx0XHRcdGxvZ2dlci53YXJuKFxuXHRcdFx0XHRcdFx0J0xvY2FsIGF1dGhlbnRpY2F0aW9uIGZhaWxlZDogVXNlciBub3QgZm91bmQ6ICcsXG5cdFx0XHRcdFx0XHR1c2VybmFtZVxuXHRcdFx0XHRcdCk7XG5cdFx0XHRcdFx0cmV0dXJuIGRvbmUobnVsbCwgZmFsc2UsIHsgbWVzc2FnZTogJ1VzZXIgbm90IGZvdW5kJyB9KTtcblx0XHRcdFx0fVxuXG5cdFx0XHRcdGxldCBpc01hdGNoID0gYXdhaXQgdXNlci5jb21wYXJlUGFzc3dvcmQocGFzc3dvcmQpO1xuXHRcdFx0XHRpZiAoaXNNYXRjaCkge1xuXHRcdFx0XHRcdGxvZ2dlci5pbmZvKFxuXHRcdFx0XHRcdFx0J0xvY2FsIGF1dGhlbnRpY2F0aW9uIHN1Y2Nlc3NmdWwgZm9yIHVzZXI6ICcsXG5cdFx0XHRcdFx0XHR1c2VybmFtZVxuXHRcdFx0XHRcdCk7XG5cdFx0XHRcdFx0cmV0dXJuIGRvbmUobnVsbCwgdXNlcik7XG5cdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0bG9nZ2VyLndhcm4oXG5cdFx0XHRcdFx0XHQnTG9jYWwgYXV0aGVudGljYXRpb24gZmFpbGVkOiBpbmNvcnJlY3QgcGFzc3dvcmQgZm9yIHVzZXI6ICcsXG5cdFx0XHRcdFx0XHR1c2VybmFtZVxuXHRcdFx0XHRcdCk7XG5cdFx0XHRcdFx0cmV0dXJuIGRvbmUobnVsbCwgZmFsc2UsIHsgbWVzc2FnZTogJ0luY29ycmVjdCBwYXNzd29yZCcgfSk7XG5cdFx0XHRcdH1cblx0XHRcdH0gY2F0Y2ggKGVycikge1xuXHRcdFx0XHRsb2dnZXIuZXJyb3IoXG5cdFx0XHRcdFx0J0xvY2FsIGF1dGhlbnRpY2F0b24gZXJyb3IgZm9yIHVzZXI6ICcsXG5cdFx0XHRcdFx0dXNlcm5hbWUsXG5cdFx0XHRcdFx0JyA6IEVycm9yOiAnLFxuXHRcdFx0XHRcdGVyclxuXHRcdFx0XHQpO1xuXHRcdFx0XHRyZXR1cm4gZG9uZShlcnIpO1xuXHRcdFx0fVxuXHRcdH0pXG5cdCk7XG59XG4iXX0=