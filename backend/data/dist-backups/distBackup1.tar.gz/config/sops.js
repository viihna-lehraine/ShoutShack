import { __awaiter } from "tslib";
import { execSync } from 'child_process';
import path from 'path';
import { __dirname } from './loadEnv.js';
import setupLogger from '../middleware/logger.js';
function decryptFile(encryptedFilePath) {
    return __awaiter(this, void 0, void 0, function* () {
        let logger = yield setupLogger();
        try {
            let decryptedFile = execSync(`sops -d --output-type json ${encryptedFilePath}`).toString();
            return decryptedFile;
        }
        catch (err) {
            logger.error('Error decrypting file from SOPS: ', err);
            throw err;
        }
    });
}
function decryptDataFiles() {
    return __awaiter(this, void 0, void 0, function* () {
        let logger = yield setupLogger();
        try {
            let filePaths = [
                process.env.SERVER_DATA_FILE_PATH_1,
                process.env.SERVER_DATA_FILE_PATH_2,
                process.env.SERVER_DATA_FILE_PATH_3,
                process.env.SERVER_DATA_FILE_PATH_4
            ];
            let decryptedFiles = {};
            for (let [index, filePath] of filePaths.entries()) {
                if (filePath) {
                    decryptedFiles[`files${index + 1}`] = execSync(`sops -d --output-type json ${filePath}`).toString();
                }
                else {
                    logger.warn(`SERVER_DATA_FILE_PATH_${index + 1} is not defined`);
                }
            }
            return decryptedFiles;
        }
        catch (err) {
            logger.error('Error decrypting files from backend data folder: ', err);
            throw err;
        }
    });
}
function getSSLKeys() {
    return __awaiter(this, void 0, void 0, function* () {
        let logger = yield setupLogger();
        try {
            let keyPath = path.join(__dirname, './keys/ssl/guestbook_key.pem.gpg');
            let certPath = path.join(__dirname, './keys/ssl/guestbook_cert.pem.gpg');
            let decryptedKey = yield decryptFile(keyPath);
            let decryptedCert = yield decryptFile(certPath);
            return {
                key: decryptedKey,
                cert: decryptedCert
            };
        }
        catch (err) {
            logger.error('Error retrieving SSL keys from SOPS: ', err);
            throw err;
        }
    });
}
export default { decryptDataFiles, getSSLKeys };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic29wcy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9jb25maWcvc29wcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUN6QyxPQUFPLElBQUksTUFBTSxNQUFNLENBQUM7QUFDeEIsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLFdBQVcsQ0FBQztBQUN0QyxPQUFPLFdBQVcsTUFBTSxzQkFBc0IsQ0FBQztBQUUvQyxTQUFlLFdBQVcsQ0FBQyxpQkFBeUI7O1FBQ25ELElBQUksTUFBTSxHQUFHLE1BQU0sV0FBVyxFQUFFLENBQUM7UUFFakMsSUFBSSxDQUFDO1lBQ0osSUFBSSxhQUFhLEdBQUcsUUFBUSxDQUMzQiw4QkFBOEIsaUJBQWlCLEVBQUUsQ0FDakQsQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUNiLE9BQU8sYUFBYSxDQUFDO1FBQ3RCLENBQUM7UUFBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO1lBQ2QsTUFBTSxDQUFDLEtBQUssQ0FBQyxtQ0FBbUMsRUFBRSxHQUFHLENBQUMsQ0FBQztZQUN2RCxNQUFNLEdBQUcsQ0FBQztRQUNYLENBQUM7SUFDRixDQUFDO0NBQUE7QUFFRCxTQUFlLGdCQUFnQjs7UUFDOUIsSUFBSSxNQUFNLEdBQUcsTUFBTSxXQUFXLEVBQUUsQ0FBQztRQUVqQyxJQUFJLENBQUM7WUFDSixJQUFJLFNBQVMsR0FBRztnQkFDZixPQUFPLENBQUMsR0FBRyxDQUFDLHVCQUF1QjtnQkFDbkMsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUI7Z0JBQ25DLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCO2dCQUNuQyxPQUFPLENBQUMsR0FBRyxDQUFDLHVCQUF1QjthQUNuQyxDQUFDO1lBRUYsSUFBSSxjQUFjLEdBQThCLEVBQUUsQ0FBQztZQUVuRCxLQUFLLElBQUksQ0FBQyxLQUFLLEVBQUUsUUFBUSxDQUFDLElBQUksU0FBUyxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUM7Z0JBQ25ELElBQUksUUFBUSxFQUFFLENBQUM7b0JBQ2QsY0FBYyxDQUFDLFFBQVEsS0FBSyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsUUFBUSxDQUM3Qyw4QkFBOEIsUUFBUSxFQUFFLENBQ3hDLENBQUMsUUFBUSxFQUFFLENBQUM7Z0JBQ2QsQ0FBQztxQkFBTSxDQUFDO29CQUNQLE1BQU0sQ0FBQyxJQUFJLENBQ1YseUJBQXlCLEtBQUssR0FBRyxDQUFDLGlCQUFpQixDQUNuRCxDQUFDO2dCQUNILENBQUM7WUFDRixDQUFDO1lBRUQsT0FBTyxjQUFjLENBQUM7UUFDdkIsQ0FBQztRQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7WUFDZCxNQUFNLENBQUMsS0FBSyxDQUFDLG1EQUFtRCxFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBQ3ZFLE1BQU0sR0FBRyxDQUFDO1FBQ1gsQ0FBQztJQUNGLENBQUM7Q0FBQTtBQUVELFNBQWUsVUFBVTs7UUFDeEIsSUFBSSxNQUFNLEdBQUcsTUFBTSxXQUFXLEVBQUUsQ0FBQztRQUVqQyxJQUFJLENBQUM7WUFDSixJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxrQ0FBa0MsQ0FBQyxDQUFDO1lBQ3ZFLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQ3ZCLFNBQVMsRUFDVCxtQ0FBbUMsQ0FDbkMsQ0FBQztZQUNGLElBQUksWUFBWSxHQUFHLE1BQU0sV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQzlDLElBQUksYUFBYSxHQUFHLE1BQU0sV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBRWhELE9BQU87Z0JBQ04sR0FBRyxFQUFFLFlBQVk7Z0JBQ2pCLElBQUksRUFBRSxhQUFhO2FBQ25CLENBQUM7UUFDSCxDQUFDO1FBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztZQUNkLE1BQU0sQ0FBQyxLQUFLLENBQUMsdUNBQXVDLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDM0QsTUFBTSxHQUFHLENBQUM7UUFDWCxDQUFDO0lBQ0YsQ0FBQztDQUFBO0FBRUQsZUFBZSxFQUFFLGdCQUFnQixFQUFFLFVBQVUsRUFBRSxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZXhlY1N5bmMgfSBmcm9tICdjaGlsZF9wcm9jZXNzJztcbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnO1xuaW1wb3J0IHsgX19kaXJuYW1lIH0gZnJvbSAnLi9sb2FkRW52JztcbmltcG9ydCBzZXR1cExvZ2dlciBmcm9tICcuLi9taWRkbGV3YXJlL2xvZ2dlcic7XG5cbmFzeW5jIGZ1bmN0aW9uIGRlY3J5cHRGaWxlKGVuY3J5cHRlZEZpbGVQYXRoOiBzdHJpbmcpIHtcblx0bGV0IGxvZ2dlciA9IGF3YWl0IHNldHVwTG9nZ2VyKCk7XG5cblx0dHJ5IHtcblx0XHRsZXQgZGVjcnlwdGVkRmlsZSA9IGV4ZWNTeW5jKFxuXHRcdFx0YHNvcHMgLWQgLS1vdXRwdXQtdHlwZSBqc29uICR7ZW5jcnlwdGVkRmlsZVBhdGh9YFxuXHRcdCkudG9TdHJpbmcoKTtcblx0XHRyZXR1cm4gZGVjcnlwdGVkRmlsZTtcblx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0bG9nZ2VyLmVycm9yKCdFcnJvciBkZWNyeXB0aW5nIGZpbGUgZnJvbSBTT1BTOiAnLCBlcnIpO1xuXHRcdHRocm93IGVycjtcblx0fVxufVxuXG5hc3luYyBmdW5jdGlvbiBkZWNyeXB0RGF0YUZpbGVzKCkge1xuXHRsZXQgbG9nZ2VyID0gYXdhaXQgc2V0dXBMb2dnZXIoKTtcblxuXHR0cnkge1xuXHRcdGxldCBmaWxlUGF0aHMgPSBbXG5cdFx0XHRwcm9jZXNzLmVudi5TRVJWRVJfREFUQV9GSUxFX1BBVEhfMSxcblx0XHRcdHByb2Nlc3MuZW52LlNFUlZFUl9EQVRBX0ZJTEVfUEFUSF8yLFxuXHRcdFx0cHJvY2Vzcy5lbnYuU0VSVkVSX0RBVEFfRklMRV9QQVRIXzMsXG5cdFx0XHRwcm9jZXNzLmVudi5TRVJWRVJfREFUQV9GSUxFX1BBVEhfNFxuXHRcdF07XG5cblx0XHRsZXQgZGVjcnlwdGVkRmlsZXM6IHsgW2tleTogc3RyaW5nXTogc3RyaW5nIH0gPSB7fTtcblxuXHRcdGZvciAobGV0IFtpbmRleCwgZmlsZVBhdGhdIG9mIGZpbGVQYXRocy5lbnRyaWVzKCkpIHtcblx0XHRcdGlmIChmaWxlUGF0aCkge1xuXHRcdFx0XHRkZWNyeXB0ZWRGaWxlc1tgZmlsZXMke2luZGV4ICsgMX1gXSA9IGV4ZWNTeW5jKFxuXHRcdFx0XHRcdGBzb3BzIC1kIC0tb3V0cHV0LXR5cGUganNvbiAke2ZpbGVQYXRofWBcblx0XHRcdFx0KS50b1N0cmluZygpO1xuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0bG9nZ2VyLndhcm4oXG5cdFx0XHRcdFx0YFNFUlZFUl9EQVRBX0ZJTEVfUEFUSF8ke2luZGV4ICsgMX0gaXMgbm90IGRlZmluZWRgXG5cdFx0XHRcdCk7XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0cmV0dXJuIGRlY3J5cHRlZEZpbGVzO1xuXHR9IGNhdGNoIChlcnIpIHtcblx0XHRsb2dnZXIuZXJyb3IoJ0Vycm9yIGRlY3J5cHRpbmcgZmlsZXMgZnJvbSBiYWNrZW5kIGRhdGEgZm9sZGVyOiAnLCBlcnIpO1xuXHRcdHRocm93IGVycjtcblx0fVxufVxuXG5hc3luYyBmdW5jdGlvbiBnZXRTU0xLZXlzKCkge1xuXHRsZXQgbG9nZ2VyID0gYXdhaXQgc2V0dXBMb2dnZXIoKTtcblxuXHR0cnkge1xuXHRcdGxldCBrZXlQYXRoID0gcGF0aC5qb2luKF9fZGlybmFtZSwgJy4va2V5cy9zc2wvZ3Vlc3Rib29rX2tleS5wZW0uZ3BnJyk7XG5cdFx0bGV0IGNlcnRQYXRoID0gcGF0aC5qb2luKFxuXHRcdFx0X19kaXJuYW1lLFxuXHRcdFx0Jy4va2V5cy9zc2wvZ3Vlc3Rib29rX2NlcnQucGVtLmdwZydcblx0XHQpO1xuXHRcdGxldCBkZWNyeXB0ZWRLZXkgPSBhd2FpdCBkZWNyeXB0RmlsZShrZXlQYXRoKTtcblx0XHRsZXQgZGVjcnlwdGVkQ2VydCA9IGF3YWl0IGRlY3J5cHRGaWxlKGNlcnRQYXRoKTtcblxuXHRcdHJldHVybiB7XG5cdFx0XHRrZXk6IGRlY3J5cHRlZEtleSxcblx0XHRcdGNlcnQ6IGRlY3J5cHRlZENlcnRcblx0XHR9O1xuXHR9IGNhdGNoIChlcnIpIHtcblx0XHRsb2dnZXIuZXJyb3IoJ0Vycm9yIHJldHJpZXZpbmcgU1NMIGtleXMgZnJvbSBTT1BTOiAnLCBlcnIpO1xuXHRcdHRocm93IGVycjtcblx0fVxufVxuXG5leHBvcnQgZGVmYXVsdCB7IGRlY3J5cHREYXRhRmlsZXMsIGdldFNTTEtleXMgfTtcbiJdfQ==