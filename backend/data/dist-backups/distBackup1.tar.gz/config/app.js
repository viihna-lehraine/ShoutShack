import { __awaiter } from "tslib";
import express from 'express';
import bodyParser from 'body-parser';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import hpp from 'hpp';
import morgan from 'morgan';
import passport from 'passport';
import { randomBytes } from 'crypto';
import path from 'path';
import initializeStaticRoutes from '../routes/staticRoutes.js';
import apiRoutes from '../routes/apiRoutes.js';
import { csrfMiddleware, ipBlacklistMiddleware, loadTestRoutes, rateLimitMiddleware, setupSecurityHeaders } from '../index.js';
import setupLogger from '../middleware/logger.js';
const app = express();
const staticRootPath = process.env.STATIC_ROOT_PATH;
function initializeApp() {
    return __awaiter(this, void 0, void 0, function* () {
        const logger = yield setupLogger();
        // Set up middlewares
        app.use(bodyParser.json());
        app.use(express.urlencoded({ extended: true }));
        app.use(cors({
            methods: 'GET,POST,PUT,DELETE',
            allowedHeaders: 'Content-Type,Authorization',
            credentials: true
        }));
        app.use(hpp());
        app.use(morgan('combined', {
            stream: { write: (message) => logger.info(message.trim()) }
        }));
        app.use(passport.initialize());
        app.use(cookieParser());
        app.use(express.static(staticRootPath));
        // Initialize routes
        app.use('/', initializeStaticRoutes);
        app.use('/api', apiRoutes);
        app.use(rateLimitMiddleware);
        app.use(ipBlacklistMiddleware);
        app.use(csrfMiddleware);
        // Generate nonce for each request
        app.use((req, res, next) => {
            res.locals.cspNonce = randomBytes(16).toString('hex');
            next();
        });
        // Set up security headers
        setupSecurityHeaders(app);
        // Load test routes
        loadTestRoutes(app);
        // Session management
        // app.use(session({
        //     store: new RedisStore({ client: redisClient }),
        //     secret: 'secrets.REDIS_KEY',
        //     resave: false,
        //     saveUninitialized: false,
        //     cookie: { secure: true },
        // }));
        // Apply Sentry middleware for request and error handling
        // app.use(Sentry.RequestHandlers.requestHandler());
        // app.use(Sentry.Handlers.errorHandler());
        // 404 error handling
        app.use((req, res, next) => {
            res.status(404).sendFile(path.join(__dirname, '../public', 'not-found.html'));
            next();
        });
        // General error handling
        app.use((err, req, res, next) => {
            logger.error('Error occurred: ', err.stack || err.message || err);
            res.status(500).send(`Server error - something failed ${err.stack}`);
            next();
        });
    });
}
export { app, initializeApp };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL2NvbmZpZy9hcHAudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sT0FBTyxNQUFNLFNBQVMsQ0FBQztBQUU5QixPQUFPLFVBQVUsTUFBTSxhQUFhLENBQUM7QUFDckMsT0FBTyxZQUFZLE1BQU0sZUFBZSxDQUFDO0FBQ3pDLE9BQU8sSUFBSSxNQUFNLE1BQU0sQ0FBQztBQUN4QixPQUFPLEdBQUcsTUFBTSxLQUFLLENBQUM7QUFDdEIsT0FBTyxNQUFNLE1BQU0sUUFBUSxDQUFDO0FBQzVCLE9BQU8sUUFBUSxNQUFNLFVBQVUsQ0FBQztBQUNoQyxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0sUUFBUSxDQUFDO0FBQ3JDLE9BQU8sSUFBSSxNQUFNLE1BQU0sQ0FBQztBQUN4QixPQUFPLHNCQUFzQixNQUFNLHdCQUF3QixDQUFDO0FBQzVELE9BQU8sU0FBUyxNQUFNLHFCQUFxQixDQUFDO0FBQzVDLE9BQU8sRUFDTixjQUFjLEVBQ2QscUJBQXFCLEVBQ3JCLGNBQWMsRUFDZCxtQkFBbUIsRUFDbkIsb0JBQW9CLEVBQ3BCLE1BQU0sVUFBVSxDQUFDO0FBQ2xCLE9BQU8sV0FBVyxNQUFNLHNCQUFzQixDQUFDO0FBRS9DLE1BQU0sR0FBRyxHQUFHLE9BQU8sRUFBRSxDQUFDO0FBQ3RCLE1BQU0sY0FBYyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWlCLENBQUM7QUFFckQsU0FBZSxhQUFhOztRQUMzQixNQUFNLE1BQU0sR0FBRyxNQUFNLFdBQVcsRUFBRSxDQUFDO1FBRW5DLHFCQUFxQjtRQUNyQixHQUFHLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDO1FBQzNCLEdBQUcsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDaEQsR0FBRyxDQUFDLEdBQUcsQ0FDTixJQUFJLENBQUM7WUFDSixPQUFPLEVBQUUscUJBQXFCO1lBQzlCLGNBQWMsRUFBRSw0QkFBNEI7WUFDNUMsV0FBVyxFQUFFLElBQUk7U0FDakIsQ0FBQyxDQUNGLENBQUM7UUFDRixHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7UUFDZixHQUFHLENBQUMsR0FBRyxDQUNOLE1BQU0sQ0FBQyxVQUFVLEVBQUU7WUFDbEIsTUFBTSxFQUFFLEVBQUUsS0FBSyxFQUFFLENBQUMsT0FBTyxFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxFQUFFO1NBQzNELENBQUMsQ0FDRixDQUFDO1FBQ0YsR0FBRyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQztRQUMvQixHQUFHLENBQUMsR0FBRyxDQUFDLFlBQVksRUFBRSxDQUFDLENBQUM7UUFDeEIsR0FBRyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUM7UUFFeEMsb0JBQW9CO1FBQ3BCLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLHNCQUFzQixDQUFDLENBQUM7UUFDckMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFDM0IsR0FBRyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1FBQzdCLEdBQUcsQ0FBQyxHQUFHLENBQUMscUJBQXFCLENBQUMsQ0FBQztRQUMvQixHQUFHLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxDQUFDO1FBRXhCLGtDQUFrQztRQUNsQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBWSxFQUFFLEdBQWEsRUFBRSxJQUFrQixFQUFFLEVBQUU7WUFDM0QsR0FBRyxDQUFDLE1BQU0sQ0FBQyxRQUFRLEdBQUcsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUN0RCxJQUFJLEVBQUUsQ0FBQztRQUNSLENBQUMsQ0FBQyxDQUFDO1FBRUgsMEJBQTBCO1FBQzFCLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRTFCLG1CQUFtQjtRQUNuQixjQUFjLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFcEIscUJBQXFCO1FBQ3JCLG9CQUFvQjtRQUNwQixzREFBc0Q7UUFDdEQsbUNBQW1DO1FBQ25DLHFCQUFxQjtRQUNyQixnQ0FBZ0M7UUFDaEMsZ0NBQWdDO1FBQ2hDLE9BQU87UUFFUCx5REFBeUQ7UUFDekQsb0RBQW9EO1FBQ3BELDJDQUEyQztRQUUzQyxxQkFBcUI7UUFDckIsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQVksRUFBRSxHQUFhLEVBQUUsSUFBa0IsRUFBRSxFQUFFO1lBQzNELEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUN2QixJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxXQUFXLEVBQUUsZ0JBQWdCLENBQUMsQ0FDbkQsQ0FBQztZQUNGLElBQUksRUFBRSxDQUFDO1FBQ1IsQ0FBQyxDQUFDLENBQUM7UUFFSCx5QkFBeUI7UUFDekIsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQVUsRUFBRSxHQUFZLEVBQUUsR0FBYSxFQUFFLElBQWtCLEVBQUUsRUFBRTtZQUN2RSxNQUFNLENBQUMsS0FBSyxDQUFDLGtCQUFrQixFQUFFLEdBQUcsQ0FBQyxLQUFLLElBQUksR0FBRyxDQUFDLE9BQU8sSUFBSSxHQUFHLENBQUMsQ0FBQztZQUNsRSxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxtQ0FBbUMsR0FBRyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUM7WUFDckUsSUFBSSxFQUFFLENBQUM7UUFDUixDQUFDLENBQUMsQ0FBQztJQUNKLENBQUM7Q0FBQTtBQUVELE9BQU8sRUFBRSxHQUFHLEVBQUUsYUFBYSxFQUFFLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgZXhwcmVzcyBmcm9tICdleHByZXNzJztcbmltcG9ydCB7IFJlcXVlc3QsIFJlc3BvbnNlLCBOZXh0RnVuY3Rpb24gfSBmcm9tICdleHByZXNzJztcbmltcG9ydCBib2R5UGFyc2VyIGZyb20gJ2JvZHktcGFyc2VyJztcbmltcG9ydCBjb29raWVQYXJzZXIgZnJvbSAnY29va2llLXBhcnNlcic7XG5pbXBvcnQgY29ycyBmcm9tICdjb3JzJztcbmltcG9ydCBocHAgZnJvbSAnaHBwJztcbmltcG9ydCBtb3JnYW4gZnJvbSAnbW9yZ2FuJztcbmltcG9ydCBwYXNzcG9ydCBmcm9tICdwYXNzcG9ydCc7XG5pbXBvcnQgeyByYW5kb21CeXRlcyB9IGZyb20gJ2NyeXB0byc7XG5pbXBvcnQgcGF0aCBmcm9tICdwYXRoJztcbmltcG9ydCBpbml0aWFsaXplU3RhdGljUm91dGVzIGZyb20gJy4uL3JvdXRlcy9zdGF0aWNSb3V0ZXMnO1xuaW1wb3J0IGFwaVJvdXRlcyBmcm9tICcuLi9yb3V0ZXMvYXBpUm91dGVzJztcbmltcG9ydCB7XG5cdGNzcmZNaWRkbGV3YXJlLFxuXHRpcEJsYWNrbGlzdE1pZGRsZXdhcmUsXG5cdGxvYWRUZXN0Um91dGVzLFxuXHRyYXRlTGltaXRNaWRkbGV3YXJlLFxuXHRzZXR1cFNlY3VyaXR5SGVhZGVyc1xufSBmcm9tICcuLi9pbmRleCc7XG5pbXBvcnQgc2V0dXBMb2dnZXIgZnJvbSAnLi4vbWlkZGxld2FyZS9sb2dnZXInO1xuXG5jb25zdCBhcHAgPSBleHByZXNzKCk7XG5jb25zdCBzdGF0aWNSb290UGF0aCA9IHByb2Nlc3MuZW52LlNUQVRJQ19ST09UX1BBVEghO1xuXG5hc3luYyBmdW5jdGlvbiBpbml0aWFsaXplQXBwKCk6IFByb21pc2U8dm9pZD4ge1xuXHRjb25zdCBsb2dnZXIgPSBhd2FpdCBzZXR1cExvZ2dlcigpO1xuXG5cdC8vIFNldCB1cCBtaWRkbGV3YXJlc1xuXHRhcHAudXNlKGJvZHlQYXJzZXIuanNvbigpKTtcblx0YXBwLnVzZShleHByZXNzLnVybGVuY29kZWQoeyBleHRlbmRlZDogdHJ1ZSB9KSk7XG5cdGFwcC51c2UoXG5cdFx0Y29ycyh7XG5cdFx0XHRtZXRob2RzOiAnR0VULFBPU1QsUFVULERFTEVURScsXG5cdFx0XHRhbGxvd2VkSGVhZGVyczogJ0NvbnRlbnQtVHlwZSxBdXRob3JpemF0aW9uJyxcblx0XHRcdGNyZWRlbnRpYWxzOiB0cnVlXG5cdFx0fSlcblx0KTtcblx0YXBwLnVzZShocHAoKSk7XG5cdGFwcC51c2UoXG5cdFx0bW9yZ2FuKCdjb21iaW5lZCcsIHtcblx0XHRcdHN0cmVhbTogeyB3cml0ZTogKG1lc3NhZ2UpID0+IGxvZ2dlci5pbmZvKG1lc3NhZ2UudHJpbSgpKSB9XG5cdFx0fSlcblx0KTtcblx0YXBwLnVzZShwYXNzcG9ydC5pbml0aWFsaXplKCkpO1xuXHRhcHAudXNlKGNvb2tpZVBhcnNlcigpKTtcblx0YXBwLnVzZShleHByZXNzLnN0YXRpYyhzdGF0aWNSb290UGF0aCkpO1xuXG5cdC8vIEluaXRpYWxpemUgcm91dGVzXG5cdGFwcC51c2UoJy8nLCBpbml0aWFsaXplU3RhdGljUm91dGVzKTtcblx0YXBwLnVzZSgnL2FwaScsIGFwaVJvdXRlcyk7XG5cdGFwcC51c2UocmF0ZUxpbWl0TWlkZGxld2FyZSk7XG5cdGFwcC51c2UoaXBCbGFja2xpc3RNaWRkbGV3YXJlKTtcblx0YXBwLnVzZShjc3JmTWlkZGxld2FyZSk7XG5cblx0Ly8gR2VuZXJhdGUgbm9uY2UgZm9yIGVhY2ggcmVxdWVzdFxuXHRhcHAudXNlKChyZXE6IFJlcXVlc3QsIHJlczogUmVzcG9uc2UsIG5leHQ6IE5leHRGdW5jdGlvbikgPT4ge1xuXHRcdHJlcy5sb2NhbHMuY3NwTm9uY2UgPSByYW5kb21CeXRlcygxNikudG9TdHJpbmcoJ2hleCcpO1xuXHRcdG5leHQoKTtcblx0fSk7XG5cblx0Ly8gU2V0IHVwIHNlY3VyaXR5IGhlYWRlcnNcblx0c2V0dXBTZWN1cml0eUhlYWRlcnMoYXBwKTtcblxuXHQvLyBMb2FkIHRlc3Qgcm91dGVzXG5cdGxvYWRUZXN0Um91dGVzKGFwcCk7XG5cblx0Ly8gU2Vzc2lvbiBtYW5hZ2VtZW50XG5cdC8vIGFwcC51c2Uoc2Vzc2lvbih7XG5cdC8vICAgICBzdG9yZTogbmV3IFJlZGlzU3RvcmUoeyBjbGllbnQ6IHJlZGlzQ2xpZW50IH0pLFxuXHQvLyAgICAgc2VjcmV0OiAnc2VjcmV0cy5SRURJU19LRVknLFxuXHQvLyAgICAgcmVzYXZlOiBmYWxzZSxcblx0Ly8gICAgIHNhdmVVbmluaXRpYWxpemVkOiBmYWxzZSxcblx0Ly8gICAgIGNvb2tpZTogeyBzZWN1cmU6IHRydWUgfSxcblx0Ly8gfSkpO1xuXG5cdC8vIEFwcGx5IFNlbnRyeSBtaWRkbGV3YXJlIGZvciByZXF1ZXN0IGFuZCBlcnJvciBoYW5kbGluZ1xuXHQvLyBhcHAudXNlKFNlbnRyeS5SZXF1ZXN0SGFuZGxlcnMucmVxdWVzdEhhbmRsZXIoKSk7XG5cdC8vIGFwcC51c2UoU2VudHJ5LkhhbmRsZXJzLmVycm9ySGFuZGxlcigpKTtcblxuXHQvLyA0MDQgZXJyb3IgaGFuZGxpbmdcblx0YXBwLnVzZSgocmVxOiBSZXF1ZXN0LCByZXM6IFJlc3BvbnNlLCBuZXh0OiBOZXh0RnVuY3Rpb24pID0+IHtcblx0XHRyZXMuc3RhdHVzKDQwNCkuc2VuZEZpbGUoXG5cdFx0XHRwYXRoLmpvaW4oX19kaXJuYW1lLCAnLi4vcHVibGljJywgJ25vdC1mb3VuZC5odG1sJylcblx0XHQpO1xuXHRcdG5leHQoKTtcblx0fSk7XG5cblx0Ly8gR2VuZXJhbCBlcnJvciBoYW5kbGluZ1xuXHRhcHAudXNlKChlcnI6IEVycm9yLCByZXE6IFJlcXVlc3QsIHJlczogUmVzcG9uc2UsIG5leHQ6IE5leHRGdW5jdGlvbikgPT4ge1xuXHRcdGxvZ2dlci5lcnJvcignRXJyb3Igb2NjdXJyZWQ6ICcsIGVyci5zdGFjayB8fCBlcnIubWVzc2FnZSB8fCBlcnIpO1xuXHRcdHJlcy5zdGF0dXMoNTAwKS5zZW5kKGBTZXJ2ZXIgZXJyb3IgLSBzb21ldGhpbmcgZmFpbGVkICR7ZXJyLnN0YWNrfWApO1xuXHRcdG5leHQoKTtcblx0fSk7XG59XG5cbmV4cG9ydCB7IGFwcCwgaW5pdGlhbGl6ZUFwcCB9O1xuIl19