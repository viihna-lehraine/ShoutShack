import { __awaiter } from "tslib";
import express from 'express';
import { constants } from 'crypto';
import http2 from 'http2';
import createHttp2ExpressBridge from 'http2-express-bridge';
import https from 'https';
import featureFlags from './featureFlags.js';
import setupLogger from '../middleware/logger.js';
import sops from './sops.js';
export function setupHttp(app) {
    return __awaiter(this, void 0, void 0, function* () {
        console.log('setupHttp() executing');
        let logger = yield setupLogger();
        let sslKeys = yield sops.getSSLKeys();
        // Define global SSL options
        let options = {
            key: sslKeys.key,
            cert: sslKeys.cert,
            allowHTTP1: true,
            secureOptions: constants.SSL_OP_NO_TLSv1 | constants.SSL_OP_NO_TLSv1_1,
            ciphers: [
                'ECDHE-ECDSA-AES256-GCM-SHA384',
                'ECDHE-RSA-AES256-GCM-SHA384',
                'ECDHE-ECDSA-CHACHA20-POLY1305',
                'ECDHE-RSA-CHACHA20-POLY1305',
                'ECDHE-ECDSA-AES128-GCM-SHA256',
                'ECDHE-RSA-AES128-GCM-SHA256',
                'ECDHE-ECDSA-AES256-SHA384',
                'ECDHE-RSA-AES256-SHA384',
                'ECDHE-ECDSA-AES128-SHA256',
                'ECDHE-RSA-AES128-SHA256'
            ].join(':'),
            honorCipherOrder: true
        };
        function startHttp1Server() {
            return __awaiter(this, void 0, void 0, function* () {
                logger.info('Starting HTTP1.1 server');
                logger.info('Server port: ', process.env.SERVER_PORT);
                https.createServer(options, app).listen(process.env.SERVER_PORT, () => {
                    logger.info(`HTTP1.1 server running on port ${process.env.SERVER_PORT}`);
                });
            });
        }
        function startHttp2Server() {
            return __awaiter(this, void 0, void 0, function* () {
                let http2App = createHttp2ExpressBridge(express);
                // Use the existing Express app as middleware for the HTTP2-compatible app
                http2App.use(app);
                try {
                    http2
                        .createSecureServer(options, http2App)
                        .listen(process.env.SERVER_PORT, () => {
                        logger.info(`HTTP2 server running on port ${process.env.SERVER_PORT}`);
                    });
                }
                catch (err) {
                    logger.error('Error starting HTTP2 server: ', err);
                    throw err;
                }
            });
        }
        function startServer() {
            return __awaiter(this, void 0, void 0, function* () {
                if (featureFlags.http1Flag) {
                    yield startHttp1Server();
                }
                else if (featureFlags.http2Flag) {
                    yield startHttp2Server();
                }
                else {
                    logger.error('Please set one of the HTTP flags to true in the .env file');
                    throw new Error('Please set one of the HTTP flags to true in the .env file');
                }
            });
        }
        return { startServer };
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaHR0cC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9jb25maWcvaHR0cC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxPQUF3QixNQUFNLFNBQVMsQ0FBQztBQUMvQyxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sUUFBUSxDQUFDO0FBQ25DLE9BQU8sS0FBSyxNQUFNLE9BQU8sQ0FBQztBQUMxQixPQUFPLHdCQUF3QixNQUFNLHNCQUFzQixDQUFDO0FBQzVELE9BQU8sS0FBSyxNQUFNLE9BQU8sQ0FBQztBQUMxQixPQUFPLFlBQVksTUFBTSxnQkFBZ0IsQ0FBQztBQUMxQyxPQUFPLFdBQVcsTUFBTSxzQkFBc0IsQ0FBQztBQUMvQyxPQUFPLElBQUksTUFBTSxRQUFRLENBQUM7QUFFMUIsTUFBTSxVQUFnQixTQUFTLENBQUMsR0FBZ0I7O1FBQy9DLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLENBQUMsQ0FBQztRQUNyQyxJQUFJLE1BQU0sR0FBRyxNQUFNLFdBQVcsRUFBRSxDQUFDO1FBQ2pDLElBQUksT0FBTyxHQUFHLE1BQU0sSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBRXRDLDRCQUE0QjtRQUM1QixJQUFJLE9BQU8sR0FBRztZQUNiLEdBQUcsRUFBRSxPQUFPLENBQUMsR0FBRztZQUNoQixJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUk7WUFDbEIsVUFBVSxFQUFFLElBQUk7WUFDaEIsYUFBYSxFQUFFLFNBQVMsQ0FBQyxlQUFlLEdBQUcsU0FBUyxDQUFDLGlCQUFpQjtZQUN0RSxPQUFPLEVBQUU7Z0JBQ1IsK0JBQStCO2dCQUMvQiw2QkFBNkI7Z0JBQzdCLCtCQUErQjtnQkFDL0IsNkJBQTZCO2dCQUM3QiwrQkFBK0I7Z0JBQy9CLDZCQUE2QjtnQkFDN0IsMkJBQTJCO2dCQUMzQix5QkFBeUI7Z0JBQ3pCLDJCQUEyQjtnQkFDM0IseUJBQXlCO2FBQ3pCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztZQUNYLGdCQUFnQixFQUFFLElBQUk7U0FDdEIsQ0FBQztRQUVGLFNBQWUsZ0JBQWdCOztnQkFDOUIsTUFBTSxDQUFDLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO2dCQUN2QyxNQUFNLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUV0RCxLQUFLLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsR0FBRyxFQUFFO29CQUNyRSxNQUFNLENBQUMsSUFBSSxDQUNWLGtDQUFrQyxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUMzRCxDQUFDO2dCQUNILENBQUMsQ0FBQyxDQUFDO1lBQ0osQ0FBQztTQUFBO1FBRUQsU0FBZSxnQkFBZ0I7O2dCQUM5QixJQUFJLFFBQVEsR0FBRyx3QkFBd0IsQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFFakQsMEVBQTBFO2dCQUMxRSxRQUFRLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUVsQixJQUFJLENBQUM7b0JBQ0osS0FBSzt5QkFDSCxrQkFBa0IsQ0FBQyxPQUFPLEVBQUUsUUFBUSxDQUFDO3lCQUNyQyxNQUFNLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsR0FBRyxFQUFFO3dCQUNyQyxNQUFNLENBQUMsSUFBSSxDQUNWLGdDQUFnQyxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUN6RCxDQUFDO29CQUNILENBQUMsQ0FBQyxDQUFDO2dCQUNMLENBQUM7Z0JBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztvQkFDZCxNQUFNLENBQUMsS0FBSyxDQUFDLCtCQUErQixFQUFFLEdBQUcsQ0FBQyxDQUFDO29CQUNuRCxNQUFNLEdBQUcsQ0FBQztnQkFDWCxDQUFDO1lBQ0YsQ0FBQztTQUFBO1FBRUQsU0FBZSxXQUFXOztnQkFDekIsSUFBSSxZQUFZLENBQUMsU0FBUyxFQUFFLENBQUM7b0JBQzVCLE1BQU0sZ0JBQWdCLEVBQUUsQ0FBQztnQkFDMUIsQ0FBQztxQkFBTSxJQUFJLFlBQVksQ0FBQyxTQUFTLEVBQUUsQ0FBQztvQkFDbkMsTUFBTSxnQkFBZ0IsRUFBRSxDQUFDO2dCQUMxQixDQUFDO3FCQUFNLENBQUM7b0JBQ1AsTUFBTSxDQUFDLEtBQUssQ0FDWCwyREFBMkQsQ0FDM0QsQ0FBQztvQkFDRixNQUFNLElBQUksS0FBSyxDQUNkLDJEQUEyRCxDQUMzRCxDQUFDO2dCQUNILENBQUM7WUFDRixDQUFDO1NBQUE7UUFFRCxPQUFPLEVBQUUsV0FBVyxFQUFFLENBQUM7SUFDeEIsQ0FBQztDQUFBIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGV4cHJlc3MsIHsgQXBwbGljYXRpb24gfSBmcm9tICdleHByZXNzJztcbmltcG9ydCB7IGNvbnN0YW50cyB9IGZyb20gJ2NyeXB0byc7XG5pbXBvcnQgaHR0cDIgZnJvbSAnaHR0cDInO1xuaW1wb3J0IGNyZWF0ZUh0dHAyRXhwcmVzc0JyaWRnZSBmcm9tICdodHRwMi1leHByZXNzLWJyaWRnZSc7XG5pbXBvcnQgaHR0cHMgZnJvbSAnaHR0cHMnO1xuaW1wb3J0IGZlYXR1cmVGbGFncyBmcm9tICcuL2ZlYXR1cmVGbGFncyc7XG5pbXBvcnQgc2V0dXBMb2dnZXIgZnJvbSAnLi4vbWlkZGxld2FyZS9sb2dnZXInO1xuaW1wb3J0IHNvcHMgZnJvbSAnLi9zb3BzJztcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldHVwSHR0cChhcHA6IEFwcGxpY2F0aW9uKSB7XG5cdGNvbnNvbGUubG9nKCdzZXR1cEh0dHAoKSBleGVjdXRpbmcnKTtcblx0bGV0IGxvZ2dlciA9IGF3YWl0IHNldHVwTG9nZ2VyKCk7XG5cdGxldCBzc2xLZXlzID0gYXdhaXQgc29wcy5nZXRTU0xLZXlzKCk7XG5cblx0Ly8gRGVmaW5lIGdsb2JhbCBTU0wgb3B0aW9uc1xuXHRsZXQgb3B0aW9ucyA9IHtcblx0XHRrZXk6IHNzbEtleXMua2V5LFxuXHRcdGNlcnQ6IHNzbEtleXMuY2VydCxcblx0XHRhbGxvd0hUVFAxOiB0cnVlLFxuXHRcdHNlY3VyZU9wdGlvbnM6IGNvbnN0YW50cy5TU0xfT1BfTk9fVExTdjEgfCBjb25zdGFudHMuU1NMX09QX05PX1RMU3YxXzEsXG5cdFx0Y2lwaGVyczogW1xuXHRcdFx0J0VDREhFLUVDRFNBLUFFUzI1Ni1HQ00tU0hBMzg0Jyxcblx0XHRcdCdFQ0RIRS1SU0EtQUVTMjU2LUdDTS1TSEEzODQnLFxuXHRcdFx0J0VDREhFLUVDRFNBLUNIQUNIQTIwLVBPTFkxMzA1Jyxcblx0XHRcdCdFQ0RIRS1SU0EtQ0hBQ0hBMjAtUE9MWTEzMDUnLFxuXHRcdFx0J0VDREhFLUVDRFNBLUFFUzEyOC1HQ00tU0hBMjU2Jyxcblx0XHRcdCdFQ0RIRS1SU0EtQUVTMTI4LUdDTS1TSEEyNTYnLFxuXHRcdFx0J0VDREhFLUVDRFNBLUFFUzI1Ni1TSEEzODQnLFxuXHRcdFx0J0VDREhFLVJTQS1BRVMyNTYtU0hBMzg0Jyxcblx0XHRcdCdFQ0RIRS1FQ0RTQS1BRVMxMjgtU0hBMjU2Jyxcblx0XHRcdCdFQ0RIRS1SU0EtQUVTMTI4LVNIQTI1Nidcblx0XHRdLmpvaW4oJzonKSxcblx0XHRob25vckNpcGhlck9yZGVyOiB0cnVlXG5cdH07XG5cblx0YXN5bmMgZnVuY3Rpb24gc3RhcnRIdHRwMVNlcnZlcigpIHtcblx0XHRsb2dnZXIuaW5mbygnU3RhcnRpbmcgSFRUUDEuMSBzZXJ2ZXInKTtcblx0XHRsb2dnZXIuaW5mbygnU2VydmVyIHBvcnQ6ICcsIHByb2Nlc3MuZW52LlNFUlZFUl9QT1JUKTtcblxuXHRcdGh0dHBzLmNyZWF0ZVNlcnZlcihvcHRpb25zLCBhcHApLmxpc3Rlbihwcm9jZXNzLmVudi5TRVJWRVJfUE9SVCwgKCkgPT4ge1xuXHRcdFx0bG9nZ2VyLmluZm8oXG5cdFx0XHRcdGBIVFRQMS4xIHNlcnZlciBydW5uaW5nIG9uIHBvcnQgJHtwcm9jZXNzLmVudi5TRVJWRVJfUE9SVH1gXG5cdFx0XHQpO1xuXHRcdH0pO1xuXHR9XG5cblx0YXN5bmMgZnVuY3Rpb24gc3RhcnRIdHRwMlNlcnZlcigpIHtcblx0XHRsZXQgaHR0cDJBcHAgPSBjcmVhdGVIdHRwMkV4cHJlc3NCcmlkZ2UoZXhwcmVzcyk7XG5cblx0XHQvLyBVc2UgdGhlIGV4aXN0aW5nIEV4cHJlc3MgYXBwIGFzIG1pZGRsZXdhcmUgZm9yIHRoZSBIVFRQMi1jb21wYXRpYmxlIGFwcFxuXHRcdGh0dHAyQXBwLnVzZShhcHApO1xuXG5cdFx0dHJ5IHtcblx0XHRcdGh0dHAyXG5cdFx0XHRcdC5jcmVhdGVTZWN1cmVTZXJ2ZXIob3B0aW9ucywgaHR0cDJBcHApXG5cdFx0XHRcdC5saXN0ZW4ocHJvY2Vzcy5lbnYuU0VSVkVSX1BPUlQsICgpID0+IHtcblx0XHRcdFx0XHRsb2dnZXIuaW5mbyhcblx0XHRcdFx0XHRcdGBIVFRQMiBzZXJ2ZXIgcnVubmluZyBvbiBwb3J0ICR7cHJvY2Vzcy5lbnYuU0VSVkVSX1BPUlR9YFxuXHRcdFx0XHRcdCk7XG5cdFx0XHRcdH0pO1xuXHRcdH0gY2F0Y2ggKGVycikge1xuXHRcdFx0bG9nZ2VyLmVycm9yKCdFcnJvciBzdGFydGluZyBIVFRQMiBzZXJ2ZXI6ICcsIGVycik7XG5cdFx0XHR0aHJvdyBlcnI7XG5cdFx0fVxuXHR9XG5cblx0YXN5bmMgZnVuY3Rpb24gc3RhcnRTZXJ2ZXIoKSB7XG5cdFx0aWYgKGZlYXR1cmVGbGFncy5odHRwMUZsYWcpIHtcblx0XHRcdGF3YWl0IHN0YXJ0SHR0cDFTZXJ2ZXIoKTtcblx0XHR9IGVsc2UgaWYgKGZlYXR1cmVGbGFncy5odHRwMkZsYWcpIHtcblx0XHRcdGF3YWl0IHN0YXJ0SHR0cDJTZXJ2ZXIoKTtcblx0XHR9IGVsc2Uge1xuXHRcdFx0bG9nZ2VyLmVycm9yKFxuXHRcdFx0XHQnUGxlYXNlIHNldCBvbmUgb2YgdGhlIEhUVFAgZmxhZ3MgdG8gdHJ1ZSBpbiB0aGUgLmVudiBmaWxlJ1xuXHRcdFx0KTtcblx0XHRcdHRocm93IG5ldyBFcnJvcihcblx0XHRcdFx0J1BsZWFzZSBzZXQgb25lIG9mIHRoZSBIVFRQIGZsYWdzIHRvIHRydWUgaW4gdGhlIC5lbnYgZmlsZSdcblx0XHRcdCk7XG5cdFx0fVxuXHR9XG5cblx0cmV0dXJuIHsgc3RhcnRTZXJ2ZXIgfTtcbn1cbiJdfQ==