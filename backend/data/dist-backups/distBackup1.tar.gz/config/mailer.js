import { __awaiter } from "tslib";
import nodemailer from 'nodemailer';
import getSecrets from './secrets.js';
function createTransporter() {
    return __awaiter(this, void 0, void 0, function* () {
        let secrets = yield getSecrets();
        let transporter = nodemailer.createTransport({
            host: secrets.EMAIL_HOST,
            port: secrets.EMAIL_PORT,
            secure: secrets.EMAIL_SECURE,
            auth: {
                user: process.env.EMAIL_USER,
                pass: secrets.SMTP_TOKEN
            }
        });
        return transporter;
    });
}
let transporter = null;
function getTransporter() {
    return __awaiter(this, void 0, void 0, function* () {
        if (!transporter) {
            transporter = yield createTransporter();
        }
        return transporter;
    });
}
export { createTransporter, getTransporter };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWFpbGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL2NvbmZpZy9tYWlsZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sVUFBMkIsTUFBTSxZQUFZLENBQUM7QUFDckQsT0FBTyxVQUFVLE1BQU0sV0FBVyxDQUFDO0FBRW5DLFNBQWUsaUJBQWlCOztRQUMvQixJQUFJLE9BQU8sR0FBRyxNQUFNLFVBQVUsRUFBRSxDQUFDO1FBRWpDLElBQUksV0FBVyxHQUFHLFVBQVUsQ0FBQyxlQUFlLENBQUM7WUFDNUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxVQUFVO1lBQ3hCLElBQUksRUFBRSxPQUFPLENBQUMsVUFBVTtZQUN4QixNQUFNLEVBQUUsT0FBTyxDQUFDLFlBQVk7WUFDNUIsSUFBSSxFQUFFO2dCQUNMLElBQUksRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQW9CO2dCQUN0QyxJQUFJLEVBQUUsT0FBTyxDQUFDLFVBQVU7YUFDeEI7U0FDRCxDQUFDLENBQUM7UUFFSCxPQUFPLFdBQVcsQ0FBQztJQUNwQixDQUFDO0NBQUE7QUFFRCxJQUFJLFdBQVcsR0FBdUIsSUFBSSxDQUFDO0FBRTNDLFNBQWUsY0FBYzs7UUFDNUIsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ2xCLFdBQVcsR0FBRyxNQUFNLGlCQUFpQixFQUFFLENBQUM7UUFDekMsQ0FBQztRQUNELE9BQU8sV0FBVyxDQUFDO0lBQ3BCLENBQUM7Q0FBQTtBQUVELE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxjQUFjLEVBQUUsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBub2RlbWFpbGVyLCB7IFRyYW5zcG9ydGVyIH0gZnJvbSAnbm9kZW1haWxlcic7XG5pbXBvcnQgZ2V0U2VjcmV0cyBmcm9tICcuL3NlY3JldHMnO1xuXG5hc3luYyBmdW5jdGlvbiBjcmVhdGVUcmFuc3BvcnRlcigpOiBQcm9taXNlPFRyYW5zcG9ydGVyPiB7XG5cdGxldCBzZWNyZXRzID0gYXdhaXQgZ2V0U2VjcmV0cygpO1xuXG5cdGxldCB0cmFuc3BvcnRlciA9IG5vZGVtYWlsZXIuY3JlYXRlVHJhbnNwb3J0KHtcblx0XHRob3N0OiBzZWNyZXRzLkVNQUlMX0hPU1QsXG5cdFx0cG9ydDogc2VjcmV0cy5FTUFJTF9QT1JULFxuXHRcdHNlY3VyZTogc2VjcmV0cy5FTUFJTF9TRUNVUkUsXG5cdFx0YXV0aDoge1xuXHRcdFx0dXNlcjogcHJvY2Vzcy5lbnYuRU1BSUxfVVNFUiBhcyBzdHJpbmcsXG5cdFx0XHRwYXNzOiBzZWNyZXRzLlNNVFBfVE9LRU5cblx0XHR9XG5cdH0pO1xuXG5cdHJldHVybiB0cmFuc3BvcnRlcjtcbn1cblxubGV0IHRyYW5zcG9ydGVyOiBUcmFuc3BvcnRlciB8IG51bGwgPSBudWxsO1xuXG5hc3luYyBmdW5jdGlvbiBnZXRUcmFuc3BvcnRlcigpOiBQcm9taXNlPFRyYW5zcG9ydGVyPiB7XG5cdGlmICghdHJhbnNwb3J0ZXIpIHtcblx0XHR0cmFuc3BvcnRlciA9IGF3YWl0IGNyZWF0ZVRyYW5zcG9ydGVyKCk7XG5cdH1cblx0cmV0dXJuIHRyYW5zcG9ydGVyO1xufVxuXG5leHBvcnQgeyBjcmVhdGVUcmFuc3BvcnRlciwgZ2V0VHJhbnNwb3J0ZXIgfTtcbiJdfQ==