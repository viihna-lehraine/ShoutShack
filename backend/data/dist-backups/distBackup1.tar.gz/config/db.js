import { __awaiter } from "tslib";
import { Sequelize } from 'sequelize';
import setupLogger from '../middleware/logger.js';
import featureFlags from './featureFlags.js';
import getSecrets from './secrets.js';
let sequelize = null;
export function initializeDatabase() {
    return __awaiter(this, void 0, void 0, function* () {
        if (!sequelize) {
            let secrets = yield getSecrets();
            let logger = yield setupLogger();
            console.log('Sequelize logging is set to ', featureFlags.sequelizeLoggingFlag, ' data type: ', typeof featureFlags.sequelizeLoggingFlag);
            sequelize = new Sequelize(secrets.DB_NAME, secrets.DB_USER, secrets.DB_PASSWORD, {
                host: secrets.DB_HOST,
                dialect: secrets.DB_DIALECT,
                logging: process.env.FEATURE_SEQUELIZE_LOGGING
                    ? (msg) => logger.info(msg)
                    : false
            });
            try {
                yield sequelize.authenticate();
                logger.info('Connection has been established successfully.');
            }
            catch (error) {
                logger.error('Unable to connect to the database:', error);
                throw error;
            }
        }
        return sequelize;
    });
}
export function getSequelizeInstance() {
    if (!sequelize) {
        throw new Error('Database has not been initialized. Call initializeDatabase() first.');
    }
    return sequelize;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvY29uZmlnL2RiLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sV0FBVyxDQUFDO0FBQ3RDLE9BQU8sV0FBVyxNQUFNLHNCQUFzQixDQUFDO0FBQy9DLE9BQU8sWUFBWSxNQUFNLGdCQUFnQixDQUFDO0FBQzFDLE9BQU8sVUFBVSxNQUFNLFdBQVcsQ0FBQztBQUVuQyxJQUFJLFNBQVMsR0FBcUIsSUFBSSxDQUFDO0FBRXZDLE1BQU0sVUFBZ0Isa0JBQWtCOztRQUN2QyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDaEIsSUFBSSxPQUFPLEdBQUcsTUFBTSxVQUFVLEVBQUUsQ0FBQztZQUNqQyxJQUFJLE1BQU0sR0FBRyxNQUFNLFdBQVcsRUFBRSxDQUFDO1lBRWpDLE9BQU8sQ0FBQyxHQUFHLENBQ1YsOEJBQThCLEVBQzlCLFlBQVksQ0FBQyxvQkFBb0IsRUFDakMsY0FBYyxFQUNkLE9BQU8sWUFBWSxDQUFDLG9CQUFvQixDQUN4QyxDQUFDO1lBRUYsU0FBUyxHQUFHLElBQUksU0FBUyxDQUN4QixPQUFPLENBQUMsT0FBTyxFQUNmLE9BQU8sQ0FBQyxPQUFPLEVBQ2YsT0FBTyxDQUFDLFdBQVcsRUFDbkI7Z0JBQ0MsSUFBSSxFQUFFLE9BQU8sQ0FBQyxPQUFPO2dCQUNyQixPQUFPLEVBQUUsT0FBTyxDQUFDLFVBQVU7Z0JBQzNCLE9BQU8sRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLHlCQUF5QjtvQkFDN0MsQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztvQkFDM0IsQ0FBQyxDQUFDLEtBQUs7YUFDUixDQUNELENBQUM7WUFFRixJQUFJLENBQUM7Z0JBQ0osTUFBTSxTQUFTLENBQUMsWUFBWSxFQUFFLENBQUM7Z0JBQy9CLE1BQU0sQ0FBQyxJQUFJLENBQUMsK0NBQStDLENBQUMsQ0FBQztZQUM5RCxDQUFDO1lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztnQkFDaEIsTUFBTSxDQUFDLEtBQUssQ0FBQyxvQ0FBb0MsRUFBRSxLQUFLLENBQUMsQ0FBQztnQkFDMUQsTUFBTSxLQUFLLENBQUM7WUFDYixDQUFDO1FBQ0YsQ0FBQztRQUVELE9BQU8sU0FBUyxDQUFDO0lBQ2xCLENBQUM7Q0FBQTtBQUVELE1BQU0sVUFBVSxvQkFBb0I7SUFDbkMsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ2hCLE1BQU0sSUFBSSxLQUFLLENBQ2QscUVBQXFFLENBQ3JFLENBQUM7SUFDSCxDQUFDO0lBQ0QsT0FBTyxTQUFTLENBQUM7QUFDbEIsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFNlcXVlbGl6ZSB9IGZyb20gJ3NlcXVlbGl6ZSc7XG5pbXBvcnQgc2V0dXBMb2dnZXIgZnJvbSAnLi4vbWlkZGxld2FyZS9sb2dnZXInO1xuaW1wb3J0IGZlYXR1cmVGbGFncyBmcm9tICcuL2ZlYXR1cmVGbGFncyc7XG5pbXBvcnQgZ2V0U2VjcmV0cyBmcm9tICcuL3NlY3JldHMnO1xuXG5sZXQgc2VxdWVsaXplOiBTZXF1ZWxpemUgfCBudWxsID0gbnVsbDtcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGluaXRpYWxpemVEYXRhYmFzZSgpOiBQcm9taXNlPFNlcXVlbGl6ZT4ge1xuXHRpZiAoIXNlcXVlbGl6ZSkge1xuXHRcdGxldCBzZWNyZXRzID0gYXdhaXQgZ2V0U2VjcmV0cygpO1xuXHRcdGxldCBsb2dnZXIgPSBhd2FpdCBzZXR1cExvZ2dlcigpO1xuXG5cdFx0Y29uc29sZS5sb2coXG5cdFx0XHQnU2VxdWVsaXplIGxvZ2dpbmcgaXMgc2V0IHRvICcsXG5cdFx0XHRmZWF0dXJlRmxhZ3Muc2VxdWVsaXplTG9nZ2luZ0ZsYWcsXG5cdFx0XHQnIGRhdGEgdHlwZTogJyxcblx0XHRcdHR5cGVvZiBmZWF0dXJlRmxhZ3Muc2VxdWVsaXplTG9nZ2luZ0ZsYWdcblx0XHQpO1xuXG5cdFx0c2VxdWVsaXplID0gbmV3IFNlcXVlbGl6ZShcblx0XHRcdHNlY3JldHMuREJfTkFNRSxcblx0XHRcdHNlY3JldHMuREJfVVNFUixcblx0XHRcdHNlY3JldHMuREJfUEFTU1dPUkQsXG5cdFx0XHR7XG5cdFx0XHRcdGhvc3Q6IHNlY3JldHMuREJfSE9TVCxcblx0XHRcdFx0ZGlhbGVjdDogc2VjcmV0cy5EQl9ESUFMRUNULFxuXHRcdFx0XHRsb2dnaW5nOiBwcm9jZXNzLmVudi5GRUFUVVJFX1NFUVVFTElaRV9MT0dHSU5HXG5cdFx0XHRcdFx0PyAobXNnKSA9PiBsb2dnZXIuaW5mbyhtc2cpXG5cdFx0XHRcdFx0OiBmYWxzZVxuXHRcdFx0fVxuXHRcdCk7XG5cblx0XHR0cnkge1xuXHRcdFx0YXdhaXQgc2VxdWVsaXplLmF1dGhlbnRpY2F0ZSgpO1xuXHRcdFx0bG9nZ2VyLmluZm8oJ0Nvbm5lY3Rpb24gaGFzIGJlZW4gZXN0YWJsaXNoZWQgc3VjY2Vzc2Z1bGx5LicpO1xuXHRcdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0XHRsb2dnZXIuZXJyb3IoJ1VuYWJsZSB0byBjb25uZWN0IHRvIHRoZSBkYXRhYmFzZTonLCBlcnJvcik7XG5cdFx0XHR0aHJvdyBlcnJvcjtcblx0XHR9XG5cdH1cblxuXHRyZXR1cm4gc2VxdWVsaXplO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0U2VxdWVsaXplSW5zdGFuY2UoKTogU2VxdWVsaXplIHtcblx0aWYgKCFzZXF1ZWxpemUpIHtcblx0XHR0aHJvdyBuZXcgRXJyb3IoXG5cdFx0XHQnRGF0YWJhc2UgaGFzIG5vdCBiZWVuIGluaXRpYWxpemVkLiBDYWxsIGluaXRpYWxpemVEYXRhYmFzZSgpIGZpcnN0Lidcblx0XHQpO1xuXHR9XG5cdHJldHVybiBzZXF1ZWxpemU7XG59XG4iXX0=