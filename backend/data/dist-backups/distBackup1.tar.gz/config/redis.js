import { __awaiter } from "tslib";
import { createClient } from 'redis';
function connectRedis() {
    return __awaiter(this, void 0, void 0, function* () {
        let client = createClient({
            url: 'redis://localhost:6379'
        });
        client.on('error', (err) => {
            console.error('Redis client error:', err);
        });
        yield client.connect();
        console.log('Connected to Redis');
        yield client.set('key', 'value');
        let value = yield client.get('key');
        console.log('Key value:', value);
        return client;
    });
}
let redisClient = connectRedis();
export default redisClient;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVkaXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvY29uZmlnL3JlZGlzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sT0FBTyxDQUFDO0FBRXJDLFNBQWUsWUFBWTs7UUFDMUIsSUFBSSxNQUFNLEdBQUcsWUFBWSxDQUFDO1lBQ3pCLEdBQUcsRUFBRSx3QkFBd0I7U0FDN0IsQ0FBQyxDQUFDO1FBRUgsTUFBTSxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRTtZQUMxQixPQUFPLENBQUMsS0FBSyxDQUFDLHFCQUFxQixFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQzNDLENBQUMsQ0FBQyxDQUFDO1FBRUgsTUFBTSxNQUFNLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDdkIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1FBRWxDLE1BQU0sTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDakMsSUFBSSxLQUFLLEdBQUcsTUFBTSxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3BDLE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRWpDLE9BQU8sTUFBTSxDQUFDO0lBQ2YsQ0FBQztDQUFBO0FBRUQsSUFBSSxXQUFXLEdBQUcsWUFBWSxFQUFFLENBQUM7QUFFakMsZUFBZSxXQUFXLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tICdyZWRpcyc7XG5cbmFzeW5jIGZ1bmN0aW9uIGNvbm5lY3RSZWRpcygpIHtcblx0bGV0IGNsaWVudCA9IGNyZWF0ZUNsaWVudCh7XG5cdFx0dXJsOiAncmVkaXM6Ly9sb2NhbGhvc3Q6NjM3OSdcblx0fSk7XG5cblx0Y2xpZW50Lm9uKCdlcnJvcicsIChlcnIpID0+IHtcblx0XHRjb25zb2xlLmVycm9yKCdSZWRpcyBjbGllbnQgZXJyb3I6JywgZXJyKTtcblx0fSk7XG5cblx0YXdhaXQgY2xpZW50LmNvbm5lY3QoKTtcblx0Y29uc29sZS5sb2coJ0Nvbm5lY3RlZCB0byBSZWRpcycpO1xuXG5cdGF3YWl0IGNsaWVudC5zZXQoJ2tleScsICd2YWx1ZScpO1xuXHRsZXQgdmFsdWUgPSBhd2FpdCBjbGllbnQuZ2V0KCdrZXknKTtcblx0Y29uc29sZS5sb2coJ0tleSB2YWx1ZTonLCB2YWx1ZSk7XG5cblx0cmV0dXJuIGNsaWVudDtcbn1cblxubGV0IHJlZGlzQ2xpZW50ID0gY29ubmVjdFJlZGlzKCk7XG5cbmV4cG9ydCBkZWZhdWx0IHJlZGlzQ2xpZW50O1xuIl19