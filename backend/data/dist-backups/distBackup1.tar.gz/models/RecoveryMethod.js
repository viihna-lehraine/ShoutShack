import { Model } from 'sequelize';
class RecoveryMethod extends Model {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "id", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "isRecoveryActive", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "recoveryId", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "recoveryMethod", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "backupCodes", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "recoveryLastUpdated", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
    }
}
export default RecoveryMethod;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiUmVjb3ZlcnlNZXRob2QuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvbW9kZWxzL1JlY292ZXJ5TWV0aG9kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFJTixLQUFLLEVBQ0wsTUFBTSxXQUFXLENBQUM7QUFXbkIsTUFBTSxjQUNMLFNBQVEsS0FHUDtJQUpGOztRQU9DOzs7OztXQUFZO1FBQ1o7Ozs7O1dBQTJCO1FBQzNCOzs7OztXQUFvQjtRQUNwQjs7Ozs7V0FBeUM7UUFDekM7Ozs7O1dBQThCO1FBQzlCOzs7OztXQUE2QztJQUM5QyxDQUFDO0NBQUE7QUFFRCxlQUFlLGNBQWMsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG5cdENyZWF0aW9uT3B0aW9uYWwsXG5cdEluZmVyQXR0cmlidXRlcyxcblx0SW5mZXJDcmVhdGlvbkF0dHJpYnV0ZXMsXG5cdE1vZGVsXG59IGZyb20gJ3NlcXVlbGl6ZSc7XG5cbmludGVyZmFjZSBSZWNvdmVyeU1ldGhvZEF0dHJpYnV0ZXMge1xuXHRpZDogc3RyaW5nO1xuXHRpc1JlY292ZXJ5QWN0aXZlOiBib29sZWFuO1xuXHRyZWNvdmVyeUlkOiBzdHJpbmc7XG5cdHJlY292ZXJ5TWV0aG9kOiAnZW1haWwnIHwgJ2JhY2t1cENvZGVzJztcblx0YmFja3VwQ29kZXM/OiBzdHJpbmdbXSB8IG51bGw7XG5cdHJlY292ZXJ5TGFzdFVwZGF0ZWQ6IERhdGU7XG59XG5cbmNsYXNzIFJlY292ZXJ5TWV0aG9kXG5cdGV4dGVuZHMgTW9kZWw8XG5cdFx0SW5mZXJBdHRyaWJ1dGVzPFJlY292ZXJ5TWV0aG9kPixcblx0XHRJbmZlckNyZWF0aW9uQXR0cmlidXRlczxSZWNvdmVyeU1ldGhvZD5cblx0PlxuXHRpbXBsZW1lbnRzIFJlY292ZXJ5TWV0aG9kQXR0cmlidXRlc1xue1xuXHRpZCE6IHN0cmluZztcblx0aXNSZWNvdmVyeUFjdGl2ZSE6IGJvb2xlYW47XG5cdHJlY292ZXJ5SWQhOiBzdHJpbmc7XG5cdHJlY292ZXJ5TWV0aG9kITogJ2VtYWlsJyB8ICdiYWNrdXBDb2Rlcyc7XG5cdGJhY2t1cENvZGVzITogc3RyaW5nW10gfCBudWxsO1xuXHRyZWNvdmVyeUxhc3RVcGRhdGVkITogQ3JlYXRpb25PcHRpb25hbDxEYXRlPjtcbn1cblxuZXhwb3J0IGRlZmF1bHQgUmVjb3ZlcnlNZXRob2Q7XG4iXX0=