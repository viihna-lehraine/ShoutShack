import { Model } from 'sequelize';
class DataShareOptions extends Model {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "id", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "trackingPixelOption", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "featureUsageOption", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "pageViewsOption", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "interactionDataOption", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "deviceTypeOption", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "browserInfoOption", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "operatingSystemOption", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "randomAnonSurveyOption", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "lastUpdated", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
    }
}
export default DataShareOptions;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiRGF0YVNoYXJlT3B0aW9ucy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9tb2RlbHMvRGF0YVNoYXJlT3B0aW9ucy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQ04sS0FBSyxFQUlMLE1BQU0sV0FBVyxDQUFDO0FBZW5CLE1BQU0sZ0JBQ0wsU0FBUSxLQUdQO0lBSkY7O1FBT0M7Ozs7O1dBQVk7UUFDWjs7Ozs7V0FBOEI7UUFDOUI7Ozs7O1dBQTZCO1FBQzdCOzs7OztXQUEwQjtRQUMxQjs7Ozs7V0FBZ0M7UUFDaEM7Ozs7O1dBQTJCO1FBQzNCOzs7OztXQUE0QjtRQUM1Qjs7Ozs7V0FBZ0M7UUFDaEM7Ozs7O1dBQWlDO1FBQ2pDOzs7OztXQUFxQztJQUN0QyxDQUFDO0NBQUE7QUFFRCxlQUFlLGdCQUFnQixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcblx0TW9kZWwsXG5cdEluZmVyQXR0cmlidXRlcyxcblx0SW5mZXJDcmVhdGlvbkF0dHJpYnV0ZXMsXG5cdENyZWF0aW9uT3B0aW9uYWxcbn0gZnJvbSAnc2VxdWVsaXplJztcblxuaW50ZXJmYWNlIERhdGFTaGFyZU9wdGlvbnNBdHRyaWJ1dGVzIHtcblx0aWQ6IHN0cmluZztcblx0dHJhY2tpbmdQaXhlbE9wdGlvbjogYm9vbGVhbjtcblx0ZmVhdHVyZVVzYWdlT3B0aW9uOiBib29sZWFuO1xuXHRwYWdlVmlld3NPcHRpb246IGJvb2xlYW47XG5cdGludGVyYWN0aW9uRGF0YU9wdGlvbjogYm9vbGVhbjtcblx0ZGV2aWNlVHlwZU9wdGlvbjogYm9vbGVhbjtcblx0YnJvd3NlckluZm9PcHRpb246IGJvb2xlYW47XG5cdG9wZXJhdGluZ1N5c3RlbU9wdGlvbjogYm9vbGVhbjtcblx0cmFuZG9tQW5vblN1cnZleU9wdGlvbjogYm9vbGVhbjtcblx0bGFzdFVwZGF0ZWQ6IERhdGU7XG59XG5cbmNsYXNzIERhdGFTaGFyZU9wdGlvbnNcblx0ZXh0ZW5kcyBNb2RlbDxcblx0XHRJbmZlckF0dHJpYnV0ZXM8RGF0YVNoYXJlT3B0aW9ucz4sXG5cdFx0SW5mZXJDcmVhdGlvbkF0dHJpYnV0ZXM8RGF0YVNoYXJlT3B0aW9ucz5cblx0PlxuXHRpbXBsZW1lbnRzIERhdGFTaGFyZU9wdGlvbnNBdHRyaWJ1dGVzXG57XG5cdGlkITogc3RyaW5nO1xuXHR0cmFja2luZ1BpeGVsT3B0aW9uITogYm9vbGVhbjtcblx0ZmVhdHVyZVVzYWdlT3B0aW9uITogYm9vbGVhbjtcblx0cGFnZVZpZXdzT3B0aW9uITogYm9vbGVhbjtcblx0aW50ZXJhY3Rpb25EYXRhT3B0aW9uITogYm9vbGVhbjtcblx0ZGV2aWNlVHlwZU9wdGlvbiE6IGJvb2xlYW47XG5cdGJyb3dzZXJJbmZvT3B0aW9uITogYm9vbGVhbjtcblx0b3BlcmF0aW5nU3lzdGVtT3B0aW9uITogYm9vbGVhbjtcblx0cmFuZG9tQW5vblN1cnZleU9wdGlvbiE6IGJvb2xlYW47XG5cdGxhc3RVcGRhdGVkITogQ3JlYXRpb25PcHRpb25hbDxEYXRlPjtcbn1cblxuZXhwb3J0IGRlZmF1bHQgRGF0YVNoYXJlT3B0aW9ucztcbiJdfQ==