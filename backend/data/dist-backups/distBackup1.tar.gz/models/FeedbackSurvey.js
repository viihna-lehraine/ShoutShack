import { Model } from 'sequelize';
class FeedbackSurvey extends Model {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "surveyId", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "questionGeneralApproval", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "questionServiceQuality", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "questionEaseOfUse", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "questionUserSupport", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "questionHelpGuides", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "questionIsPremiumUser", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "questionPremiumValue", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "questionLikelihoodToRecommend", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "questionUsefulFeaturesAndAspects", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "questionFeaturesThatNeedImprovement", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "questionOpenEndedLikeTheMost", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "questionOpenEndedWhatCanWeImprove", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "questionDemoHeardAboutUs", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "questionDemoAgeGroup", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "questionDemoGender", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "questionDemoRegion", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "questionDemoLangPref", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "questionFinalThoughts", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "hasOptedInForFollowUp", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "email", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "surveyDate", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
    }
}
export default FeedbackSurvey;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiRmVlZGJhY2tTdXJ2ZXkuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvbW9kZWxzL0ZlZWRiYWNrU3VydmV5LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBNEMsS0FBSyxFQUFFLE1BQU0sV0FBVyxDQUFDO0FBMkI1RSxNQUFNLGNBQ0wsU0FBUSxLQUdQO0lBSkY7O1FBT0M7Ozs7O1dBQWtCO1FBQ2xCOzs7OztXQUF3QztRQUN4Qzs7Ozs7V0FBdUM7UUFDdkM7Ozs7O1dBQWtDO1FBQ2xDOzs7OztXQUFvQztRQUNwQzs7Ozs7V0FBbUM7UUFDbkM7Ozs7O1dBQXVDO1FBQ3ZDOzs7OztXQUFxQztRQUNyQzs7Ozs7V0FBOEM7UUFDOUM7Ozs7O1dBQWlEO1FBQ2pEOzs7OztXQUFvRDtRQUNwRDs7Ozs7V0FBNkM7UUFDN0M7Ozs7O1dBQWtEO1FBQ2xEOzs7OztXQUF5QztRQUN6Qzs7Ozs7V0FBcUM7UUFDckM7Ozs7O1dBQW1DO1FBQ25DOzs7OztXQUFtQztRQUNuQzs7Ozs7V0FBcUM7UUFDckM7Ozs7O1dBQXNDO1FBQ3RDOzs7OztXQUF1QztRQUN2Qzs7Ozs7V0FBc0I7UUFDdEI7Ozs7O1dBQWtCO0lBQ25CLENBQUM7Q0FBQTtBQUVELGVBQWUsY0FBYyxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5mZXJBdHRyaWJ1dGVzLCBJbmZlckNyZWF0aW9uQXR0cmlidXRlcywgTW9kZWwgfSBmcm9tICdzZXF1ZWxpemUnO1xuXG5pbnRlcmZhY2UgRmVlZGJhY2tTdXJ2ZXlBdHRyaWJ1dGVzIHtcblx0c3VydmV5SWQ6IHN0cmluZztcblx0cXVlc3Rpb25HZW5lcmFsQXBwcm92YWw/OiBudW1iZXIgfCBudWxsO1xuXHRxdWVzdGlvblNlcnZpY2VRdWFsaXR5PzogbnVtYmVyIHwgbnVsbDtcblx0cXVlc3Rpb25FYXNlT2ZVc2U/OiBudW1iZXIgfCBudWxsO1xuXHRxdWVzdGlvblVzZXJTdXBwb3J0PzogbnVtYmVyIHwgbnVsbDtcblx0cXVlc3Rpb25IZWxwR3VpZGVzPzogbnVtYmVyIHwgbnVsbDtcblx0cXVlc3Rpb25Jc1ByZW1pdW1Vc2VyPzogYm9vbGVhbiB8IG51bGw7XG5cdHF1ZXN0aW9uUHJlbWl1bVZhbHVlPzogbnVtYmVyIHwgbnVsbDtcblx0cXVlc3Rpb25MaWtlbGlob29kVG9SZWNvbW1lbmQ/OiBudW1iZXIgfCBudWxsO1xuXHRxdWVzdGlvblVzZWZ1bEZlYXR1cmVzQW5kQXNwZWN0cz86IG9iamVjdCB8IG51bGw7XG5cdHF1ZXN0aW9uRmVhdHVyZXNUaGF0TmVlZEltcHJvdmVtZW50Pzogb2JqZWN0IHwgbnVsbDtcblx0cXVlc3Rpb25PcGVuRW5kZWRMaWtlVGhlTW9zdD86IHN0cmluZyB8IG51bGw7XG5cdHF1ZXN0aW9uT3BlbkVuZGVkV2hhdENhbldlSW1wcm92ZT86IHN0cmluZyB8IG51bGw7XG5cdHF1ZXN0aW9uRGVtb0hlYXJkQWJvdXRVcz86IG51bWJlciB8IG51bGw7XG5cdHF1ZXN0aW9uRGVtb0FnZUdyb3VwPzogbnVtYmVyIHwgbnVsbDtcblx0cXVlc3Rpb25EZW1vR2VuZGVyPzogc3RyaW5nIHwgbnVsbDtcblx0cXVlc3Rpb25EZW1vUmVnaW9uPzogc3RyaW5nIHwgbnVsbDtcblx0cXVlc3Rpb25EZW1vTGFuZ1ByZWY/OiBzdHJpbmcgfCBudWxsO1xuXHRxdWVzdGlvbkZpbmFsVGhvdWdodHM/OiBzdHJpbmcgfCBudWxsO1xuXHRoYXNPcHRlZEluRm9yRm9sbG93VXA/OiBib29sZWFuIHwgbnVsbDtcblx0ZW1haWw/OiBzdHJpbmcgfCBudWxsO1xuXHRzdXJ2ZXlEYXRlOiBEYXRlO1xufVxuXG5jbGFzcyBGZWVkYmFja1N1cnZleVxuXHRleHRlbmRzIE1vZGVsPFxuXHRcdEluZmVyQXR0cmlidXRlczxGZWVkYmFja1N1cnZleT4sXG5cdFx0SW5mZXJDcmVhdGlvbkF0dHJpYnV0ZXM8RmVlZGJhY2tTdXJ2ZXk+XG5cdD5cblx0aW1wbGVtZW50cyBGZWVkYmFja1N1cnZleUF0dHJpYnV0ZXNcbntcblx0c3VydmV5SWQhOiBzdHJpbmc7XG5cdHF1ZXN0aW9uR2VuZXJhbEFwcHJvdmFsPzogbnVtYmVyIHwgbnVsbDtcblx0cXVlc3Rpb25TZXJ2aWNlUXVhbGl0eT86IG51bWJlciB8IG51bGw7XG5cdHF1ZXN0aW9uRWFzZU9mVXNlPzogbnVtYmVyIHwgbnVsbDtcblx0cXVlc3Rpb25Vc2VyU3VwcG9ydD86IG51bWJlciB8IG51bGw7XG5cdHF1ZXN0aW9uSGVscEd1aWRlcz86IG51bWJlciB8IG51bGw7XG5cdHF1ZXN0aW9uSXNQcmVtaXVtVXNlcj86IGJvb2xlYW4gfCBudWxsO1xuXHRxdWVzdGlvblByZW1pdW1WYWx1ZT86IG51bWJlciB8IG51bGw7XG5cdHF1ZXN0aW9uTGlrZWxpaG9vZFRvUmVjb21tZW5kPzogbnVtYmVyIHwgbnVsbDtcblx0cXVlc3Rpb25Vc2VmdWxGZWF0dXJlc0FuZEFzcGVjdHM/OiBvYmplY3QgfCBudWxsO1xuXHRxdWVzdGlvbkZlYXR1cmVzVGhhdE5lZWRJbXByb3ZlbWVudD86IG9iamVjdCB8IG51bGw7XG5cdHF1ZXN0aW9uT3BlbkVuZGVkTGlrZVRoZU1vc3Q/OiBzdHJpbmcgfCBudWxsO1xuXHRxdWVzdGlvbk9wZW5FbmRlZFdoYXRDYW5XZUltcHJvdmU/OiBzdHJpbmcgfCBudWxsO1xuXHRxdWVzdGlvbkRlbW9IZWFyZEFib3V0VXM/OiBudW1iZXIgfCBudWxsO1xuXHRxdWVzdGlvbkRlbW9BZ2VHcm91cD86IG51bWJlciB8IG51bGw7XG5cdHF1ZXN0aW9uRGVtb0dlbmRlcj86IHN0cmluZyB8IG51bGw7XG5cdHF1ZXN0aW9uRGVtb1JlZ2lvbj86IHN0cmluZyB8IG51bGw7XG5cdHF1ZXN0aW9uRGVtb0xhbmdQcmVmPzogc3RyaW5nIHwgbnVsbDtcblx0cXVlc3Rpb25GaW5hbFRob3VnaHRzPzogc3RyaW5nIHwgbnVsbDtcblx0aGFzT3B0ZWRJbkZvckZvbGxvd1VwPzogYm9vbGVhbiB8IG51bGw7XG5cdGVtYWlsPzogc3RyaW5nIHwgbnVsbDtcblx0c3VydmV5RGF0ZSE6IERhdGU7XG59XG5cbmV4cG9ydCBkZWZhdWx0IEZlZWRiYWNrU3VydmV5O1xuIl19