import { Model } from 'sequelize';
class Device extends Model {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "deviceId", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "id", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "deviceName", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "deviceType", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "os", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "browser", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "ipAddress", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "lastUsed", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "isTrusted", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "creationDate", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "lastUpdated", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
    }
}
export default Device;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiRGV2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL21vZGVscy9EZXZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNOLEtBQUssRUFJTCxNQUFNLFdBQVcsQ0FBQztBQWdCbkIsTUFBTSxNQUNMLFNBQVEsS0FBK0Q7SUFEeEU7O1FBSUM7Ozs7O1dBQWtCO1FBQ2xCOzs7OztXQUFZO1FBQ1o7Ozs7O1dBQW9CO1FBQ3BCOzs7OztXQUFvQjtRQUNwQjs7Ozs7V0FBWTtRQUNaOzs7OztXQUF3QjtRQUN4Qjs7Ozs7V0FBbUI7UUFDbkI7Ozs7O1dBQWtDO1FBQ2xDOzs7OztXQUFvQjtRQUNwQjs7Ozs7V0FBc0M7UUFDdEM7Ozs7O1dBQXFDO0lBQ3RDLENBQUM7Q0FBQTtBQUVELGVBQWUsTUFBTSxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcblx0TW9kZWwsXG5cdEluZmVyQXR0cmlidXRlcyxcblx0SW5mZXJDcmVhdGlvbkF0dHJpYnV0ZXMsXG5cdENyZWF0aW9uT3B0aW9uYWxcbn0gZnJvbSAnc2VxdWVsaXplJztcblxuaW50ZXJmYWNlIERldmljZUF0dHJpYnV0ZXMge1xuXHRkZXZpY2VJZDogbnVtYmVyO1xuXHRpZDogc3RyaW5nO1xuXHRkZXZpY2VOYW1lOiBzdHJpbmc7XG5cdGRldmljZVR5cGU6IHN0cmluZztcblx0b3M6IHN0cmluZztcblx0YnJvd3Nlcj86IHN0cmluZyB8IG51bGw7XG5cdGlwQWRkcmVzczogc3RyaW5nO1xuXHRsYXN0VXNlZDogRGF0ZTtcblx0aXNUcnVzdGVkOiBib29sZWFuO1xuXHRjcmVhdGlvbkRhdGU6IERhdGU7XG5cdGxhc3RVcGRhdGVkOiBEYXRlO1xufVxuXG5jbGFzcyBEZXZpY2Vcblx0ZXh0ZW5kcyBNb2RlbDxJbmZlckF0dHJpYnV0ZXM8RGV2aWNlPiwgSW5mZXJDcmVhdGlvbkF0dHJpYnV0ZXM8RGV2aWNlPj5cblx0aW1wbGVtZW50cyBEZXZpY2VBdHRyaWJ1dGVzXG57XG5cdGRldmljZUlkITogbnVtYmVyO1xuXHRpZCE6IHN0cmluZztcblx0ZGV2aWNlTmFtZSE6IHN0cmluZztcblx0ZGV2aWNlVHlwZSE6IHN0cmluZztcblx0b3MhOiBzdHJpbmc7XG5cdGJyb3dzZXIhOiBzdHJpbmcgfCBudWxsO1xuXHRpcEFkZHJlc3MhOiBzdHJpbmc7XG5cdGxhc3RVc2VkITogQ3JlYXRpb25PcHRpb25hbDxEYXRlPjtcblx0aXNUcnVzdGVkITogYm9vbGVhbjtcblx0Y3JlYXRpb25EYXRlITogQ3JlYXRpb25PcHRpb25hbDxEYXRlPjtcblx0bGFzdFVwZGF0ZWQhOiBDcmVhdGlvbk9wdGlvbmFsPERhdGU+O1xufVxuXG5leHBvcnQgZGVmYXVsdCBEZXZpY2U7XG4iXX0=