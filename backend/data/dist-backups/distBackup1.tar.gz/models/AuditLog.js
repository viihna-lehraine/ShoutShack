import { Model } from 'sequelize';
class AuditLog extends Model {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "auditId", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "id", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "actionType", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "actionDescription", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "affectedResource", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "previousValue", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "newValue", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "ipAddress", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "userAgent", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "auditLogDate", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "auditLogUpdateDate", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
    }
}
export default AuditLog;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQXVkaXRMb2cuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvbW9kZWxzL0F1ZGl0TG9nLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxLQUFLLEVBQTRDLE1BQU0sV0FBVyxDQUFDO0FBZ0I1RSxNQUFNLFFBQ0wsU0FBUSxLQUFtRTtJQUQ1RTs7UUFJQzs7Ozs7V0FBaUI7UUFDakI7Ozs7O1dBQVk7UUFDWjs7Ozs7V0FBb0I7UUFDcEI7Ozs7O1dBQWtDO1FBQ2xDOzs7OztXQUFpQztRQUNqQzs7Ozs7V0FBOEI7UUFDOUI7Ozs7O1dBQXlCO1FBQ3pCOzs7OztXQUFtQjtRQUNuQjs7Ozs7V0FBbUI7UUFDbkI7Ozs7O1dBQW9CO1FBQ3BCOzs7OztXQUFpQztJQUNsQyxDQUFDO0NBQUE7QUFFRCxlQUFlLFFBQVEsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE1vZGVsLCBJbmZlckF0dHJpYnV0ZXMsIEluZmVyQ3JlYXRpb25BdHRyaWJ1dGVzIH0gZnJvbSAnc2VxdWVsaXplJztcblxuaW50ZXJmYWNlIEF1ZGl0TG9nQXR0cmlidXRlcyB7XG5cdGF1ZGl0SWQ6IHN0cmluZztcblx0aWQ6IHN0cmluZztcblx0YWN0aW9uVHlwZTogc3RyaW5nO1xuXHRhY3Rpb25EZXNjcmlwdGlvbj86IHN0cmluZyB8IG51bGw7XG5cdGFmZmVjdGVkUmVzb3VyY2U/OiBzdHJpbmcgfCBudWxsO1xuXHRwcmV2aW91c1ZhbHVlPzogc3RyaW5nIHwgbnVsbDtcblx0bmV3VmFsdWU/OiBzdHJpbmcgfCBudWxsO1xuXHRpcEFkZHJlc3M6IHN0cmluZztcblx0dXNlckFnZW50OiBzdHJpbmc7XG5cdGF1ZGl0TG9nRGF0ZTogRGF0ZTtcblx0YXVkaXRMb2dVcGRhdGVEYXRlPzogRGF0ZSB8IG51bGw7XG59XG5cbmNsYXNzIEF1ZGl0TG9nXG5cdGV4dGVuZHMgTW9kZWw8SW5mZXJBdHRyaWJ1dGVzPEF1ZGl0TG9nPiwgSW5mZXJDcmVhdGlvbkF0dHJpYnV0ZXM8QXVkaXRMb2c+PlxuXHRpbXBsZW1lbnRzIEF1ZGl0TG9nQXR0cmlidXRlc1xue1xuXHRhdWRpdElkITogc3RyaW5nO1xuXHRpZCE6IHN0cmluZztcblx0YWN0aW9uVHlwZSE6IHN0cmluZztcblx0YWN0aW9uRGVzY3JpcHRpb24hOiBzdHJpbmcgfCBudWxsO1xuXHRhZmZlY3RlZFJlc291cmNlITogc3RyaW5nIHwgbnVsbDtcblx0cHJldmlvdXNWYWx1ZSE6IHN0cmluZyB8IG51bGw7XG5cdG5ld1ZhbHVlITogc3RyaW5nIHwgbnVsbDtcblx0aXBBZGRyZXNzITogc3RyaW5nO1xuXHR1c2VyQWdlbnQhOiBzdHJpbmc7XG5cdGF1ZGl0TG9nRGF0ZSE6IERhdGU7XG5cdGF1ZGl0TG9nVXBkYXRlRGF0ZT86IERhdGUgfCBudWxsO1xufVxuXG5leHBvcnQgZGVmYXVsdCBBdWRpdExvZztcbiJdfQ==