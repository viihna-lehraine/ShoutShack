import { Model } from 'sequelize';
// Fields in the UserMfa Model
class UserMfa extends Model {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "id", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "isMfaEnabled", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "backupCodes", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "isEmail2faEnabled", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "isTotpl2faEnabled", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "isYubicoOtp2faEnabled", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "isU2f2faEnabled", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "isPasskeyEnabled", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "totpSecret", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "yubicoOtpPublicId", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "yubicoOtpSecretKey", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "fido2CredentialId", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "fido2PublicKey", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "fido2Counter", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "fido2AttestationFormat", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "passkeyCredentialId", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "passkeyPublicKey", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "passkeyCounter", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "passkeyAttestationFormat", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
    }
}
export default UserMfa;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiVXNlck1mYS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9tb2RlbHMvVXNlck1mYS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQTRDLEtBQUssRUFBRSxNQUFNLFdBQVcsQ0FBQztBQXdCNUUsOEJBQThCO0FBQzlCLE1BQU0sT0FDTCxTQUFRLEtBQWlFO0lBRDFFOztRQUlDOzs7OztXQUFZO1FBQ1o7Ozs7O1dBQXVCO1FBQ3ZCOzs7OztXQUE4QjtRQUM5Qjs7Ozs7V0FBNEI7UUFDNUI7Ozs7O1dBQTRCO1FBQzVCOzs7OztXQUFnQztRQUNoQzs7Ozs7V0FBMEI7UUFDMUI7Ozs7O1dBQTJCO1FBQzNCOzs7OztXQUEyQjtRQUMzQjs7Ozs7V0FBa0M7UUFDbEM7Ozs7O1dBQW1DO1FBQ25DOzs7OztXQUFrQztRQUNsQzs7Ozs7V0FBK0I7UUFDL0I7Ozs7O1dBQTZCO1FBQzdCOzs7OztXQUF1QztRQUN2Qzs7Ozs7V0FBb0M7UUFDcEM7Ozs7O1dBQWlDO1FBQ2pDOzs7OztXQUErQjtRQUMvQjs7Ozs7V0FBeUM7SUFDMUMsQ0FBQztDQUFBO0FBRUQsZUFBZSxPQUFPLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmZlckF0dHJpYnV0ZXMsIEluZmVyQ3JlYXRpb25BdHRyaWJ1dGVzLCBNb2RlbCB9IGZyb20gJ3NlcXVlbGl6ZSc7XG5cbmludGVyZmFjZSBVc2VyTWZhQXR0cmlidXRlcyB7XG5cdGlkOiBzdHJpbmc7XG5cdGlzTWZhRW5hYmxlZDogYm9vbGVhbjtcblx0YmFja3VwQ29kZXM6IHN0cmluZ1tdIHwgbnVsbDtcblx0aXNFbWFpbDJmYUVuYWJsZWQ6IGJvb2xlYW47XG5cdGlzVG90cGwyZmFFbmFibGVkOiBib29sZWFuO1xuXHRpc1l1Ymljb090cDJmYUVuYWJsZWQ6IGJvb2xlYW47XG5cdGlzVTJmMmZhRW5hYmxlZDogYm9vbGVhbjtcblx0aXNQYXNza2V5RW5hYmxlZDogYm9vbGVhbjtcblx0dG90cFNlY3JldDogc3RyaW5nIHwgbnVsbDtcblx0eXViaWNvT3RwUHVibGljSWQ6IHN0cmluZyB8IG51bGw7XG5cdHl1Ymljb090cFNlY3JldEtleTogc3RyaW5nIHwgbnVsbDtcblx0ZmlkbzJDcmVkZW50aWFsSWQ6IHN0cmluZyB8IG51bGw7XG5cdGZpZG8yUHVibGljS2V5OiBzdHJpbmcgfCBudWxsO1xuXHRmaWRvMkNvdW50ZXI6IG51bWJlciB8IG51bGw7XG5cdGZpZG8yQXR0ZXN0YXRpb25Gb3JtYXQ6IHN0cmluZyB8IG51bGw7XG5cdHBhc3NrZXlDcmVkZW50aWFsSWQ6IHN0cmluZyB8IG51bGw7XG5cdHBhc3NrZXlQdWJsaWNLZXk6IHN0cmluZyB8IG51bGw7XG5cdHBhc3NrZXlDb3VudGVyOiBudW1iZXIgfCBudWxsO1xuXHRwYXNza2V5QXR0ZXN0YXRpb25Gb3JtYXQ6IHN0cmluZyB8IG51bGw7XG59XG5cbi8vIEZpZWxkcyBpbiB0aGUgVXNlck1mYSBNb2RlbFxuY2xhc3MgVXNlck1mYVxuXHRleHRlbmRzIE1vZGVsPEluZmVyQXR0cmlidXRlczxVc2VyTWZhPiwgSW5mZXJDcmVhdGlvbkF0dHJpYnV0ZXM8VXNlck1mYT4+XG5cdGltcGxlbWVudHMgVXNlck1mYUF0dHJpYnV0ZXNcbntcblx0aWQhOiBzdHJpbmc7XG5cdGlzTWZhRW5hYmxlZCE6IGJvb2xlYW47XG5cdGJhY2t1cENvZGVzITogc3RyaW5nW10gfCBudWxsO1xuXHRpc0VtYWlsMmZhRW5hYmxlZCE6IGJvb2xlYW47XG5cdGlzVG90cGwyZmFFbmFibGVkITogYm9vbGVhbjtcblx0aXNZdWJpY29PdHAyZmFFbmFibGVkITogYm9vbGVhbjtcblx0aXNVMmYyZmFFbmFibGVkITogYm9vbGVhbjtcblx0aXNQYXNza2V5RW5hYmxlZCE6IGJvb2xlYW47XG5cdHRvdHBTZWNyZXQhOiBzdHJpbmcgfCBudWxsO1xuXHR5dWJpY29PdHBQdWJsaWNJZCE6IHN0cmluZyB8IG51bGw7XG5cdHl1Ymljb090cFNlY3JldEtleSE6IHN0cmluZyB8IG51bGw7XG5cdGZpZG8yQ3JlZGVudGlhbElkITogc3RyaW5nIHwgbnVsbDtcblx0ZmlkbzJQdWJsaWNLZXkhOiBzdHJpbmcgfCBudWxsO1xuXHRmaWRvMkNvdW50ZXIhOiBudW1iZXIgfCBudWxsO1xuXHRmaWRvMkF0dGVzdGF0aW9uRm9ybWF0ITogc3RyaW5nIHwgbnVsbDtcblx0cGFzc2tleUNyZWRlbnRpYWxJZCE6IHN0cmluZyB8IG51bGw7XG5cdHBhc3NrZXlQdWJsaWNLZXkhOiBzdHJpbmcgfCBudWxsO1xuXHRwYXNza2V5Q291bnRlciE6IG51bWJlciB8IG51bGw7XG5cdHBhc3NrZXlBdHRlc3RhdGlvbkZvcm1hdCE6IHN0cmluZyB8IG51bGw7XG59XG5cbmV4cG9ydCBkZWZhdWx0IFVzZXJNZmE7XG4iXX0=