import { Model } from 'sequelize';
class FeatureRequest extends Model {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "featureRequestNumber", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "id", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "email", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "featureRequestType", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "featureRequestContent", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "canFollowUpFeatureRequest", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "featureRequestOpenDate", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "featureRequestCloseDate", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
    }
}
export default FeatureRequest;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiRmVhdHVyZVJlcXVlc3QuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvbW9kZWxzL0ZlYXR1cmVSZXF1ZXN0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFJTixLQUFLLEVBQ0wsTUFBTSxXQUFXLENBQUM7QUFhbkIsTUFBTSxjQUNMLFNBQVEsS0FHUDtJQUpGOztRQU9DOzs7OztXQUE4QjtRQUM5Qjs7Ozs7V0FBWTtRQUNaOzs7OztXQUFzQjtRQUN0Qjs7Ozs7V0FBNEI7UUFDNUI7Ozs7O1dBQStCO1FBQy9COzs7OztXQUFvQztRQUNwQzs7Ozs7V0FBZ0Q7UUFDaEQ7Ozs7O1dBQXNDO0lBQ3ZDLENBQUM7Q0FBQTtBQUVELGVBQWUsY0FBYyxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcblx0Q3JlYXRpb25PcHRpb25hbCxcblx0SW5mZXJBdHRyaWJ1dGVzLFxuXHRJbmZlckNyZWF0aW9uQXR0cmlidXRlcyxcblx0TW9kZWxcbn0gZnJvbSAnc2VxdWVsaXplJztcblxuaW50ZXJmYWNlIEZlYXR1cmVSZXF1ZXN0QXR0cmlidXRlcyB7XG5cdGZlYXR1cmVSZXF1ZXN0TnVtYmVyOiBudW1iZXI7XG5cdGlkOiBzdHJpbmc7XG5cdGVtYWlsPzogc3RyaW5nIHwgbnVsbDtcblx0ZmVhdHVyZVJlcXVlc3RUeXBlOiBzdHJpbmc7XG5cdGZlYXR1cmVSZXF1ZXN0Q29udGVudDogc3RyaW5nO1xuXHRjYW5Gb2xsb3dVcEZlYXR1cmVSZXF1ZXN0OiBib29sZWFuO1xuXHRmZWF0dXJlUmVxdWVzdE9wZW5EYXRlOiBEYXRlO1xuXHRmZWF0dXJlUmVxdWVzdENsb3NlRGF0ZT86IERhdGUgfCBudWxsO1xufVxuXG5jbGFzcyBGZWF0dXJlUmVxdWVzdFxuXHRleHRlbmRzIE1vZGVsPFxuXHRcdEluZmVyQXR0cmlidXRlczxGZWF0dXJlUmVxdWVzdD4sXG5cdFx0SW5mZXJDcmVhdGlvbkF0dHJpYnV0ZXM8RmVhdHVyZVJlcXVlc3Q+XG5cdD5cblx0aW1wbGVtZW50cyBGZWF0dXJlUmVxdWVzdEF0dHJpYnV0ZXNcbntcblx0ZmVhdHVyZVJlcXVlc3ROdW1iZXIhOiBudW1iZXI7XG5cdGlkITogc3RyaW5nO1xuXHRlbWFpbCE6IHN0cmluZyB8IG51bGw7XG5cdGZlYXR1cmVSZXF1ZXN0VHlwZSE6IHN0cmluZztcblx0ZmVhdHVyZVJlcXVlc3RDb250ZW50ITogc3RyaW5nO1xuXHRjYW5Gb2xsb3dVcEZlYXR1cmVSZXF1ZXN0ITogYm9vbGVhbjtcblx0ZmVhdHVyZVJlcXVlc3RPcGVuRGF0ZSE6IENyZWF0aW9uT3B0aW9uYWw8RGF0ZT47XG5cdGZlYXR1cmVSZXF1ZXN0Q2xvc2VEYXRlITogRGF0ZSB8IG51bGw7XG59XG5cbmV4cG9ydCBkZWZhdWx0IEZlYXR1cmVSZXF1ZXN0O1xuIl19