import { Model } from 'sequelize';
class SecurityEvent extends Model {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "id", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "eventId", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "eventType", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "eventDescription", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "ipAddress", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "userAgent", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "securityEventDate", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "securityEventLastUpdated", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
    }
}
export default SecurityEvent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiU2VjdXJpdHlFdmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9tb2RlbHMvU2VjdXJpdHlFdmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBSU4sS0FBSyxFQUNMLE1BQU0sV0FBVyxDQUFDO0FBYW5CLE1BQU0sYUFDTCxTQUFRLEtBR1A7SUFKRjs7UUFPQzs7Ozs7V0FBWTtRQUNaOzs7OztXQUFpQjtRQUNqQjs7Ozs7V0FBbUI7UUFDbkI7Ozs7O1dBQWlDO1FBQ2pDOzs7OztXQUFtQjtRQUNuQjs7Ozs7V0FBbUI7UUFDbkI7Ozs7O1dBQXlCO1FBQ3pCOzs7OztXQUFrRDtJQUNuRCxDQUFDO0NBQUE7QUFFRCxlQUFlLGFBQWEsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG5cdENyZWF0aW9uT3B0aW9uYWwsXG5cdEluZmVyQXR0cmlidXRlcyxcblx0SW5mZXJDcmVhdGlvbkF0dHJpYnV0ZXMsXG5cdE1vZGVsXG59IGZyb20gJ3NlcXVlbGl6ZSc7XG5cbmludGVyZmFjZSBTZWN1cml0eUV2ZW50QXR0cmlidXRlcyB7XG5cdGlkOiBzdHJpbmc7XG5cdGV2ZW50SWQ6IHN0cmluZztcblx0ZXZlbnRUeXBlOiBzdHJpbmc7XG5cdGV2ZW50RGVzY3JpcHRpb24/OiBzdHJpbmcgfCBudWxsO1xuXHRpcEFkZHJlc3M6IHN0cmluZztcblx0dXNlckFnZW50OiBzdHJpbmc7XG5cdHNlY3VyaXR5RXZlbnREYXRlOiBEYXRlO1xuXHRzZWN1cml0eUV2ZW50TGFzdFVwZGF0ZWQ6IERhdGU7XG59XG5cbmNsYXNzIFNlY3VyaXR5RXZlbnRcblx0ZXh0ZW5kcyBNb2RlbDxcblx0XHRJbmZlckF0dHJpYnV0ZXM8U2VjdXJpdHlFdmVudD4sXG5cdFx0SW5mZXJDcmVhdGlvbkF0dHJpYnV0ZXM8U2VjdXJpdHlFdmVudD5cblx0PlxuXHRpbXBsZW1lbnRzIFNlY3VyaXR5RXZlbnRBdHRyaWJ1dGVzXG57XG5cdGlkITogc3RyaW5nO1xuXHRldmVudElkITogc3RyaW5nO1xuXHRldmVudFR5cGUhOiBzdHJpbmc7XG5cdGV2ZW50RGVzY3JpcHRpb24hOiBzdHJpbmcgfCBudWxsO1xuXHRpcEFkZHJlc3MhOiBzdHJpbmc7XG5cdHVzZXJBZ2VudCE6IHN0cmluZztcblx0c2VjdXJpdHlFdmVudERhdGUhOiBEYXRlO1xuXHRzZWN1cml0eUV2ZW50TGFzdFVwZGF0ZWQhOiBDcmVhdGlvbk9wdGlvbmFsPERhdGU+O1xufVxuXG5leHBvcnQgZGVmYXVsdCBTZWN1cml0eUV2ZW50O1xuIl19