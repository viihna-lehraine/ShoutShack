import { Model } from 'sequelize';
class SupportRequest extends Model {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "id", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "email", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "supportTicketNumber", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "supportType", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "supportContent", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "isSupportTicketOpen", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "supportTicketOpenDate", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "supportTicketCloseDate", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
    }
}
export default SupportRequest;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiU3VwcG9ydFJlcXVlc3QuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvbW9kZWxzL1N1cHBvcnRSZXF1ZXN0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBNEMsS0FBSyxFQUFFLE1BQU0sV0FBVyxDQUFDO0FBYTVFLE1BQU0sY0FDTCxTQUFRLEtBR1A7SUFKRjs7UUFPQzs7Ozs7V0FBWTtRQUNaOzs7OztXQUFlO1FBQ2Y7Ozs7O1dBQTZCO1FBQzdCOzs7OztXQUFxQjtRQUNyQjs7Ozs7V0FBd0I7UUFDeEI7Ozs7O1dBQThCO1FBQzlCOzs7OztXQUE2QjtRQUM3Qjs7Ozs7V0FBcUM7SUFDdEMsQ0FBQztDQUFBO0FBRUQsZUFBZSxjQUFjLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmZlckF0dHJpYnV0ZXMsIEluZmVyQ3JlYXRpb25BdHRyaWJ1dGVzLCBNb2RlbCB9IGZyb20gJ3NlcXVlbGl6ZSc7XG5cbmludGVyZmFjZSBTdXBwb3J0UmVxdWVzdEF0dHJpYnV0ZXMge1xuXHRpZDogc3RyaW5nO1xuXHRlbWFpbDogc3RyaW5nO1xuXHRzdXBwb3J0VGlja2V0TnVtYmVyOiBudW1iZXI7XG5cdHN1cHBvcnRUeXBlOiBzdHJpbmc7XG5cdHN1cHBvcnRDb250ZW50OiBzdHJpbmc7XG5cdGlzU3VwcG9ydFRpY2tldE9wZW46IGJvb2xlYW47XG5cdHN1cHBvcnRUaWNrZXRPcGVuRGF0ZTogRGF0ZTtcblx0c3VwcG9ydFRpY2tldENsb3NlRGF0ZT86IERhdGUgfCBudWxsO1xufVxuXG5jbGFzcyBTdXBwb3J0UmVxdWVzdFxuXHRleHRlbmRzIE1vZGVsPFxuXHRcdEluZmVyQXR0cmlidXRlczxTdXBwb3J0UmVxdWVzdD4sXG5cdFx0SW5mZXJDcmVhdGlvbkF0dHJpYnV0ZXM8U3VwcG9ydFJlcXVlc3Q+XG5cdD5cblx0aW1wbGVtZW50cyBTdXBwb3J0UmVxdWVzdEF0dHJpYnV0ZXNcbntcblx0aWQhOiBzdHJpbmc7XG5cdGVtYWlsITogc3RyaW5nO1xuXHRzdXBwb3J0VGlja2V0TnVtYmVyITogbnVtYmVyO1xuXHRzdXBwb3J0VHlwZSE6IHN0cmluZztcblx0c3VwcG9ydENvbnRlbnQhOiBzdHJpbmc7XG5cdGlzU3VwcG9ydFRpY2tldE9wZW4hOiBib29sZWFuO1xuXHRzdXBwb3J0VGlja2V0T3BlbkRhdGUhOiBEYXRlO1xuXHRzdXBwb3J0VGlja2V0Q2xvc2VEYXRlPzogRGF0ZSB8IG51bGw7XG59XG5cbmV4cG9ydCBkZWZhdWx0IFN1cHBvcnRSZXF1ZXN0O1xuIl19