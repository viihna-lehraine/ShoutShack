import { Model } from 'sequelize';
class FailedLoginAttempts extends Model {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "attemptId", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "id", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "ipAddress", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "userAgent", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "attemptDate", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "isLocked", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
    }
}
export default FailedLoginAttempts;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiRmFpbGVkTG9naW5BdHRlbXB0cy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9tb2RlbHMvRmFpbGVkTG9naW5BdHRlbXB0cy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQTRDLEtBQUssRUFBRSxNQUFNLFdBQVcsQ0FBQztBQVc1RSxNQUFNLG1CQUNMLFNBQVEsS0FHUDtJQUpGOztRQU9DOzs7OztXQUFtQjtRQUNuQjs7Ozs7V0FBWTtRQUNaOzs7OztXQUFtQjtRQUNuQjs7Ozs7V0FBbUI7UUFDbkI7Ozs7O1dBQW1CO1FBQ25COzs7OztXQUFtQjtJQUNwQixDQUFDO0NBQUE7QUFFRCxlQUFlLG1CQUFtQixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5mZXJBdHRyaWJ1dGVzLCBJbmZlckNyZWF0aW9uQXR0cmlidXRlcywgTW9kZWwgfSBmcm9tICdzZXF1ZWxpemUnO1xuXG5pbnRlcmZhY2UgRmFpbGVkTG9naW5BdHRlbXB0c0F0dHJpYnV0ZXMge1xuXHRhdHRlbXB0SWQ6IHN0cmluZztcblx0aWQ6IHN0cmluZztcblx0aXBBZGRyZXNzOiBzdHJpbmc7XG5cdHVzZXJBZ2VudDogc3RyaW5nO1xuXHRhdHRlbXB0RGF0ZTogRGF0ZTtcblx0aXNMb2NrZWQ6IGJvb2xlYW47XG59XG5cbmNsYXNzIEZhaWxlZExvZ2luQXR0ZW1wdHNcblx0ZXh0ZW5kcyBNb2RlbDxcblx0XHRJbmZlckF0dHJpYnV0ZXM8RmFpbGVkTG9naW5BdHRlbXB0cz4sXG5cdFx0SW5mZXJDcmVhdGlvbkF0dHJpYnV0ZXM8RmFpbGVkTG9naW5BdHRlbXB0cz5cblx0PlxuXHRpbXBsZW1lbnRzIEZhaWxlZExvZ2luQXR0ZW1wdHNBdHRyaWJ1dGVzXG57XG5cdGF0dGVtcHRJZCE6IHN0cmluZztcblx0aWQhOiBzdHJpbmc7XG5cdGlwQWRkcmVzcyE6IHN0cmluZztcblx0dXNlckFnZW50ITogc3RyaW5nO1xuXHRhdHRlbXB0RGF0ZSE6IERhdGU7XG5cdGlzTG9ja2VkITogYm9vbGVhbjtcbn1cblxuZXhwb3J0IGRlZmF1bHQgRmFpbGVkTG9naW5BdHRlbXB0cztcbiJdfQ==