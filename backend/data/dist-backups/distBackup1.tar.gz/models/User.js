import { __awaiter } from "tslib";
import argon2 from 'argon2';
import { Model } from 'sequelize';
import { v4 as uuidv4 } from 'uuid';
import getSecrets from '../config/secrets.js';
class User extends Model {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "id", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "userid", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "username", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "password", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "email", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "isAccountVerified", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "resetPasswordToken", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "resetPasswordExpires", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "isMfaEnabled", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "creationDate", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
    }
    // Method to compare passwords
    comparePassword(password) {
        return __awaiter(this, void 0, void 0, function* () {
            const secrets = yield getSecrets();
            return argon2.verify(this.password, password + secrets.PEPPER);
        });
    }
    // Static method to validate passwords
    static validatePassword(password) {
        const isValidLength = password.length >= 8 && password.length <= 128;
        const hasUpperCase = /[A-Z]/.test(password);
        const hasLowerCase = /[a-z]/.test(password);
        const hasNumber = /\d/.test(password);
        const hasSpecial = /[^\dA-Za-z]/.test(password);
        return (isValidLength &&
            hasUpperCase &&
            hasLowerCase &&
            hasNumber &&
            hasSpecial);
    }
    // Static method to create a new user
    static createUser(username, password, email) {
        return __awaiter(this, void 0, void 0, function* () {
            const isValidPassword = User.validatePassword(password);
            if (!isValidPassword) {
                throw new Error('Password does not meet the security requirements.');
            }
            const newUser = yield User.create({
                id: uuidv4(),
                username,
                password,
                email,
                isAccountVerified: false,
                resetPasswordToken: null, // Set to null initially
                resetPasswordExpires: null, // Set to null initially
                isMfaEnabled: false,
                creationDate: new Date()
            });
            return newUser;
        });
    }
}
export default User;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiVXNlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9tb2RlbHMvVXNlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxNQUFNLE1BQU0sUUFBUSxDQUFDO0FBQzVCLE9BQU8sRUFBNEMsS0FBSyxFQUFFLE1BQU0sV0FBVyxDQUFDO0FBQzVFLE9BQU8sRUFBRSxFQUFFLElBQUksTUFBTSxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBQ3BDLE9BQU8sVUFBVSxNQUFNLG1CQUFtQixDQUFDO0FBZTNDLE1BQU0sSUFDTCxTQUFRLEtBQTJEO0lBRHBFOztRQUlDOzs7OztXQUFZO1FBQ1o7Ozs7O1dBQWdCO1FBQ2hCOzs7OztXQUFrQjtRQUNsQjs7Ozs7V0FBa0I7UUFDbEI7Ozs7O1dBQWU7UUFDZjs7Ozs7V0FBNEI7UUFDNUI7Ozs7O1dBQW1DO1FBQ25DOzs7OztXQUFtQztRQUNuQzs7Ozs7V0FBdUI7UUFDdkI7Ozs7O1dBQW9CO0lBb0RyQixDQUFDO0lBbERBLDhCQUE4QjtJQUN4QixlQUFlLENBQUMsUUFBZ0I7O1lBQ3JDLE1BQU0sT0FBTyxHQUFHLE1BQU0sVUFBVSxFQUFFLENBQUM7WUFDbkMsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsUUFBUSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNoRSxDQUFDO0tBQUE7SUFFRCxzQ0FBc0M7SUFDdEMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLFFBQWdCO1FBQ3ZDLE1BQU0sYUFBYSxHQUFHLFFBQVEsQ0FBQyxNQUFNLElBQUksQ0FBQyxJQUFJLFFBQVEsQ0FBQyxNQUFNLElBQUksR0FBRyxDQUFDO1FBQ3JFLE1BQU0sWUFBWSxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDNUMsTUFBTSxZQUFZLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUM1QyxNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sVUFBVSxHQUFHLGFBQWEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFaEQsT0FBTyxDQUNOLGFBQWE7WUFDYixZQUFZO1lBQ1osWUFBWTtZQUNaLFNBQVM7WUFDVCxVQUFVLENBQ1YsQ0FBQztJQUNILENBQUM7SUFFRCxxQ0FBcUM7SUFDckMsTUFBTSxDQUFPLFVBQVUsQ0FDdEIsUUFBZ0IsRUFDaEIsUUFBZ0IsRUFDaEIsS0FBYTs7WUFFYixNQUFNLGVBQWUsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDeEQsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO2dCQUN0QixNQUFNLElBQUksS0FBSyxDQUNkLG1EQUFtRCxDQUNuRCxDQUFDO1lBQ0gsQ0FBQztZQUVELE1BQU0sT0FBTyxHQUFHLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQztnQkFDakMsRUFBRSxFQUFFLE1BQU0sRUFBRTtnQkFDWixRQUFRO2dCQUNSLFFBQVE7Z0JBQ1IsS0FBSztnQkFDTCxpQkFBaUIsRUFBRSxLQUFLO2dCQUN4QixrQkFBa0IsRUFBRSxJQUFJLEVBQUUsd0JBQXdCO2dCQUNsRCxvQkFBb0IsRUFBRSxJQUFJLEVBQUUsd0JBQXdCO2dCQUNwRCxZQUFZLEVBQUUsS0FBSztnQkFDbkIsWUFBWSxFQUFFLElBQUksSUFBSSxFQUFFO2FBQ3hCLENBQUMsQ0FBQztZQUVILE9BQU8sT0FBTyxDQUFDO1FBQ2hCLENBQUM7S0FBQTtDQUNEO0FBRUQsZUFBZSxJQUFJLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgYXJnb24yIGZyb20gJ2FyZ29uMic7XG5pbXBvcnQgeyBJbmZlckF0dHJpYnV0ZXMsIEluZmVyQ3JlYXRpb25BdHRyaWJ1dGVzLCBNb2RlbCB9IGZyb20gJ3NlcXVlbGl6ZSc7XG5pbXBvcnQgeyB2NCBhcyB1dWlkdjQgfSBmcm9tICd1dWlkJztcbmltcG9ydCBnZXRTZWNyZXRzIGZyb20gJy4uL2NvbmZpZy9zZWNyZXRzJztcblxuaW50ZXJmYWNlIFVzZXJBdHRyaWJ1dGVzIHtcblx0aWQ6IHN0cmluZztcblx0dXNlcmlkPzogbnVtYmVyO1xuXHR1c2VybmFtZTogc3RyaW5nO1xuXHRwYXNzd29yZDogc3RyaW5nO1xuXHRlbWFpbDogc3RyaW5nO1xuXHRpc0FjY291bnRWZXJpZmllZDogYm9vbGVhbjtcblx0cmVzZXRQYXNzd29yZFRva2VuPzogc3RyaW5nIHwgbnVsbDtcblx0cmVzZXRQYXNzd29yZEV4cGlyZXM/OiBEYXRlIHwgbnVsbDtcblx0aXNNZmFFbmFibGVkOiBib29sZWFuO1xuXHRjcmVhdGlvbkRhdGU6IERhdGU7XG59XG5cbmNsYXNzIFVzZXJcblx0ZXh0ZW5kcyBNb2RlbDxJbmZlckF0dHJpYnV0ZXM8VXNlcj4sIEluZmVyQ3JlYXRpb25BdHRyaWJ1dGVzPFVzZXI+PlxuXHRpbXBsZW1lbnRzIFVzZXJBdHRyaWJ1dGVzXG57XG5cdGlkITogc3RyaW5nO1xuXHR1c2VyaWQ/OiBudW1iZXI7XG5cdHVzZXJuYW1lITogc3RyaW5nO1xuXHRwYXNzd29yZCE6IHN0cmluZztcblx0ZW1haWwhOiBzdHJpbmc7XG5cdGlzQWNjb3VudFZlcmlmaWVkITogYm9vbGVhbjtcblx0cmVzZXRQYXNzd29yZFRva2VuITogc3RyaW5nIHwgbnVsbDtcblx0cmVzZXRQYXNzd29yZEV4cGlyZXMhOiBEYXRlIHwgbnVsbDtcblx0aXNNZmFFbmFibGVkITogYm9vbGVhbjtcblx0Y3JlYXRpb25EYXRlITogRGF0ZTtcblxuXHQvLyBNZXRob2QgdG8gY29tcGFyZSBwYXNzd29yZHNcblx0YXN5bmMgY29tcGFyZVBhc3N3b3JkKHBhc3N3b3JkOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+IHtcblx0XHRjb25zdCBzZWNyZXRzID0gYXdhaXQgZ2V0U2VjcmV0cygpO1xuXHRcdHJldHVybiBhcmdvbjIudmVyaWZ5KHRoaXMucGFzc3dvcmQsIHBhc3N3b3JkICsgc2VjcmV0cy5QRVBQRVIpO1xuXHR9XG5cblx0Ly8gU3RhdGljIG1ldGhvZCB0byB2YWxpZGF0ZSBwYXNzd29yZHNcblx0c3RhdGljIHZhbGlkYXRlUGFzc3dvcmQocGFzc3dvcmQ6IHN0cmluZyk6IGJvb2xlYW4ge1xuXHRcdGNvbnN0IGlzVmFsaWRMZW5ndGggPSBwYXNzd29yZC5sZW5ndGggPj0gOCAmJiBwYXNzd29yZC5sZW5ndGggPD0gMTI4O1xuXHRcdGNvbnN0IGhhc1VwcGVyQ2FzZSA9IC9bQS1aXS8udGVzdChwYXNzd29yZCk7XG5cdFx0Y29uc3QgaGFzTG93ZXJDYXNlID0gL1thLXpdLy50ZXN0KHBhc3N3b3JkKTtcblx0XHRjb25zdCBoYXNOdW1iZXIgPSAvXFxkLy50ZXN0KHBhc3N3b3JkKTtcblx0XHRjb25zdCBoYXNTcGVjaWFsID0gL1teXFxkQS1aYS16XS8udGVzdChwYXNzd29yZCk7XG5cblx0XHRyZXR1cm4gKFxuXHRcdFx0aXNWYWxpZExlbmd0aCAmJlxuXHRcdFx0aGFzVXBwZXJDYXNlICYmXG5cdFx0XHRoYXNMb3dlckNhc2UgJiZcblx0XHRcdGhhc051bWJlciAmJlxuXHRcdFx0aGFzU3BlY2lhbFxuXHRcdCk7XG5cdH1cblxuXHQvLyBTdGF0aWMgbWV0aG9kIHRvIGNyZWF0ZSBhIG5ldyB1c2VyXG5cdHN0YXRpYyBhc3luYyBjcmVhdGVVc2VyKFxuXHRcdHVzZXJuYW1lOiBzdHJpbmcsXG5cdFx0cGFzc3dvcmQ6IHN0cmluZyxcblx0XHRlbWFpbDogc3RyaW5nXG5cdCk6IFByb21pc2U8VXNlcj4ge1xuXHRcdGNvbnN0IGlzVmFsaWRQYXNzd29yZCA9IFVzZXIudmFsaWRhdGVQYXNzd29yZChwYXNzd29yZCk7XG5cdFx0aWYgKCFpc1ZhbGlkUGFzc3dvcmQpIHtcblx0XHRcdHRocm93IG5ldyBFcnJvcihcblx0XHRcdFx0J1Bhc3N3b3JkIGRvZXMgbm90IG1lZXQgdGhlIHNlY3VyaXR5IHJlcXVpcmVtZW50cy4nXG5cdFx0XHQpO1xuXHRcdH1cblxuXHRcdGNvbnN0IG5ld1VzZXIgPSBhd2FpdCBVc2VyLmNyZWF0ZSh7XG5cdFx0XHRpZDogdXVpZHY0KCksXG5cdFx0XHR1c2VybmFtZSxcblx0XHRcdHBhc3N3b3JkLFxuXHRcdFx0ZW1haWwsXG5cdFx0XHRpc0FjY291bnRWZXJpZmllZDogZmFsc2UsXG5cdFx0XHRyZXNldFBhc3N3b3JkVG9rZW46IG51bGwsIC8vIFNldCB0byBudWxsIGluaXRpYWxseVxuXHRcdFx0cmVzZXRQYXNzd29yZEV4cGlyZXM6IG51bGwsIC8vIFNldCB0byBudWxsIGluaXRpYWxseVxuXHRcdFx0aXNNZmFFbmFibGVkOiBmYWxzZSxcblx0XHRcdGNyZWF0aW9uRGF0ZTogbmV3IERhdGUoKVxuXHRcdH0pO1xuXG5cdFx0cmV0dXJuIG5ld1VzZXI7XG5cdH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgVXNlcjtcbiJdfQ==