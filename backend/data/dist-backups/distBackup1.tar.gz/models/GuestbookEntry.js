import { Model } from 'sequelize';
class GuestbookEntry extends Model {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "id", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "guestName", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "guestEmail", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "guestMessage", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "guestMessageStyles", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "entryDate", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
    }
}
export default GuestbookEntry;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiR3Vlc3Rib29rRW50cnkuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvbW9kZWxzL0d1ZXN0Ym9va0VudHJ5LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFJTixLQUFLLEVBQ0wsTUFBTSxXQUFXLENBQUM7QUFXbkIsTUFBTSxjQUNMLFNBQVEsS0FHUDtJQUpGOztRQU9DOzs7OztXQUFZO1FBQ1o7Ozs7O1dBQTBCO1FBQzFCOzs7OztXQUEyQjtRQUMzQjs7Ozs7V0FBc0I7UUFDdEI7Ozs7O1dBQW1DO1FBQ25DOzs7OztXQUFtQztJQUNwQyxDQUFDO0NBQUE7QUFFRCxlQUFlLGNBQWMsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG5cdENyZWF0aW9uT3B0aW9uYWwsXG5cdEluZmVyQXR0cmlidXRlcyxcblx0SW5mZXJDcmVhdGlvbkF0dHJpYnV0ZXMsXG5cdE1vZGVsXG59IGZyb20gJ3NlcXVlbGl6ZSc7XG5cbmludGVyZmFjZSBHdWVzdGJvb2tFbnRyeUF0dHJpYnV0ZXMge1xuXHRpZDogc3RyaW5nO1xuXHRndWVzdE5hbWU/OiBzdHJpbmcgfCBudWxsO1xuXHRndWVzdEVtYWlsPzogc3RyaW5nIHwgbnVsbDtcblx0Z3Vlc3RNZXNzYWdlOiBzdHJpbmc7XG5cdGd1ZXN0TWVzc2FnZVN0eWxlcz86IG9iamVjdCB8IG51bGw7XG5cdGVudHJ5RGF0ZTogRGF0ZTtcbn1cblxuY2xhc3MgR3Vlc3Rib29rRW50cnlcblx0ZXh0ZW5kcyBNb2RlbDxcblx0XHRJbmZlckF0dHJpYnV0ZXM8R3Vlc3Rib29rRW50cnk+LFxuXHRcdEluZmVyQ3JlYXRpb25BdHRyaWJ1dGVzPEd1ZXN0Ym9va0VudHJ5PlxuXHQ+XG5cdGltcGxlbWVudHMgR3Vlc3Rib29rRW50cnlBdHRyaWJ1dGVzXG57XG5cdGlkITogc3RyaW5nO1xuXHRndWVzdE5hbWUhOiBzdHJpbmcgfCBudWxsO1xuXHRndWVzdEVtYWlsITogc3RyaW5nIHwgbnVsbDtcblx0Z3Vlc3RNZXNzYWdlITogc3RyaW5nO1xuXHRndWVzdE1lc3NhZ2VTdHlsZXMhOiBvYmplY3QgfCBudWxsO1xuXHRlbnRyeURhdGUhOiBDcmVhdGlvbk9wdGlvbmFsPERhdGU+O1xufVxuXG5leHBvcnQgZGVmYXVsdCBHdWVzdGJvb2tFbnRyeTtcbiJdfQ==