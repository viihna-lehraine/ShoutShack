import { Model } from 'sequelize';
class MultiFactorAuthSetup extends Model {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "mfaId", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "id", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "userId", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "method", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "secret", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "publicKey", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "counter", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "isActive", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "createdAt", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "updatedAt", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
    }
}
export default MultiFactorAuthSetup;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTXVsdGlGYWN0b3JBdXRoU2V0dXAuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvbW9kZWxzL011bHRpRmFjdG9yQXV0aFNldHVwLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFJTixLQUFLLEVBQ0wsTUFBTSxXQUFXLENBQUM7QUFlbkIsTUFBTSxvQkFDTCxTQUFRLEtBR1A7SUFKRjs7UUFPQzs7Ozs7V0FBZTtRQUNmOzs7OztXQUFZO1FBQ1o7Ozs7O1dBQWdCO1FBQ2hCOzs7OztXQUEyRDtRQUMzRDs7Ozs7V0FBdUI7UUFDdkI7Ozs7O1dBQTBCO1FBQzFCOzs7OztXQUF3QjtRQUN4Qjs7Ozs7V0FBbUI7UUFDbkI7Ozs7O1dBQW1DO1FBQ25DOzs7OztXQUFtQztJQUNwQyxDQUFDO0NBQUE7QUFFRCxlQUFlLG9CQUFvQixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcblx0Q3JlYXRpb25PcHRpb25hbCxcblx0SW5mZXJBdHRyaWJ1dGVzLFxuXHRJbmZlckNyZWF0aW9uQXR0cmlidXRlcyxcblx0TW9kZWxcbn0gZnJvbSAnc2VxdWVsaXplJztcblxuaW50ZXJmYWNlIE11bHRpRmFjdG9yQXV0aFNldHVwQXR0cmlidXRlcyB7XG5cdG1mYUlkOiBudW1iZXI7XG5cdGlkOiBzdHJpbmc7XG5cdHVzZXJJZDogc3RyaW5nO1xuXHRtZXRob2Q6ICd0b3RwJyB8ICdlbWFpbCcgfCAneXViaWNvJyB8ICdmaWRvMicgfCAncGFzc2tleSc7XG5cdHNlY3JldD86IHN0cmluZyB8IG51bGw7XG5cdHB1YmxpY0tleT86IHN0cmluZyB8IG51bGw7XG5cdGNvdW50ZXI/OiBudW1iZXIgfCBudWxsO1xuXHRpc0FjdGl2ZTogYm9vbGVhbjtcblx0Y3JlYXRlZEF0OiBEYXRlO1xuXHR1cGRhdGVkQXQ6IERhdGU7XG59XG5cbmNsYXNzIE11bHRpRmFjdG9yQXV0aFNldHVwXG5cdGV4dGVuZHMgTW9kZWw8XG5cdFx0SW5mZXJBdHRyaWJ1dGVzPE11bHRpRmFjdG9yQXV0aFNldHVwPixcblx0XHRJbmZlckNyZWF0aW9uQXR0cmlidXRlczxNdWx0aUZhY3RvckF1dGhTZXR1cD5cblx0PlxuXHRpbXBsZW1lbnRzIE11bHRpRmFjdG9yQXV0aFNldHVwQXR0cmlidXRlc1xue1xuXHRtZmFJZCE6IG51bWJlcjtcblx0aWQhOiBzdHJpbmc7XG5cdHVzZXJJZCE6IHN0cmluZztcblx0bWV0aG9kITogJ3RvdHAnIHwgJ2VtYWlsJyB8ICd5dWJpY28nIHwgJ2ZpZG8yJyB8ICdwYXNza2V5Jztcblx0c2VjcmV0ITogc3RyaW5nIHwgbnVsbDtcblx0cHVibGljS2V5ITogc3RyaW5nIHwgbnVsbDtcblx0Y291bnRlciE6IG51bWJlciB8IG51bGw7XG5cdGlzQWN0aXZlITogYm9vbGVhbjtcblx0Y3JlYXRlZEF0ITogQ3JlYXRpb25PcHRpb25hbDxEYXRlPjtcblx0dXBkYXRlZEF0ITogQ3JlYXRpb25PcHRpb25hbDxEYXRlPjtcbn1cblxuZXhwb3J0IGRlZmF1bHQgTXVsdGlGYWN0b3JBdXRoU2V0dXA7XG4iXX0=