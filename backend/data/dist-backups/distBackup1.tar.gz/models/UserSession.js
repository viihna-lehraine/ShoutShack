import { Model } from 'sequelize';
class UserSession extends Model {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "id", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "sessionId", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "userId", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "ipAddress", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "userAgent", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "createdAt", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "updatedAt", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "expiresAt", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "isActive", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
    }
}
export default UserSession;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiVXNlclNlc3Npb24uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvbW9kZWxzL1VzZXJTZXNzaW9uLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFJTixLQUFLLEVBQ0wsTUFBTSxXQUFXLENBQUM7QUFjbkIsTUFBTSxXQUNMLFNBQVEsS0FHUDtJQUpGOztRQU9DOzs7OztXQUFZO1FBQ1o7Ozs7O1dBQW1CO1FBQ25COzs7OztXQUFnQjtRQUNoQjs7Ozs7V0FBbUI7UUFDbkI7Ozs7O1dBQW1CO1FBQ25COzs7OztXQUFtQztRQUNuQzs7Ozs7V0FBd0I7UUFDeEI7Ozs7O1dBQWlCO1FBQ2pCOzs7OztXQUFtQjtJQUNwQixDQUFDO0NBQUE7QUFFRCxlQUFlLFdBQVcsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG5cdENyZWF0aW9uT3B0aW9uYWwsXG5cdEluZmVyQXR0cmlidXRlcyxcblx0SW5mZXJDcmVhdGlvbkF0dHJpYnV0ZXMsXG5cdE1vZGVsXG59IGZyb20gJ3NlcXVlbGl6ZSc7XG5cbmludGVyZmFjZSBVc2VyU2Vzc2lvbkF0dHJpYnV0ZXMge1xuXHRpZDogc3RyaW5nO1xuXHRzZXNzaW9uSWQ6IG51bWJlcjtcblx0dXNlcklkOiBzdHJpbmc7XG5cdGlwQWRkcmVzczogc3RyaW5nO1xuXHR1c2VyQWdlbnQ6IHN0cmluZztcblx0Y3JlYXRlZEF0OiBEYXRlO1xuXHR1cGRhdGVkQXQ/OiBEYXRlIHwgbnVsbDtcblx0ZXhwaXJlc0F0OiBEYXRlO1xuXHRpc0FjdGl2ZTogYm9vbGVhbjtcbn1cblxuY2xhc3MgVXNlclNlc3Npb25cblx0ZXh0ZW5kcyBNb2RlbDxcblx0XHRJbmZlckF0dHJpYnV0ZXM8VXNlclNlc3Npb24+LFxuXHRcdEluZmVyQ3JlYXRpb25BdHRyaWJ1dGVzPFVzZXJTZXNzaW9uPlxuXHQ+XG5cdGltcGxlbWVudHMgVXNlclNlc3Npb25BdHRyaWJ1dGVzXG57XG5cdGlkITogc3RyaW5nO1xuXHRzZXNzaW9uSWQhOiBudW1iZXI7XG5cdHVzZXJJZCE6IHN0cmluZztcblx0aXBBZGRyZXNzITogc3RyaW5nO1xuXHR1c2VyQWdlbnQhOiBzdHJpbmc7XG5cdGNyZWF0ZWRBdCE6IENyZWF0aW9uT3B0aW9uYWw8RGF0ZT47XG5cdHVwZGF0ZWRBdCE6IERhdGUgfCBudWxsO1xuXHRleHBpcmVzQXQhOiBEYXRlO1xuXHRpc0FjdGl2ZSE6IGJvb2xlYW47XG59XG5cbmV4cG9ydCBkZWZhdWx0IFVzZXJTZXNzaW9uO1xuIl19