import { __awaiter } from "tslib";
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import getSecrets from '../../config/secrets.js';
let secrets;
function getSecretsOrThrow() {
    return __awaiter(this, void 0, void 0, function* () {
        if (!secrets) {
            secrets = yield getSecrets();
            if (!secrets) {
                throw new Error('Secrets could not be loaded');
            }
        }
        return secrets;
    });
}
function generateEmail2FACode() {
    return __awaiter(this, void 0, void 0, function* () {
        let secrets = yield getSecretsOrThrow();
        let email2FACode = yield bcrypt.genSalt(6); // generates a 6-character hex code
        let email2FAToken = jwt.sign({ email2FACode }, secrets.EMAIL_2FA_KEY, {
            expiresIn: '30m'
        });
        return {
            email2FACode, // raw 2FA code
            email2FAToken // JWT containing the 2FA code
        };
    });
}
function verifyEmail2FACode(token, email2FACode) {
    return __awaiter(this, void 0, void 0, function* () {
        let secrets = yield getSecretsOrThrow();
        try {
            let decodedEmail2FACode = jwt.verify(token, secrets.EMAIL_2FA_KEY);
            // ensue the decoded 2FA code matches the one provided
            return decodedEmail2FACode.code === email2FACode;
        }
        catch (err) {
            console.error(err);
            return false;
        }
    });
}
export { generateEmail2FACode, verifyEmail2FACode };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZW1haWwyRkFVdGlsLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL3V0aWxzL2F1dGgvZW1haWwyRkFVdGlsLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxPQUFPLE1BQU0sTUFBTSxRQUFRLENBQUM7QUFDNUIsT0FBTyxHQUFtQixNQUFNLGNBQWMsQ0FBQztBQUMvQyxPQUFPLFVBQVUsTUFBTSx5QkFBeUIsQ0FBQztBQU1qRCxJQUFJLE9BQTRCLENBQUM7QUFFakMsU0FBZSxpQkFBaUI7O1FBQy9CLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUNkLE9BQU8sR0FBRyxNQUFNLFVBQVUsRUFBRSxDQUFDO1lBQzdCLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztnQkFDZCxNQUFNLElBQUksS0FBSyxDQUFDLDZCQUE2QixDQUFDLENBQUM7WUFDaEQsQ0FBQztRQUNGLENBQUM7UUFFRCxPQUFPLE9BQU8sQ0FBQztJQUNoQixDQUFDO0NBQUE7QUFFRCxTQUFlLG9CQUFvQjs7UUFDbEMsSUFBSSxPQUFPLEdBQUcsTUFBTSxpQkFBaUIsRUFBRSxDQUFDO1FBRXhDLElBQUksWUFBWSxHQUFHLE1BQU0sTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG1DQUFtQztRQUMvRSxJQUFJLGFBQWEsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsWUFBWSxFQUFFLEVBQUUsT0FBTyxDQUFDLGFBQWEsRUFBRTtZQUNyRSxTQUFTLEVBQUUsS0FBSztTQUNoQixDQUFDLENBQUM7UUFDSCxPQUFPO1lBQ04sWUFBWSxFQUFFLGVBQWU7WUFDN0IsYUFBYSxDQUFDLDhCQUE4QjtTQUM1QyxDQUFDO0lBQ0gsQ0FBQztDQUFBO0FBRUQsU0FBZSxrQkFBa0IsQ0FBQyxLQUFhLEVBQUUsWUFBb0I7O1FBQ3BFLElBQUksT0FBTyxHQUFHLE1BQU0saUJBQWlCLEVBQUUsQ0FBQztRQUV4QyxJQUFJLENBQUM7WUFDSixJQUFJLG1CQUFtQixHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQ25DLEtBQUssRUFDTCxPQUFPLENBQUMsYUFBYSxDQUNQLENBQUM7WUFFaEIsc0RBQXNEO1lBQ3RELE9BQU8sbUJBQW1CLENBQUMsSUFBSSxLQUFLLFlBQVksQ0FBQztRQUNsRCxDQUFDO1FBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztZQUNkLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDbkIsT0FBTyxLQUFLLENBQUM7UUFDZCxDQUFDO0lBQ0YsQ0FBQztDQUFBO0FBRUQsT0FBTyxFQUFFLG9CQUFvQixFQUFFLGtCQUFrQixFQUFFLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgYmNyeXB0IGZyb20gJ2JjcnlwdCc7XG5pbXBvcnQgand0LCB7IEp3dFBheWxvYWQgfSBmcm9tICdqc29ud2VidG9rZW4nO1xuaW1wb3J0IGdldFNlY3JldHMgZnJvbSAnLi4vLi4vY29uZmlnL3NlY3JldHMuanMnO1xuXG5pbnRlcmZhY2UgU2VjcmV0cyB7XG5cdEVNQUlMXzJGQV9LRVk6IHN0cmluZztcbn1cblxubGV0IHNlY3JldHM6IFNlY3JldHMgfCB1bmRlZmluZWQ7XG5cbmFzeW5jIGZ1bmN0aW9uIGdldFNlY3JldHNPclRocm93KCk6IFByb21pc2U8U2VjcmV0cz4ge1xuXHRpZiAoIXNlY3JldHMpIHtcblx0XHRzZWNyZXRzID0gYXdhaXQgZ2V0U2VjcmV0cygpO1xuXHRcdGlmICghc2VjcmV0cykge1xuXHRcdFx0dGhyb3cgbmV3IEVycm9yKCdTZWNyZXRzIGNvdWxkIG5vdCBiZSBsb2FkZWQnKTtcblx0XHR9XG5cdH1cblxuXHRyZXR1cm4gc2VjcmV0cztcbn1cblxuYXN5bmMgZnVuY3Rpb24gZ2VuZXJhdGVFbWFpbDJGQUNvZGUoKSB7XG5cdGxldCBzZWNyZXRzID0gYXdhaXQgZ2V0U2VjcmV0c09yVGhyb3coKTtcblxuXHRsZXQgZW1haWwyRkFDb2RlID0gYXdhaXQgYmNyeXB0LmdlblNhbHQoNik7IC8vIGdlbmVyYXRlcyBhIDYtY2hhcmFjdGVyIGhleCBjb2RlXG5cdGxldCBlbWFpbDJGQVRva2VuID0gand0LnNpZ24oeyBlbWFpbDJGQUNvZGUgfSwgc2VjcmV0cy5FTUFJTF8yRkFfS0VZLCB7XG5cdFx0ZXhwaXJlc0luOiAnMzBtJ1xuXHR9KTtcblx0cmV0dXJuIHtcblx0XHRlbWFpbDJGQUNvZGUsIC8vIHJhdyAyRkEgY29kZVxuXHRcdGVtYWlsMkZBVG9rZW4gLy8gSldUIGNvbnRhaW5pbmcgdGhlIDJGQSBjb2RlXG5cdH07XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHZlcmlmeUVtYWlsMkZBQ29kZSh0b2tlbjogc3RyaW5nLCBlbWFpbDJGQUNvZGU6IHN0cmluZykge1xuXHRsZXQgc2VjcmV0cyA9IGF3YWl0IGdldFNlY3JldHNPclRocm93KCk7XG5cblx0dHJ5IHtcblx0XHRsZXQgZGVjb2RlZEVtYWlsMkZBQ29kZSA9IGp3dC52ZXJpZnkoXG5cdFx0XHR0b2tlbixcblx0XHRcdHNlY3JldHMuRU1BSUxfMkZBX0tFWVxuXHRcdCkgYXMgSnd0UGF5bG9hZDtcblxuXHRcdC8vIGVuc3VlIHRoZSBkZWNvZGVkIDJGQSBjb2RlIG1hdGNoZXMgdGhlIG9uZSBwcm92aWRlZFxuXHRcdHJldHVybiBkZWNvZGVkRW1haWwyRkFDb2RlLmNvZGUgPT09IGVtYWlsMkZBQ29kZTtcblx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0Y29uc29sZS5lcnJvcihlcnIpO1xuXHRcdHJldHVybiBmYWxzZTtcblx0fVxufVxuXG5leHBvcnQgeyBnZW5lcmF0ZUVtYWlsMkZBQ29kZSwgdmVyaWZ5RW1haWwyRkFDb2RlIH07XG4iXX0=