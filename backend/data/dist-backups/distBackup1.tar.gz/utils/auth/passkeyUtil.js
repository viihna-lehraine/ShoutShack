import { __awaiter } from "tslib";
import { Fido2Lib } from 'fido2-lib';
import getSecrets from '../../config/secrets.js';
let fido2;
(() => __awaiter(void 0, void 0, void 0, function* () {
    let secrets = yield getSecrets();
    if (!secrets) {
        throw new Error('Secrets could not be loaded');
    }
    fido2 = new Fido2Lib({
        timeout: 60000,
        rpId: secrets.RP_ID,
        rpName: secrets.RP_NAME,
        rpIcon: secrets.RP_ICON,
        challengeSize: secrets.FIDO_CHALLENGE_SIZE,
        attestation: 'direct',
        cryptoParams: secrets.FIDO_CRYPTO_PARAMETERS,
        authenticatorRequireResidentKey: secrets.FIDO_AUTHENTICATOR_REQUIRE_RESIDENT_KEY,
        authenticatorUserVerification: secrets.FIDO_AUTHENTICATOR_USER_VERIFICATION
    });
}))();
function generatePasskeyRegistrationOptions(user) {
    return __awaiter(this, void 0, void 0, function* () {
        let passkeyRegistrationOptions = yield fido2.attestationOptions();
        // constructing PublicKeyCredentialCreationOptions
        let credentialCreationOptions = Object.assign(Object.assign({}, passkeyRegistrationOptions), { user: {
                id: Buffer.from(user.id, 'utf8'),
                name: user.email,
                displayName: user.username
            }, authenticatorSelection: {
                authenticatorAttachment: 'platform',
                requireResidentKey: true,
                userVerification: 'required'
            } });
        return credentialCreationOptions;
    });
}
function verifyPasskeyRegistration(attestation, expectedChallenge) {
    return __awaiter(this, void 0, void 0, function* () {
        let secrets = yield getSecrets();
        if (!secrets) {
            throw new Error('Secrets could not be loaded');
        }
        let attestationExpectations = {
            challenge: expectedChallenge,
            origin: secrets.RP_ORIGIN,
            factor: 'either', // 'factor` type should match as defined in the library
            rpId: secrets.RP_ID
        };
        return yield fido2.attestationResult(attestation, attestationExpectations);
    });
}
function generatePasskeyAuthenticationOptions(user) {
    return __awaiter(this, void 0, void 0, function* () {
        let userCredentials = user.credential.map((cred) => ({
            type: 'public-key', // ensures 'public-key' is strictly typed
            id: Buffer.from(cred.credentialId, 'base64'),
            transports: ['usb', 'nfc', 'ble'] // *DEV-NOTE* these are just example transports!
        }));
        let assertionOptions = Object.assign(Object.assign({}, (yield fido2.assertionOptions())), { allowCredentials: userCredentials, userVerification: 'required', timeout: 60000 });
        return assertionOptions;
    });
}
function verifyPasskeyAuthentication(assertion, expectedChallenge, publicKey, previousCounter, id) {
    return __awaiter(this, void 0, void 0, function* () {
        let secrets = yield getSecrets();
        if (!secrets) {
            throw new Error('Secrets could not be loaded');
        }
        let assertionExpectations = {
            challenge: expectedChallenge,
            origin: secrets.RP_ORIGIN,
            factor: 'either',
            publicKey: publicKey,
            prevCounter: previousCounter,
            userHandle: id
        };
        return yield fido2.assertionResult(assertion, assertionExpectations);
    });
}
export { generatePasskeyAuthenticationOptions, generatePasskeyRegistrationOptions, verifyPasskeyAuthentication, verifyPasskeyRegistration };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFzc2tleVV0aWwuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvdXRpbHMvYXV0aC9wYXNza2V5VXRpbC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUtOLFFBQVEsRUFFUixNQUFNLFdBQVcsQ0FBQztBQUNuQixPQUFPLFVBQVUsTUFBTSx5QkFBeUIsQ0FBQztBQTJCakQsSUFBSSxLQUFlLENBQUM7QUFFcEIsQ0FBQyxHQUFTLEVBQUU7SUFDWCxJQUFJLE9BQU8sR0FBWSxNQUFNLFVBQVUsRUFBRSxDQUFDO0lBRTFDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUNkLE1BQU0sSUFBSSxLQUFLLENBQUMsNkJBQTZCLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBRUQsS0FBSyxHQUFHLElBQUksUUFBUSxDQUFDO1FBQ3BCLE9BQU8sRUFBRSxLQUFLO1FBQ2QsSUFBSSxFQUFFLE9BQU8sQ0FBQyxLQUFLO1FBQ25CLE1BQU0sRUFBRSxPQUFPLENBQUMsT0FBTztRQUN2QixNQUFNLEVBQUUsT0FBTyxDQUFDLE9BQU87UUFDdkIsYUFBYSxFQUFFLE9BQU8sQ0FBQyxtQkFBbUI7UUFDMUMsV0FBVyxFQUFFLFFBQVE7UUFDckIsWUFBWSxFQUFFLE9BQU8sQ0FBQyxzQkFBc0I7UUFDNUMsK0JBQStCLEVBQzlCLE9BQU8sQ0FBQyx1Q0FBdUM7UUFDaEQsNkJBQTZCLEVBQzVCLE9BQU8sQ0FBQyxvQ0FBb0M7S0FDN0MsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFBLENBQUMsRUFBRSxDQUFDO0FBRUwsU0FBZSxrQ0FBa0MsQ0FDaEQsSUFBVTs7UUFFVixJQUFJLDBCQUEwQixHQUFHLE1BQU0sS0FBSyxDQUFDLGtCQUFrQixFQUFFLENBQUM7UUFFbEUsa0RBQWtEO1FBQ2xELElBQUkseUJBQXlCLG1DQUN6QiwwQkFBMEIsS0FDN0IsSUFBSSxFQUFFO2dCQUNMLEVBQUUsRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsTUFBTSxDQUFDO2dCQUNoQyxJQUFJLEVBQUUsSUFBSSxDQUFDLEtBQUs7Z0JBQ2hCLFdBQVcsRUFBRSxJQUFJLENBQUMsUUFBUTthQUMxQixFQUNELHNCQUFzQixFQUFFO2dCQUN2Qix1QkFBdUIsRUFBRSxVQUFVO2dCQUNuQyxrQkFBa0IsRUFBRSxJQUFJO2dCQUN4QixnQkFBZ0IsRUFBRSxVQUFVO2FBQzVCLEdBQ0QsQ0FBQztRQUVGLE9BQU8seUJBQXlCLENBQUM7SUFDbEMsQ0FBQztDQUFBO0FBRUQsU0FBZSx5QkFBeUIsQ0FDdkMsV0FBOEIsRUFDOUIsaUJBQXlCOztRQUV6QixJQUFJLE9BQU8sR0FBWSxNQUFNLFVBQVUsRUFBRSxDQUFDO1FBRTFDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUNkLE1BQU0sSUFBSSxLQUFLLENBQUMsNkJBQTZCLENBQUMsQ0FBQztRQUNoRCxDQUFDO1FBRUQsSUFBSSx1QkFBdUIsR0FBOEI7WUFDeEQsU0FBUyxFQUFFLGlCQUFpQjtZQUM1QixNQUFNLEVBQUUsT0FBTyxDQUFDLFNBQVM7WUFDekIsTUFBTSxFQUFFLFFBQVEsRUFBRSx1REFBdUQ7WUFDekUsSUFBSSxFQUFFLE9BQU8sQ0FBQyxLQUFLO1NBQ25CLENBQUM7UUFFRixPQUFPLE1BQU0sS0FBSyxDQUFDLGlCQUFpQixDQUFDLFdBQVcsRUFBRSx1QkFBdUIsQ0FBQyxDQUFDO0lBQzVFLENBQUM7Q0FBQTtBQUVELFNBQWUsb0NBQW9DLENBQ2xELElBQVU7O1FBRVYsSUFBSSxlQUFlLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFDcEQsSUFBSSxFQUFFLFlBQXFCLEVBQUUseUNBQXlDO1lBQ3RFLEVBQUUsRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsUUFBUSxDQUFDO1lBQzVDLFVBQVUsRUFBRSxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUE2QixDQUFDLGdEQUFnRDtTQUM5RyxDQUFDLENBQUMsQ0FBQztRQUVKLElBQUksZ0JBQWdCLG1DQUNoQixDQUFDLE1BQU0sS0FBSyxDQUFDLGdCQUFnQixFQUFFLENBQUMsS0FDbkMsZ0JBQWdCLEVBQUUsZUFBZSxFQUNqQyxnQkFBZ0IsRUFBRSxVQUFVLEVBQzVCLE9BQU8sRUFBRSxLQUFLLEdBQ2QsQ0FBQztRQUVGLE9BQU8sZ0JBQWdCLENBQUM7SUFDekIsQ0FBQztDQUFBO0FBRUQsU0FBZSwyQkFBMkIsQ0FDekMsU0FBMEIsRUFDMUIsaUJBQXlCLEVBQ3pCLFNBQWlCLEVBQ2pCLGVBQXVCLEVBQ3ZCLEVBQVU7O1FBRVYsSUFBSSxPQUFPLEdBQVksTUFBTSxVQUFVLEVBQUUsQ0FBQztRQUUxQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDZCxNQUFNLElBQUksS0FBSyxDQUFDLDZCQUE2QixDQUFDLENBQUM7UUFDaEQsQ0FBQztRQUVELElBQUkscUJBQXFCLEdBQTRCO1lBQ3BELFNBQVMsRUFBRSxpQkFBaUI7WUFDNUIsTUFBTSxFQUFFLE9BQU8sQ0FBQyxTQUFTO1lBQ3pCLE1BQU0sRUFBRSxRQUFRO1lBQ2hCLFNBQVMsRUFBRSxTQUFTO1lBQ3BCLFdBQVcsRUFBRSxlQUFlO1lBQzVCLFVBQVUsRUFBRSxFQUFFO1NBQ2QsQ0FBQztRQUVGLE9BQU8sTUFBTSxLQUFLLENBQUMsZUFBZSxDQUFDLFNBQVMsRUFBRSxxQkFBcUIsQ0FBQyxDQUFDO0lBQ3RFLENBQUM7Q0FBQTtBQUVELE9BQU8sRUFDTixvQ0FBb0MsRUFDcEMsa0NBQWtDLEVBQ2xDLDJCQUEyQixFQUMzQix5QkFBeUIsRUFDekIsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG5cdEFzc2VydGlvblJlc3VsdCxcblx0QXR0ZXN0YXRpb25SZXN1bHQsXG5cdEV4cGVjdGVkQXNzZXJ0aW9uUmVzdWx0LFxuXHRFeHBlY3RlZEF0dGVzdGF0aW9uUmVzdWx0LFxuXHRGaWRvMkxpYixcblx0UHVibGljS2V5Q3JlZGVudGlhbENyZWF0aW9uT3B0aW9uc1xufSBmcm9tICdmaWRvMi1saWInO1xuaW1wb3J0IGdldFNlY3JldHMgZnJvbSAnLi4vLi4vY29uZmlnL3NlY3JldHMuanMnO1xuXG5pbnRlcmZhY2UgVXNlciB7XG5cdGlkOiBzdHJpbmc7XG5cdGVtYWlsOiBzdHJpbmc7XG5cdHVzZXJuYW1lOiBzdHJpbmc7XG5cdGNyZWRlbnRpYWw6IHtcblx0XHRjcmVkZW50aWFsSWQ6IHN0cmluZztcblx0fVtdO1xufVxuXG5pbnRlcmZhY2UgU2VjcmV0cyB7XG5cdFJQX0lEOiBzdHJpbmc7XG5cdFJQX05BTUU6IHN0cmluZztcblx0UlBfSUNPTjogc3RyaW5nO1xuXHRSUF9PUklHSU46IHN0cmluZztcblx0RklET19DSEFMTEVOR0VfU0laRTogbnVtYmVyO1xuXHRGSURPX0NSWVBUT19QQVJBTUVURVJTOiBudW1iZXJbXTtcblx0RklET19BVVRIRU5USUNBVE9SX1JFUVVJUkVfUkVTSURFTlRfS0VZOiBib29sZWFuO1xuXHRGSURPX0FVVEhFTlRJQ0FUT1JfVVNFUl9WRVJJRklDQVRJT046XG5cdFx0fCAncmVxdWlyZWQnXG5cdFx0fCAncHJlZmVycmVkJ1xuXHRcdHwgJ2Rpc2NvdXJhZ2VkJztcbn1cblxudHlwZSBBdXRoZW50aWNhdG9yVHJhbnNwb3J0ID0gJ3VzYicgfCAnbmZjJyB8ICdibGUnIHwgJ2ludGVybmFsJztcblxubGV0IGZpZG8yOiBGaWRvMkxpYjtcblxuKGFzeW5jICgpID0+IHtcblx0bGV0IHNlY3JldHM6IFNlY3JldHMgPSBhd2FpdCBnZXRTZWNyZXRzKCk7XG5cblx0aWYgKCFzZWNyZXRzKSB7XG5cdFx0dGhyb3cgbmV3IEVycm9yKCdTZWNyZXRzIGNvdWxkIG5vdCBiZSBsb2FkZWQnKTtcblx0fVxuXG5cdGZpZG8yID0gbmV3IEZpZG8yTGliKHtcblx0XHR0aW1lb3V0OiA2MDAwMCxcblx0XHRycElkOiBzZWNyZXRzLlJQX0lELFxuXHRcdHJwTmFtZTogc2VjcmV0cy5SUF9OQU1FLFxuXHRcdHJwSWNvbjogc2VjcmV0cy5SUF9JQ09OLFxuXHRcdGNoYWxsZW5nZVNpemU6IHNlY3JldHMuRklET19DSEFMTEVOR0VfU0laRSxcblx0XHRhdHRlc3RhdGlvbjogJ2RpcmVjdCcsXG5cdFx0Y3J5cHRvUGFyYW1zOiBzZWNyZXRzLkZJRE9fQ1JZUFRPX1BBUkFNRVRFUlMsXG5cdFx0YXV0aGVudGljYXRvclJlcXVpcmVSZXNpZGVudEtleTpcblx0XHRcdHNlY3JldHMuRklET19BVVRIRU5USUNBVE9SX1JFUVVJUkVfUkVTSURFTlRfS0VZLFxuXHRcdGF1dGhlbnRpY2F0b3JVc2VyVmVyaWZpY2F0aW9uOlxuXHRcdFx0c2VjcmV0cy5GSURPX0FVVEhFTlRJQ0FUT1JfVVNFUl9WRVJJRklDQVRJT05cblx0fSk7XG59KSgpO1xuXG5hc3luYyBmdW5jdGlvbiBnZW5lcmF0ZVBhc3NrZXlSZWdpc3RyYXRpb25PcHRpb25zKFxuXHR1c2VyOiBVc2VyXG4pOiBQcm9taXNlPFB1YmxpY0tleUNyZWRlbnRpYWxDcmVhdGlvbk9wdGlvbnM+IHtcblx0bGV0IHBhc3NrZXlSZWdpc3RyYXRpb25PcHRpb25zID0gYXdhaXQgZmlkbzIuYXR0ZXN0YXRpb25PcHRpb25zKCk7XG5cblx0Ly8gY29uc3RydWN0aW5nIFB1YmxpY0tleUNyZWRlbnRpYWxDcmVhdGlvbk9wdGlvbnNcblx0bGV0IGNyZWRlbnRpYWxDcmVhdGlvbk9wdGlvbnM6IFB1YmxpY0tleUNyZWRlbnRpYWxDcmVhdGlvbk9wdGlvbnMgPSB7XG5cdFx0Li4ucGFzc2tleVJlZ2lzdHJhdGlvbk9wdGlvbnMsXG5cdFx0dXNlcjoge1xuXHRcdFx0aWQ6IEJ1ZmZlci5mcm9tKHVzZXIuaWQsICd1dGY4JyksXG5cdFx0XHRuYW1lOiB1c2VyLmVtYWlsLFxuXHRcdFx0ZGlzcGxheU5hbWU6IHVzZXIudXNlcm5hbWVcblx0XHR9LFxuXHRcdGF1dGhlbnRpY2F0b3JTZWxlY3Rpb246IHtcblx0XHRcdGF1dGhlbnRpY2F0b3JBdHRhY2htZW50OiAncGxhdGZvcm0nLFxuXHRcdFx0cmVxdWlyZVJlc2lkZW50S2V5OiB0cnVlLFxuXHRcdFx0dXNlclZlcmlmaWNhdGlvbjogJ3JlcXVpcmVkJ1xuXHRcdH1cblx0fTtcblxuXHRyZXR1cm4gY3JlZGVudGlhbENyZWF0aW9uT3B0aW9ucztcbn1cblxuYXN5bmMgZnVuY3Rpb24gdmVyaWZ5UGFzc2tleVJlZ2lzdHJhdGlvbihcblx0YXR0ZXN0YXRpb246IEF0dGVzdGF0aW9uUmVzdWx0LFxuXHRleHBlY3RlZENoYWxsZW5nZTogc3RyaW5nXG4pIHtcblx0bGV0IHNlY3JldHM6IFNlY3JldHMgPSBhd2FpdCBnZXRTZWNyZXRzKCk7XG5cblx0aWYgKCFzZWNyZXRzKSB7XG5cdFx0dGhyb3cgbmV3IEVycm9yKCdTZWNyZXRzIGNvdWxkIG5vdCBiZSBsb2FkZWQnKTtcblx0fVxuXG5cdGxldCBhdHRlc3RhdGlvbkV4cGVjdGF0aW9uczogRXhwZWN0ZWRBdHRlc3RhdGlvblJlc3VsdCA9IHtcblx0XHRjaGFsbGVuZ2U6IGV4cGVjdGVkQ2hhbGxlbmdlLFxuXHRcdG9yaWdpbjogc2VjcmV0cy5SUF9PUklHSU4sXG5cdFx0ZmFjdG9yOiAnZWl0aGVyJywgLy8gJ2ZhY3RvcmAgdHlwZSBzaG91bGQgbWF0Y2ggYXMgZGVmaW5lZCBpbiB0aGUgbGlicmFyeVxuXHRcdHJwSWQ6IHNlY3JldHMuUlBfSURcblx0fTtcblxuXHRyZXR1cm4gYXdhaXQgZmlkbzIuYXR0ZXN0YXRpb25SZXN1bHQoYXR0ZXN0YXRpb24sIGF0dGVzdGF0aW9uRXhwZWN0YXRpb25zKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZ2VuZXJhdGVQYXNza2V5QXV0aGVudGljYXRpb25PcHRpb25zKFxuXHR1c2VyOiBVc2VyXG4pOiBQcm9taXNlPFB1YmxpY0tleUNyZWRlbnRpYWxSZXF1ZXN0T3B0aW9ucz4ge1xuXHRsZXQgdXNlckNyZWRlbnRpYWxzID0gdXNlci5jcmVkZW50aWFsLm1hcCgoY3JlZCkgPT4gKHtcblx0XHR0eXBlOiAncHVibGljLWtleScgYXMgY29uc3QsIC8vIGVuc3VyZXMgJ3B1YmxpYy1rZXknIGlzIHN0cmljdGx5IHR5cGVkXG5cdFx0aWQ6IEJ1ZmZlci5mcm9tKGNyZWQuY3JlZGVudGlhbElkLCAnYmFzZTY0JyksXG5cdFx0dHJhbnNwb3J0czogWyd1c2InLCAnbmZjJywgJ2JsZSddIGFzIEF1dGhlbnRpY2F0b3JUcmFuc3BvcnRbXSAvLyAqREVWLU5PVEUqIHRoZXNlIGFyZSBqdXN0IGV4YW1wbGUgdHJhbnNwb3J0cyFcblx0fSkpO1xuXG5cdGxldCBhc3NlcnRpb25PcHRpb25zOiBQdWJsaWNLZXlDcmVkZW50aWFsUmVxdWVzdE9wdGlvbnMgPSB7XG5cdFx0Li4uKGF3YWl0IGZpZG8yLmFzc2VydGlvbk9wdGlvbnMoKSksXG5cdFx0YWxsb3dDcmVkZW50aWFsczogdXNlckNyZWRlbnRpYWxzLFxuXHRcdHVzZXJWZXJpZmljYXRpb246ICdyZXF1aXJlZCcsXG5cdFx0dGltZW91dDogNjAwMDBcblx0fTtcblxuXHRyZXR1cm4gYXNzZXJ0aW9uT3B0aW9ucztcbn1cblxuYXN5bmMgZnVuY3Rpb24gdmVyaWZ5UGFzc2tleUF1dGhlbnRpY2F0aW9uKFxuXHRhc3NlcnRpb246IEFzc2VydGlvblJlc3VsdCxcblx0ZXhwZWN0ZWRDaGFsbGVuZ2U6IHN0cmluZyxcblx0cHVibGljS2V5OiBzdHJpbmcsXG5cdHByZXZpb3VzQ291bnRlcjogbnVtYmVyLFxuXHRpZDogc3RyaW5nXG4pIHtcblx0bGV0IHNlY3JldHM6IFNlY3JldHMgPSBhd2FpdCBnZXRTZWNyZXRzKCk7XG5cblx0aWYgKCFzZWNyZXRzKSB7XG5cdFx0dGhyb3cgbmV3IEVycm9yKCdTZWNyZXRzIGNvdWxkIG5vdCBiZSBsb2FkZWQnKTtcblx0fVxuXG5cdGxldCBhc3NlcnRpb25FeHBlY3RhdGlvbnM6IEV4cGVjdGVkQXNzZXJ0aW9uUmVzdWx0ID0ge1xuXHRcdGNoYWxsZW5nZTogZXhwZWN0ZWRDaGFsbGVuZ2UsXG5cdFx0b3JpZ2luOiBzZWNyZXRzLlJQX09SSUdJTixcblx0XHRmYWN0b3I6ICdlaXRoZXInLFxuXHRcdHB1YmxpY0tleTogcHVibGljS2V5LFxuXHRcdHByZXZDb3VudGVyOiBwcmV2aW91c0NvdW50ZXIsXG5cdFx0dXNlckhhbmRsZTogaWRcblx0fTtcblxuXHRyZXR1cm4gYXdhaXQgZmlkbzIuYXNzZXJ0aW9uUmVzdWx0KGFzc2VydGlvbiwgYXNzZXJ0aW9uRXhwZWN0YXRpb25zKTtcbn1cblxuZXhwb3J0IHtcblx0Z2VuZXJhdGVQYXNza2V5QXV0aGVudGljYXRpb25PcHRpb25zLFxuXHRnZW5lcmF0ZVBhc3NrZXlSZWdpc3RyYXRpb25PcHRpb25zLFxuXHR2ZXJpZnlQYXNza2V5QXV0aGVudGljYXRpb24sXG5cdHZlcmlmeVBhc3NrZXlSZWdpc3RyYXRpb25cbn07XG4iXX0=