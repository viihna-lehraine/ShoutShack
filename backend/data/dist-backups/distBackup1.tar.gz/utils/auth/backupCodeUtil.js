import { __awaiter } from "tslib";
import bcrypt from 'bcrypt';
import crypto from 'crypto';
import setupLogger from '../../middleware/logger.js';
import UserMfaModelPromise from '../../models/UserMfa.js';
// Generate Backup Coedes
function generateBackupCodes(id) {
    return __awaiter(this, void 0, void 0, function* () {
        let backupCodes = [];
        for (let i = 0; i < 16; i++) {
            let code = crypto.randomBytes(4).toString('hex'); // 8-character hex code
            let hashedCode = yield bcrypt.hash(code, 10);
            backupCodes.push({ code: hashedCode, used: false });
        }
        // store backupCodes in the database associated with the user's id
        yield saveBackupCodesToDatabase(id, backupCodes);
        // return only the plain codes as strings
        return backupCodes.map((backupCode) => backupCode.code);
    });
}
// Verify a Backup Code
function verifyBackupCode(id, inputCode) {
    return __awaiter(this, void 0, void 0, function* () {
        yield UserMfaModelPromise; // await the UserMfa model when needed
        let storedCodes = yield getBackupCodesFromDatabase(id);
        if (storedCodes) {
            for (let i = 0; i < storedCodes.length; i++) {
                let match = yield bcrypt.compare(inputCode, storedCodes[i].code);
                if (match && !storedCodes[i].used) {
                    storedCodes[i].used = true;
                    yield updateBackupCodesInDatabase(id, storedCodes); // mark the code as used
                    return true; // successful verification
                }
            }
        }
        else {
            console.error('No backup codes found for user');
            return false; // no backup codes found
        }
        return false; // verification failed
    });
}
// Save backup codes to the database
function saveBackupCodesToDatabase(id, backupCodes) {
    return __awaiter(this, void 0, void 0, function* () {
        let logger = yield setupLogger();
        let UserfMfa = yield UserMfaModelPromise; // await the UserMfa model when needed
        try {
            let user = yield UserfMfa.findByPk(id); // find user by primary key
            if (!user)
                throw new Error('User not found');
            // map the codes element of backupCodes to an array of strings
            let backupCodesAsStrings = backupCodes.map((codeObj) => codeObj.code);
            // assign the array of strings to user.backupCodes
            user.backupCodes = backupCodesAsStrings;
            yield user.save();
        }
        catch (err) {
            logger.error('Error saving backup codes to database: ', err);
            throw new Error('Failed to save backup codes to database');
        }
    });
}
// Get backup codes from the database
function getBackupCodesFromDatabase(id) {
    return __awaiter(this, void 0, void 0, function* () {
        let logger = yield setupLogger();
        let UserMfa = yield UserMfaModelPromise; // await the User model when needed
        try {
            let user = yield UserMfa.findByPk(id); // find user by primary key
            if (!user)
                throw new Error('User not found');
            // assume user.backupCodes is a string[] or null, convert it to BackuopCode[] or undefined
            let backupCodes = user.backupCodes;
            if (backupCodes === null) {
                return undefined; // *DEV-NOTE* probably need to configure this later
            }
            // convert string[] to BackupCode[]
            return backupCodes.map((code) => ({ code, used: false }));
        }
        catch (err) {
            logger.error('Error fetching backup codes from database: ', err);
            throw new Error('Failed to retrieve backup codes from database');
        }
    });
}
// Update backup codes in the database
function updateBackupCodesInDatabase(id, backupCodes) {
    return __awaiter(this, void 0, void 0, function* () {
        let logger = yield setupLogger();
        let UserMfa = yield UserMfaModelPromise; // await the UserMfa model when needed
        try {
            let user = yield UserMfa.findByPk(id); // find user by primary key
            if (!user)
                throw new Error('User not found');
            // map the codes element of backupCodes to an array of strings
            let backupCodesAsStrings = backupCodes.map((codeObj) => codeObj.code);
            // assign the array of strings to user.backupCodes
            user.backupCodes = backupCodesAsStrings;
            yield user.save();
        }
        catch (err) {
            logger.error('Error updating backup codes in database: ', err);
            throw new Error('Failed to update backup codes in database');
        }
    });
}
export { generateBackupCodes, getBackupCodesFromDatabase, saveBackupCodesToDatabase, verifyBackupCode };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFja3VwQ29kZVV0aWwuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvdXRpbHMvYXV0aC9iYWNrdXBDb2RlVXRpbC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxNQUFNLE1BQU0sUUFBUSxDQUFDO0FBQzVCLE9BQU8sTUFBTSxNQUFNLFFBQVEsQ0FBQztBQUM1QixPQUFPLFdBQVcsTUFBTSx5QkFBeUIsQ0FBQztBQUNsRCxPQUFPLG1CQUFtQixNQUFNLHNCQUFzQixDQUFDO0FBT3ZELHlCQUF5QjtBQUN6QixTQUFlLG1CQUFtQixDQUFDLEVBQVU7O1FBQzVDLElBQUksV0FBVyxHQUFpQixFQUFFLENBQUM7UUFDbkMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDO1lBQzdCLElBQUksSUFBSSxHQUFHLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsdUJBQXVCO1lBQ3pFLElBQUksVUFBVSxHQUFHLE1BQU0sTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFDN0MsV0FBVyxDQUFDLElBQUksQ0FBQyxFQUFFLElBQUksRUFBRSxVQUFVLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7UUFDckQsQ0FBQztRQUVELGtFQUFrRTtRQUNsRSxNQUFNLHlCQUF5QixDQUFDLEVBQUUsRUFBRSxXQUFXLENBQUMsQ0FBQztRQUVqRCx5Q0FBeUM7UUFDekMsT0FBTyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsVUFBVSxFQUFFLEVBQUUsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDekQsQ0FBQztDQUFBO0FBRUQsdUJBQXVCO0FBQ3ZCLFNBQWUsZ0JBQWdCLENBQzlCLEVBQVUsRUFDVixTQUFpQjs7UUFFakIsTUFBTSxtQkFBbUIsQ0FBQyxDQUFDLHNDQUFzQztRQUNqRSxJQUFJLFdBQVcsR0FBRyxNQUFNLDBCQUEwQixDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBRXZELElBQUksV0FBVyxFQUFFLENBQUM7WUFDakIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztnQkFDN0MsSUFBSSxLQUFLLEdBQUcsTUFBTSxNQUFNLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ2pFLElBQUksS0FBSyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO29CQUNuQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztvQkFDM0IsTUFBTSwyQkFBMkIsQ0FBQyxFQUFFLEVBQUUsV0FBVyxDQUFDLENBQUMsQ0FBQyx3QkFBd0I7b0JBQzVFLE9BQU8sSUFBSSxDQUFDLENBQUMsMEJBQTBCO2dCQUN4QyxDQUFDO1lBQ0YsQ0FBQztRQUNGLENBQUM7YUFBTSxDQUFDO1lBQ1AsT0FBTyxDQUFDLEtBQUssQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDO1lBQ2hELE9BQU8sS0FBSyxDQUFDLENBQUMsd0JBQXdCO1FBQ3ZDLENBQUM7UUFFRCxPQUFPLEtBQUssQ0FBQyxDQUFDLHNCQUFzQjtJQUNyQyxDQUFDO0NBQUE7QUFFRCxvQ0FBb0M7QUFDcEMsU0FBZSx5QkFBeUIsQ0FDdkMsRUFBVSxFQUNWLFdBQXlCOztRQUV6QixJQUFJLE1BQU0sR0FBRyxNQUFNLFdBQVcsRUFBRSxDQUFDO1FBQ2pDLElBQUksUUFBUSxHQUFHLE1BQU0sbUJBQW1CLENBQUMsQ0FBQyxzQ0FBc0M7UUFFaEYsSUFBSSxDQUFDO1lBQ0osSUFBSSxJQUFJLEdBQUcsTUFBTSxRQUFRLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsMkJBQTJCO1lBQ25FLElBQUksQ0FBQyxJQUFJO2dCQUFFLE1BQU0sSUFBSSxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztZQUU3Qyw4REFBOEQ7WUFDOUQsSUFBSSxvQkFBb0IsR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQUUsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7WUFFdEUsa0RBQWtEO1lBQ2xELElBQUksQ0FBQyxXQUFXLEdBQUcsb0JBQW9CLENBQUM7WUFDeEMsTUFBTSxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDbkIsQ0FBQztRQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7WUFDZCxNQUFNLENBQUMsS0FBSyxDQUFDLHlDQUF5QyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBQzdELE1BQU0sSUFBSSxLQUFLLENBQUMseUNBQXlDLENBQUMsQ0FBQztRQUM1RCxDQUFDO0lBQ0YsQ0FBQztDQUFBO0FBRUQscUNBQXFDO0FBQ3JDLFNBQWUsMEJBQTBCLENBQ3hDLEVBQVU7O1FBRVYsSUFBSSxNQUFNLEdBQUcsTUFBTSxXQUFXLEVBQUUsQ0FBQztRQUNqQyxJQUFJLE9BQU8sR0FBRyxNQUFNLG1CQUFtQixDQUFDLENBQUMsbUNBQW1DO1FBRTVFLElBQUksQ0FBQztZQUNKLElBQUksSUFBSSxHQUFHLE1BQU0sT0FBTyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLDJCQUEyQjtZQUNsRSxJQUFJLENBQUMsSUFBSTtnQkFBRSxNQUFNLElBQUksS0FBSyxDQUFDLGdCQUFnQixDQUFDLENBQUM7WUFFN0MsMEZBQTBGO1lBQzFGLElBQUksV0FBVyxHQUFHLElBQUksQ0FBQyxXQUE4QixDQUFDO1lBRXRELElBQUksV0FBVyxLQUFLLElBQUksRUFBRSxDQUFDO2dCQUMxQixPQUFPLFNBQVMsQ0FBQyxDQUFDLG1EQUFtRDtZQUN0RSxDQUFDO1lBRUQsbUNBQW1DO1lBQ25DLE9BQU8sV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQWUsQ0FBQyxDQUFDO1FBQ3pFLENBQUM7UUFBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO1lBQ2QsTUFBTSxDQUFDLEtBQUssQ0FBQyw2Q0FBNkMsRUFBRSxHQUFHLENBQUMsQ0FBQztZQUNqRSxNQUFNLElBQUksS0FBSyxDQUFDLCtDQUErQyxDQUFDLENBQUM7UUFDbEUsQ0FBQztJQUNGLENBQUM7Q0FBQTtBQUVELHNDQUFzQztBQUN0QyxTQUFlLDJCQUEyQixDQUN6QyxFQUFVLEVBQ1YsV0FBeUI7O1FBRXpCLElBQUksTUFBTSxHQUFHLE1BQU0sV0FBVyxFQUFFLENBQUM7UUFDakMsSUFBSSxPQUFPLEdBQUcsTUFBTSxtQkFBbUIsQ0FBQyxDQUFDLHNDQUFzQztRQUUvRSxJQUFJLENBQUM7WUFDSixJQUFJLElBQUksR0FBRyxNQUFNLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQywyQkFBMkI7WUFDbEUsSUFBSSxDQUFDLElBQUk7Z0JBQUUsTUFBTSxJQUFJLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1lBRTdDLDhEQUE4RDtZQUM5RCxJQUFJLG9CQUFvQixHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUV0RSxrREFBa0Q7WUFDbEQsSUFBSSxDQUFDLFdBQVcsR0FBRyxvQkFBb0IsQ0FBQztZQUN4QyxNQUFNLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUNuQixDQUFDO1FBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztZQUNkLE1BQU0sQ0FBQyxLQUFLLENBQUMsMkNBQTJDLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDL0QsTUFBTSxJQUFJLEtBQUssQ0FBQywyQ0FBMkMsQ0FBQyxDQUFDO1FBQzlELENBQUM7SUFDRixDQUFDO0NBQUE7QUFFRCxPQUFPLEVBQ04sbUJBQW1CLEVBQ25CLDBCQUEwQixFQUMxQix5QkFBeUIsRUFDekIsZ0JBQWdCLEVBQ2hCLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgYmNyeXB0IGZyb20gJ2JjcnlwdCc7XG5pbXBvcnQgY3J5cHRvIGZyb20gJ2NyeXB0byc7XG5pbXBvcnQgc2V0dXBMb2dnZXIgZnJvbSAnLi4vLi4vbWlkZGxld2FyZS9sb2dnZXInO1xuaW1wb3J0IFVzZXJNZmFNb2RlbFByb21pc2UgZnJvbSAnLi4vLi4vbW9kZWxzL1VzZXJNZmEnO1xuXG5pbnRlcmZhY2UgQmFja3VwQ29kZSB7XG5cdGNvZGU6IHN0cmluZztcblx0dXNlZDogYm9vbGVhbjtcbn1cblxuLy8gR2VuZXJhdGUgQmFja3VwIENvZWRlc1xuYXN5bmMgZnVuY3Rpb24gZ2VuZXJhdGVCYWNrdXBDb2RlcyhpZDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmdbXT4ge1xuXHRsZXQgYmFja3VwQ29kZXM6IEJhY2t1cENvZGVbXSA9IFtdO1xuXHRmb3IgKGxldCBpID0gMDsgaSA8IDE2OyBpKyspIHtcblx0XHRsZXQgY29kZSA9IGNyeXB0by5yYW5kb21CeXRlcyg0KS50b1N0cmluZygnaGV4Jyk7IC8vIDgtY2hhcmFjdGVyIGhleCBjb2RlXG5cdFx0bGV0IGhhc2hlZENvZGUgPSBhd2FpdCBiY3J5cHQuaGFzaChjb2RlLCAxMCk7XG5cdFx0YmFja3VwQ29kZXMucHVzaCh7IGNvZGU6IGhhc2hlZENvZGUsIHVzZWQ6IGZhbHNlIH0pO1xuXHR9XG5cblx0Ly8gc3RvcmUgYmFja3VwQ29kZXMgaW4gdGhlIGRhdGFiYXNlIGFzc29jaWF0ZWQgd2l0aCB0aGUgdXNlcidzIGlkXG5cdGF3YWl0IHNhdmVCYWNrdXBDb2Rlc1RvRGF0YWJhc2UoaWQsIGJhY2t1cENvZGVzKTtcblxuXHQvLyByZXR1cm4gb25seSB0aGUgcGxhaW4gY29kZXMgYXMgc3RyaW5nc1xuXHRyZXR1cm4gYmFja3VwQ29kZXMubWFwKChiYWNrdXBDb2RlKSA9PiBiYWNrdXBDb2RlLmNvZGUpO1xufVxuXG4vLyBWZXJpZnkgYSBCYWNrdXAgQ29kZVxuYXN5bmMgZnVuY3Rpb24gdmVyaWZ5QmFja3VwQ29kZShcblx0aWQ6IHN0cmluZyxcblx0aW5wdXRDb2RlOiBzdHJpbmdcbik6IFByb21pc2U8Ym9vbGVhbj4ge1xuXHRhd2FpdCBVc2VyTWZhTW9kZWxQcm9taXNlOyAvLyBhd2FpdCB0aGUgVXNlck1mYSBtb2RlbCB3aGVuIG5lZWRlZFxuXHRsZXQgc3RvcmVkQ29kZXMgPSBhd2FpdCBnZXRCYWNrdXBDb2Rlc0Zyb21EYXRhYmFzZShpZCk7XG5cblx0aWYgKHN0b3JlZENvZGVzKSB7XG5cdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCBzdG9yZWRDb2Rlcy5sZW5ndGg7IGkrKykge1xuXHRcdFx0bGV0IG1hdGNoID0gYXdhaXQgYmNyeXB0LmNvbXBhcmUoaW5wdXRDb2RlLCBzdG9yZWRDb2Rlc1tpXS5jb2RlKTtcblx0XHRcdGlmIChtYXRjaCAmJiAhc3RvcmVkQ29kZXNbaV0udXNlZCkge1xuXHRcdFx0XHRzdG9yZWRDb2Rlc1tpXS51c2VkID0gdHJ1ZTtcblx0XHRcdFx0YXdhaXQgdXBkYXRlQmFja3VwQ29kZXNJbkRhdGFiYXNlKGlkLCBzdG9yZWRDb2Rlcyk7IC8vIG1hcmsgdGhlIGNvZGUgYXMgdXNlZFxuXHRcdFx0XHRyZXR1cm4gdHJ1ZTsgLy8gc3VjY2Vzc2Z1bCB2ZXJpZmljYXRpb25cblx0XHRcdH1cblx0XHR9XG5cdH0gZWxzZSB7XG5cdFx0Y29uc29sZS5lcnJvcignTm8gYmFja3VwIGNvZGVzIGZvdW5kIGZvciB1c2VyJyk7XG5cdFx0cmV0dXJuIGZhbHNlOyAvLyBubyBiYWNrdXAgY29kZXMgZm91bmRcblx0fVxuXG5cdHJldHVybiBmYWxzZTsgLy8gdmVyaWZpY2F0aW9uIGZhaWxlZFxufVxuXG4vLyBTYXZlIGJhY2t1cCBjb2RlcyB0byB0aGUgZGF0YWJhc2VcbmFzeW5jIGZ1bmN0aW9uIHNhdmVCYWNrdXBDb2Rlc1RvRGF0YWJhc2UoXG5cdGlkOiBzdHJpbmcsXG5cdGJhY2t1cENvZGVzOiBCYWNrdXBDb2RlW11cbik6IFByb21pc2U8dm9pZD4ge1xuXHRsZXQgbG9nZ2VyID0gYXdhaXQgc2V0dXBMb2dnZXIoKTtcblx0bGV0IFVzZXJmTWZhID0gYXdhaXQgVXNlck1mYU1vZGVsUHJvbWlzZTsgLy8gYXdhaXQgdGhlIFVzZXJNZmEgbW9kZWwgd2hlbiBuZWVkZWRcblxuXHR0cnkge1xuXHRcdGxldCB1c2VyID0gYXdhaXQgVXNlcmZNZmEuZmluZEJ5UGsoaWQpOyAvLyBmaW5kIHVzZXIgYnkgcHJpbWFyeSBrZXlcblx0XHRpZiAoIXVzZXIpIHRocm93IG5ldyBFcnJvcignVXNlciBub3QgZm91bmQnKTtcblxuXHRcdC8vIG1hcCB0aGUgY29kZXMgZWxlbWVudCBvZiBiYWNrdXBDb2RlcyB0byBhbiBhcnJheSBvZiBzdHJpbmdzXG5cdFx0bGV0IGJhY2t1cENvZGVzQXNTdHJpbmdzID0gYmFja3VwQ29kZXMubWFwKChjb2RlT2JqKSA9PiBjb2RlT2JqLmNvZGUpO1xuXG5cdFx0Ly8gYXNzaWduIHRoZSBhcnJheSBvZiBzdHJpbmdzIHRvIHVzZXIuYmFja3VwQ29kZXNcblx0XHR1c2VyLmJhY2t1cENvZGVzID0gYmFja3VwQ29kZXNBc1N0cmluZ3M7XG5cdFx0YXdhaXQgdXNlci5zYXZlKCk7XG5cdH0gY2F0Y2ggKGVycikge1xuXHRcdGxvZ2dlci5lcnJvcignRXJyb3Igc2F2aW5nIGJhY2t1cCBjb2RlcyB0byBkYXRhYmFzZTogJywgZXJyKTtcblx0XHR0aHJvdyBuZXcgRXJyb3IoJ0ZhaWxlZCB0byBzYXZlIGJhY2t1cCBjb2RlcyB0byBkYXRhYmFzZScpO1xuXHR9XG59XG5cbi8vIEdldCBiYWNrdXAgY29kZXMgZnJvbSB0aGUgZGF0YWJhc2VcbmFzeW5jIGZ1bmN0aW9uIGdldEJhY2t1cENvZGVzRnJvbURhdGFiYXNlKFxuXHRpZDogc3RyaW5nXG4pOiBQcm9taXNlPEJhY2t1cENvZGVbXSB8IHVuZGVmaW5lZD4ge1xuXHRsZXQgbG9nZ2VyID0gYXdhaXQgc2V0dXBMb2dnZXIoKTtcblx0bGV0IFVzZXJNZmEgPSBhd2FpdCBVc2VyTWZhTW9kZWxQcm9taXNlOyAvLyBhd2FpdCB0aGUgVXNlciBtb2RlbCB3aGVuIG5lZWRlZFxuXG5cdHRyeSB7XG5cdFx0bGV0IHVzZXIgPSBhd2FpdCBVc2VyTWZhLmZpbmRCeVBrKGlkKTsgLy8gZmluZCB1c2VyIGJ5IHByaW1hcnkga2V5XG5cdFx0aWYgKCF1c2VyKSB0aHJvdyBuZXcgRXJyb3IoJ1VzZXIgbm90IGZvdW5kJyk7XG5cblx0XHQvLyBhc3N1bWUgdXNlci5iYWNrdXBDb2RlcyBpcyBhIHN0cmluZ1tdIG9yIG51bGwsIGNvbnZlcnQgaXQgdG8gQmFja3VvcENvZGVbXSBvciB1bmRlZmluZWRcblx0XHRsZXQgYmFja3VwQ29kZXMgPSB1c2VyLmJhY2t1cENvZGVzIGFzIHN0cmluZ1tdIHwgbnVsbDtcblxuXHRcdGlmIChiYWNrdXBDb2RlcyA9PT0gbnVsbCkge1xuXHRcdFx0cmV0dXJuIHVuZGVmaW5lZDsgLy8gKkRFVi1OT1RFKiBwcm9iYWJseSBuZWVkIHRvIGNvbmZpZ3VyZSB0aGlzIGxhdGVyXG5cdFx0fVxuXG5cdFx0Ly8gY29udmVydCBzdHJpbmdbXSB0byBCYWNrdXBDb2RlW11cblx0XHRyZXR1cm4gYmFja3VwQ29kZXMubWFwKChjb2RlKSA9PiAoeyBjb2RlLCB1c2VkOiBmYWxzZSB9KSBhcyBCYWNrdXBDb2RlKTtcblx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0bG9nZ2VyLmVycm9yKCdFcnJvciBmZXRjaGluZyBiYWNrdXAgY29kZXMgZnJvbSBkYXRhYmFzZTogJywgZXJyKTtcblx0XHR0aHJvdyBuZXcgRXJyb3IoJ0ZhaWxlZCB0byByZXRyaWV2ZSBiYWNrdXAgY29kZXMgZnJvbSBkYXRhYmFzZScpO1xuXHR9XG59XG5cbi8vIFVwZGF0ZSBiYWNrdXAgY29kZXMgaW4gdGhlIGRhdGFiYXNlXG5hc3luYyBmdW5jdGlvbiB1cGRhdGVCYWNrdXBDb2Rlc0luRGF0YWJhc2UoXG5cdGlkOiBzdHJpbmcsXG5cdGJhY2t1cENvZGVzOiBCYWNrdXBDb2RlW11cbik6IFByb21pc2U8dm9pZD4ge1xuXHRsZXQgbG9nZ2VyID0gYXdhaXQgc2V0dXBMb2dnZXIoKTtcblx0bGV0IFVzZXJNZmEgPSBhd2FpdCBVc2VyTWZhTW9kZWxQcm9taXNlOyAvLyBhd2FpdCB0aGUgVXNlck1mYSBtb2RlbCB3aGVuIG5lZWRlZFxuXG5cdHRyeSB7XG5cdFx0bGV0IHVzZXIgPSBhd2FpdCBVc2VyTWZhLmZpbmRCeVBrKGlkKTsgLy8gZmluZCB1c2VyIGJ5IHByaW1hcnkga2V5XG5cdFx0aWYgKCF1c2VyKSB0aHJvdyBuZXcgRXJyb3IoJ1VzZXIgbm90IGZvdW5kJyk7XG5cblx0XHQvLyBtYXAgdGhlIGNvZGVzIGVsZW1lbnQgb2YgYmFja3VwQ29kZXMgdG8gYW4gYXJyYXkgb2Ygc3RyaW5nc1xuXHRcdGxldCBiYWNrdXBDb2Rlc0FzU3RyaW5ncyA9IGJhY2t1cENvZGVzLm1hcCgoY29kZU9iaikgPT4gY29kZU9iai5jb2RlKTtcblxuXHRcdC8vIGFzc2lnbiB0aGUgYXJyYXkgb2Ygc3RyaW5ncyB0byB1c2VyLmJhY2t1cENvZGVzXG5cdFx0dXNlci5iYWNrdXBDb2RlcyA9IGJhY2t1cENvZGVzQXNTdHJpbmdzO1xuXHRcdGF3YWl0IHVzZXIuc2F2ZSgpO1xuXHR9IGNhdGNoIChlcnIpIHtcblx0XHRsb2dnZXIuZXJyb3IoJ0Vycm9yIHVwZGF0aW5nIGJhY2t1cCBjb2RlcyBpbiBkYXRhYmFzZTogJywgZXJyKTtcblx0XHR0aHJvdyBuZXcgRXJyb3IoJ0ZhaWxlZCB0byB1cGRhdGUgYmFja3VwIGNvZGVzIGluIGRhdGFiYXNlJyk7XG5cdH1cbn1cblxuZXhwb3J0IHtcblx0Z2VuZXJhdGVCYWNrdXBDb2Rlcyxcblx0Z2V0QmFja3VwQ29kZXNGcm9tRGF0YWJhc2UsXG5cdHNhdmVCYWNrdXBDb2Rlc1RvRGF0YWJhc2UsXG5cdHZlcmlmeUJhY2t1cENvZGVcbn07XG4iXX0=