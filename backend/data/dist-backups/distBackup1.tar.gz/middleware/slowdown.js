import '../../types/custom/express-session';
function slowdownMiddleware(req, res, next) {
    let requestTime = new Date().getTime();
    // Check if we already stored a request time for this IP
    if (!req.session.lastRequestTime) {
        req.session.lastRequestTime = requestTime;
        next();
    }
    else {
        let timeDiff = requestTime - req.session.lastRequestTime;
        let slowdownThreshold = 100; // *DEV-NOTE* Adjust this value as needed (in ms)
        if (timeDiff < slowdownThreshold) {
            let waitTime = slowdownThreshold - timeDiff;
            setTimeout(next, waitTime);
        }
        else {
            req.session.lastRequestTime = requestTime;
            next();
        }
    }
}
export default slowdownMiddleware;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2xvd2Rvd24uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvbWlkZGxld2FyZS9zbG93ZG93bi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQSxPQUFPLG9DQUFvQyxDQUFDO0FBRTVDLFNBQVMsa0JBQWtCLENBQUMsR0FBWSxFQUFFLEdBQWEsRUFBRSxJQUFrQjtJQUMxRSxJQUFJLFdBQVcsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDLE9BQU8sRUFBRSxDQUFDO0lBRXZDLHdEQUF3RDtJQUN4RCxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxlQUFlLEVBQUUsQ0FBQztRQUNsQyxHQUFHLENBQUMsT0FBTyxDQUFDLGVBQWUsR0FBRyxXQUFXLENBQUM7UUFDMUMsSUFBSSxFQUFFLENBQUM7SUFDUixDQUFDO1NBQU0sQ0FBQztRQUNQLElBQUksUUFBUSxHQUFHLFdBQVcsR0FBRyxHQUFHLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQztRQUN6RCxJQUFJLGlCQUFpQixHQUFHLEdBQUcsQ0FBQyxDQUFDLGlEQUFpRDtRQUU5RSxJQUFJLFFBQVEsR0FBRyxpQkFBaUIsRUFBRSxDQUFDO1lBQ2xDLElBQUksUUFBUSxHQUFHLGlCQUFpQixHQUFHLFFBQVEsQ0FBQztZQUM1QyxVQUFVLENBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1FBQzVCLENBQUM7YUFBTSxDQUFDO1lBQ1AsR0FBRyxDQUFDLE9BQU8sQ0FBQyxlQUFlLEdBQUcsV0FBVyxDQUFDO1lBQzFDLElBQUksRUFBRSxDQUFDO1FBQ1IsQ0FBQztJQUNGLENBQUM7QUFDRixDQUFDO0FBRUQsZUFBZSxrQkFBa0IsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE5leHRGdW5jdGlvbiwgUmVxdWVzdCwgUmVzcG9uc2UgfSBmcm9tICdleHByZXNzJztcbmltcG9ydCAnLi4vLi4vdHlwZXMvY3VzdG9tL2V4cHJlc3Mtc2Vzc2lvbic7XG5cbmZ1bmN0aW9uIHNsb3dkb3duTWlkZGxld2FyZShyZXE6IFJlcXVlc3QsIHJlczogUmVzcG9uc2UsIG5leHQ6IE5leHRGdW5jdGlvbikge1xuXHRsZXQgcmVxdWVzdFRpbWUgPSBuZXcgRGF0ZSgpLmdldFRpbWUoKTtcblxuXHQvLyBDaGVjayBpZiB3ZSBhbHJlYWR5IHN0b3JlZCBhIHJlcXVlc3QgdGltZSBmb3IgdGhpcyBJUFxuXHRpZiAoIXJlcS5zZXNzaW9uLmxhc3RSZXF1ZXN0VGltZSkge1xuXHRcdHJlcS5zZXNzaW9uLmxhc3RSZXF1ZXN0VGltZSA9IHJlcXVlc3RUaW1lO1xuXHRcdG5leHQoKTtcblx0fSBlbHNlIHtcblx0XHRsZXQgdGltZURpZmYgPSByZXF1ZXN0VGltZSAtIHJlcS5zZXNzaW9uLmxhc3RSZXF1ZXN0VGltZTtcblx0XHRsZXQgc2xvd2Rvd25UaHJlc2hvbGQgPSAxMDA7IC8vICpERVYtTk9URSogQWRqdXN0IHRoaXMgdmFsdWUgYXMgbmVlZGVkIChpbiBtcylcblxuXHRcdGlmICh0aW1lRGlmZiA8IHNsb3dkb3duVGhyZXNob2xkKSB7XG5cdFx0XHRsZXQgd2FpdFRpbWUgPSBzbG93ZG93blRocmVzaG9sZCAtIHRpbWVEaWZmO1xuXHRcdFx0c2V0VGltZW91dChuZXh0LCB3YWl0VGltZSk7XG5cdFx0fSBlbHNlIHtcblx0XHRcdHJlcS5zZXNzaW9uLmxhc3RSZXF1ZXN0VGltZSA9IHJlcXVlc3RUaW1lO1xuXHRcdFx0bmV4dCgpO1xuXHRcdH1cblx0fVxufVxuXG5leHBvcnQgZGVmYXVsdCBzbG93ZG93bk1pZGRsZXdhcmU7XG4iXX0=