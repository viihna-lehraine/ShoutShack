import { __awaiter } from "tslib";
import pkg from 'winston';
import DailyRotateFile from 'winston-daily-rotate-file';
import loadEnv from '../config/loadEnv.js';
const { createLogger, format, transports } = pkg;
const { combine, timestamp, printf, colorize, errors, json } = format;
let logFormat = printf(({ level, message, timestamp, stack }) => {
    return `${timestamp}, ${level}: ${stack || message}`;
});
function setupLogger() {
    return __awaiter(this, void 0, void 0, function* () {
        loadEnv();
        let logger = createLogger({
            level: process.env.NODE_ENV === 'production' ? 'info' : 'debug',
            format: combine(timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }), errors({ stack: true }), json()),
            defaultMeta: { service: 'guestbook-service' },
            transports: [
                new transports.Console({
                    format: combine(colorize(), logFormat)
                }),
                new DailyRotateFile({
                    filename: './logs/server/error-%DATE%.log',
                    dirname: './logs/server',
                    datePattern: 'YYYY-MM-DD',
                    zippedArchive: true,
                    maxSize: '20m',
                    maxFiles: '14d',
                    format: logFormat
                })
            ]
        });
        return logger;
    });
}
export default setupLogger;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9nZ2VyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL21pZGRsZXdhcmUvbG9nZ2VyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxPQUFPLEdBQUcsTUFBTSxTQUFTLENBQUM7QUFDMUIsT0FBTyxlQUFlLE1BQU0sMkJBQTJCLENBQUM7QUFDeEQsT0FBTyxPQUFPLE1BQU0sbUJBQW1CLENBQUM7QUFFeEMsTUFBTSxFQUFFLFlBQVksRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFFLEdBQUcsR0FBRyxDQUFDO0FBQ2pELE1BQU0sRUFBRSxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxHQUFHLE1BQU0sQ0FBQztBQUV0RSxJQUFJLFNBQVMsR0FBRyxNQUFNLENBQUMsQ0FBQyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUU7SUFDL0QsT0FBTyxHQUFHLFNBQVMsS0FBSyxLQUFLLEtBQUssS0FBSyxJQUFJLE9BQU8sRUFBRSxDQUFDO0FBQ3RELENBQUMsQ0FBQyxDQUFDO0FBRUgsU0FBZSxXQUFXOztRQUN6QixPQUFPLEVBQUUsQ0FBQztRQUVWLElBQUksTUFBTSxHQUFHLFlBQVksQ0FBQztZQUN6QixLQUFLLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLEtBQUssWUFBWSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU87WUFDL0QsTUFBTSxFQUFFLE9BQU8sQ0FDZCxTQUFTLENBQUMsRUFBRSxNQUFNLEVBQUUscUJBQXFCLEVBQUUsQ0FBQyxFQUM1QyxNQUFNLENBQUMsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFDdkIsSUFBSSxFQUFFLENBQ047WUFDRCxXQUFXLEVBQUUsRUFBRSxPQUFPLEVBQUUsbUJBQW1CLEVBQUU7WUFDN0MsVUFBVSxFQUFFO2dCQUNYLElBQUksVUFBVSxDQUFDLE9BQU8sQ0FBQztvQkFDdEIsTUFBTSxFQUFFLE9BQU8sQ0FBQyxRQUFRLEVBQUUsRUFBRSxTQUFTLENBQUM7aUJBQ3RDLENBQUM7Z0JBQ0YsSUFBSSxlQUFlLENBQUM7b0JBQ25CLFFBQVEsRUFBRSxnQ0FBZ0M7b0JBQzFDLE9BQU8sRUFBRSxlQUFlO29CQUN4QixXQUFXLEVBQUUsWUFBWTtvQkFDekIsYUFBYSxFQUFFLElBQUk7b0JBQ25CLE9BQU8sRUFBRSxLQUFLO29CQUNkLFFBQVEsRUFBRSxLQUFLO29CQUNmLE1BQU0sRUFBRSxTQUFTO2lCQUNqQixDQUFDO2FBQ0Y7U0FDRCxDQUFDLENBQUM7UUFFSCxPQUFPLE1BQU0sQ0FBQztJQUNmLENBQUM7Q0FBQTtBQUVELGVBQWUsV0FBVyxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHBrZyBmcm9tICd3aW5zdG9uJztcbmltcG9ydCBEYWlseVJvdGF0ZUZpbGUgZnJvbSAnd2luc3Rvbi1kYWlseS1yb3RhdGUtZmlsZSc7XG5pbXBvcnQgbG9hZEVudiBmcm9tICcuLi9jb25maWcvbG9hZEVudic7XG5cbmNvbnN0IHsgY3JlYXRlTG9nZ2VyLCBmb3JtYXQsIHRyYW5zcG9ydHMgfSA9IHBrZztcbmNvbnN0IHsgY29tYmluZSwgdGltZXN0YW1wLCBwcmludGYsIGNvbG9yaXplLCBlcnJvcnMsIGpzb24gfSA9IGZvcm1hdDtcblxubGV0IGxvZ0Zvcm1hdCA9IHByaW50ZigoeyBsZXZlbCwgbWVzc2FnZSwgdGltZXN0YW1wLCBzdGFjayB9KSA9PiB7XG5cdHJldHVybiBgJHt0aW1lc3RhbXB9LCAke2xldmVsfTogJHtzdGFjayB8fCBtZXNzYWdlfWA7XG59KTtcblxuYXN5bmMgZnVuY3Rpb24gc2V0dXBMb2dnZXIoKSB7XG5cdGxvYWRFbnYoKTtcblxuXHRsZXQgbG9nZ2VyID0gY3JlYXRlTG9nZ2VyKHtcblx0XHRsZXZlbDogcHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09ICdwcm9kdWN0aW9uJyA/ICdpbmZvJyA6ICdkZWJ1ZycsXG5cdFx0Zm9ybWF0OiBjb21iaW5lKFxuXHRcdFx0dGltZXN0YW1wKHsgZm9ybWF0OiAnWVlZWS1NTS1ERCBISDptbTpzcycgfSksXG5cdFx0XHRlcnJvcnMoeyBzdGFjazogdHJ1ZSB9KSxcblx0XHRcdGpzb24oKVxuXHRcdCksXG5cdFx0ZGVmYXVsdE1ldGE6IHsgc2VydmljZTogJ2d1ZXN0Ym9vay1zZXJ2aWNlJyB9LFxuXHRcdHRyYW5zcG9ydHM6IFtcblx0XHRcdG5ldyB0cmFuc3BvcnRzLkNvbnNvbGUoe1xuXHRcdFx0XHRmb3JtYXQ6IGNvbWJpbmUoY29sb3JpemUoKSwgbG9nRm9ybWF0KVxuXHRcdFx0fSksXG5cdFx0XHRuZXcgRGFpbHlSb3RhdGVGaWxlKHtcblx0XHRcdFx0ZmlsZW5hbWU6ICcuL2xvZ3Mvc2VydmVyL2Vycm9yLSVEQVRFJS5sb2cnLFxuXHRcdFx0XHRkaXJuYW1lOiAnLi9sb2dzL3NlcnZlcicsXG5cdFx0XHRcdGRhdGVQYXR0ZXJuOiAnWVlZWS1NTS1ERCcsXG5cdFx0XHRcdHppcHBlZEFyY2hpdmU6IHRydWUsXG5cdFx0XHRcdG1heFNpemU6ICcyMG0nLFxuXHRcdFx0XHRtYXhGaWxlczogJzE0ZCcsXG5cdFx0XHRcdGZvcm1hdDogbG9nRm9ybWF0XG5cdFx0XHR9KVxuXHRcdF1cblx0fSk7XG5cblx0cmV0dXJuIGxvZ2dlcjtcbn1cblxuZXhwb3J0IGRlZmF1bHQgc2V0dXBMb2dnZXI7XG4iXX0=