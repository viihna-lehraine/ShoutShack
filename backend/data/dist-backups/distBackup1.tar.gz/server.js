import { __awaiter } from "tslib";
import passport from 'passport';
import loadEnv from './config/loadEnv.js';
import { initializeDatabase, configurePassport, initializeIpBlacklist, setupHttp } from './index.js';
import { app, initializeApp } from './config/app.js';
import featureFlags from './config/featureFlags.js';
import { getSequelizeInstance } from './config/db.js';
import { initializeModels } from './models/ModelsIndex.js';
loadEnv();
function initializeServer() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            // Initialize the database
            console.log('Initializing database');
            yield initializeDatabase();
            // Initialize all models
            console.log('Initializing models');
            initializeModels();
            // Configure Passport for authentication]
            console.log('Initializing passport');
            yield configurePassport(passport);
            // Initialize IP blacklist
            console.log('Initializing IP blacklist');
            yield initializeIpBlacklist();
            // Initialize the Express application with all middlewares and routes
            console.log('Initializing app');
            yield initializeApp();
            // Sync Datababase Connection and Models, dependent on flag value
            console.log('DB Sync Flag: ', featureFlags.dbSyncFlag, typeof featureFlags.dbSyncFlag);
            if (featureFlags.dbSyncFlag) {
                // Test the database connection and sync models
                console.log('Testing database connection and syncing models using getSequelizeInstance');
                let sequelize = getSequelizeInstance();
                try {
                    yield sequelize.sync(); // if sync isnt working, try adding { force: true }	for one round then removing again
                    console.info('Database and tables created!');
                }
                catch (err) {
                    console.error('Database Connection Test and Sync: Server error:', err);
                    throw err;
                }
            }
            // Start Web Server
            console.log('Starting server');
            setupHttp(app);
            console.info('Server started successfully!');
        }
        catch (err) {
            console.error('Failed to start server:', err);
            process.exit(1); // exit process with failure
        }
    });
}
initializeServer().catch((err) => {
    console.error('Unhandled error during server initialization:', err);
    process.exit(1); // exit process with failure
});
export default app;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vc3JjL3NlcnZlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxRQUFRLE1BQU0sVUFBVSxDQUFDO0FBQ2hDLE9BQU8sT0FBTyxNQUFNLGtCQUFrQixDQUFDO0FBQ3ZDLE9BQU8sRUFDTixrQkFBa0IsRUFDbEIsaUJBQWlCLEVBQ2pCLHFCQUFxQixFQUNyQixTQUFTLEVBQ1QsTUFBTSxTQUFTLENBQUM7QUFDakIsT0FBTyxFQUFFLEdBQUcsRUFBRSxhQUFhLEVBQUUsTUFBTSxjQUFjLENBQUM7QUFDbEQsT0FBTyxZQUFZLE1BQU0sdUJBQXVCLENBQUM7QUFDakQsT0FBTyxFQUFFLG9CQUFvQixFQUFFLE1BQU0sYUFBYSxDQUFDO0FBQ25ELE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLHNCQUFzQixDQUFDO0FBRXhELE9BQU8sRUFBRSxDQUFDO0FBRVYsU0FBZSxnQkFBZ0I7O1FBQzlCLElBQUksQ0FBQztZQUNKLDBCQUEwQjtZQUMxQixPQUFPLENBQUMsR0FBRyxDQUFDLHVCQUF1QixDQUFDLENBQUM7WUFDckMsTUFBTSxrQkFBa0IsRUFBRSxDQUFDO1lBRTNCLHdCQUF3QjtZQUN4QixPQUFPLENBQUMsR0FBRyxDQUFDLHFCQUFxQixDQUFDLENBQUM7WUFDbkMsZ0JBQWdCLEVBQUUsQ0FBQztZQUVuQix5Q0FBeUM7WUFDekMsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1lBQ3JDLE1BQU0saUJBQWlCLENBQUMsUUFBUSxDQUFDLENBQUM7WUFFbEMsMEJBQTBCO1lBQzFCLE9BQU8sQ0FBQyxHQUFHLENBQUMsMkJBQTJCLENBQUMsQ0FBQztZQUN6QyxNQUFNLHFCQUFxQixFQUFFLENBQUM7WUFFOUIscUVBQXFFO1lBQ3JFLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsQ0FBQztZQUNoQyxNQUFNLGFBQWEsRUFBRSxDQUFDO1lBRXRCLGlFQUFpRTtZQUNqRSxPQUFPLENBQUMsR0FBRyxDQUNWLGdCQUFnQixFQUNoQixZQUFZLENBQUMsVUFBVSxFQUN2QixPQUFPLFlBQVksQ0FBQyxVQUFVLENBQzlCLENBQUM7WUFFRixJQUFJLFlBQVksQ0FBQyxVQUFVLEVBQUUsQ0FBQztnQkFDN0IsK0NBQStDO2dCQUMvQyxPQUFPLENBQUMsR0FBRyxDQUNWLDJFQUEyRSxDQUMzRSxDQUFDO2dCQUNGLElBQUksU0FBUyxHQUFHLG9CQUFvQixFQUFFLENBQUM7Z0JBQ3ZDLElBQUksQ0FBQztvQkFDSixNQUFNLFNBQVMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLHFGQUFxRjtvQkFDN0csT0FBTyxDQUFDLElBQUksQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO2dCQUM5QyxDQUFDO2dCQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7b0JBQ2QsT0FBTyxDQUFDLEtBQUssQ0FDWixrREFBa0QsRUFDbEQsR0FBRyxDQUNILENBQUM7b0JBQ0YsTUFBTSxHQUFHLENBQUM7Z0JBQ1gsQ0FBQztZQUNGLENBQUM7WUFFRCxtQkFBbUI7WUFDbkIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1lBQy9CLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNmLE9BQU8sQ0FBQyxJQUFJLENBQUMsOEJBQThCLENBQUMsQ0FBQztRQUM5QyxDQUFDO1FBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztZQUNkLE9BQU8sQ0FBQyxLQUFLLENBQUMseUJBQXlCLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDOUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLDRCQUE0QjtRQUM5QyxDQUFDO0lBQ0YsQ0FBQztDQUFBO0FBRUQsZ0JBQWdCLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLEVBQUUsRUFBRTtJQUNoQyxPQUFPLENBQUMsS0FBSyxDQUFDLCtDQUErQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ3BFLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyw0QkFBNEI7QUFDOUMsQ0FBQyxDQUFDLENBQUM7QUFFSCxlQUFlLEdBQUcsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBwYXNzcG9ydCBmcm9tICdwYXNzcG9ydCc7XG5pbXBvcnQgbG9hZEVudiBmcm9tICcuL2NvbmZpZy9sb2FkRW52JztcbmltcG9ydCB7XG5cdGluaXRpYWxpemVEYXRhYmFzZSxcblx0Y29uZmlndXJlUGFzc3BvcnQsXG5cdGluaXRpYWxpemVJcEJsYWNrbGlzdCxcblx0c2V0dXBIdHRwXG59IGZyb20gJy4vaW5kZXgnO1xuaW1wb3J0IHsgYXBwLCBpbml0aWFsaXplQXBwIH0gZnJvbSAnLi9jb25maWcvYXBwJztcbmltcG9ydCBmZWF0dXJlRmxhZ3MgZnJvbSAnLi9jb25maWcvZmVhdHVyZUZsYWdzJztcbmltcG9ydCB7IGdldFNlcXVlbGl6ZUluc3RhbmNlIH0gZnJvbSAnLi9jb25maWcvZGInO1xuaW1wb3J0IHsgaW5pdGlhbGl6ZU1vZGVscyB9IGZyb20gJy4vbW9kZWxzL01vZGVsc0luZGV4JztcblxubG9hZEVudigpO1xuXG5hc3luYyBmdW5jdGlvbiBpbml0aWFsaXplU2VydmVyKCk6IFByb21pc2U8dm9pZD4ge1xuXHR0cnkge1xuXHRcdC8vIEluaXRpYWxpemUgdGhlIGRhdGFiYXNlXG5cdFx0Y29uc29sZS5sb2coJ0luaXRpYWxpemluZyBkYXRhYmFzZScpO1xuXHRcdGF3YWl0IGluaXRpYWxpemVEYXRhYmFzZSgpO1xuXG5cdFx0Ly8gSW5pdGlhbGl6ZSBhbGwgbW9kZWxzXG5cdFx0Y29uc29sZS5sb2coJ0luaXRpYWxpemluZyBtb2RlbHMnKTtcblx0XHRpbml0aWFsaXplTW9kZWxzKCk7XG5cblx0XHQvLyBDb25maWd1cmUgUGFzc3BvcnQgZm9yIGF1dGhlbnRpY2F0aW9uXVxuXHRcdGNvbnNvbGUubG9nKCdJbml0aWFsaXppbmcgcGFzc3BvcnQnKTtcblx0XHRhd2FpdCBjb25maWd1cmVQYXNzcG9ydChwYXNzcG9ydCk7XG5cblx0XHQvLyBJbml0aWFsaXplIElQIGJsYWNrbGlzdFxuXHRcdGNvbnNvbGUubG9nKCdJbml0aWFsaXppbmcgSVAgYmxhY2tsaXN0Jyk7XG5cdFx0YXdhaXQgaW5pdGlhbGl6ZUlwQmxhY2tsaXN0KCk7XG5cblx0XHQvLyBJbml0aWFsaXplIHRoZSBFeHByZXNzIGFwcGxpY2F0aW9uIHdpdGggYWxsIG1pZGRsZXdhcmVzIGFuZCByb3V0ZXNcblx0XHRjb25zb2xlLmxvZygnSW5pdGlhbGl6aW5nIGFwcCcpO1xuXHRcdGF3YWl0IGluaXRpYWxpemVBcHAoKTtcblxuXHRcdC8vIFN5bmMgRGF0YWJhYmFzZSBDb25uZWN0aW9uIGFuZCBNb2RlbHMsIGRlcGVuZGVudCBvbiBmbGFnIHZhbHVlXG5cdFx0Y29uc29sZS5sb2coXG5cdFx0XHQnREIgU3luYyBGbGFnOiAnLFxuXHRcdFx0ZmVhdHVyZUZsYWdzLmRiU3luY0ZsYWcsXG5cdFx0XHR0eXBlb2YgZmVhdHVyZUZsYWdzLmRiU3luY0ZsYWdcblx0XHQpO1xuXG5cdFx0aWYgKGZlYXR1cmVGbGFncy5kYlN5bmNGbGFnKSB7XG5cdFx0XHQvLyBUZXN0IHRoZSBkYXRhYmFzZSBjb25uZWN0aW9uIGFuZCBzeW5jIG1vZGVsc1xuXHRcdFx0Y29uc29sZS5sb2coXG5cdFx0XHRcdCdUZXN0aW5nIGRhdGFiYXNlIGNvbm5lY3Rpb24gYW5kIHN5bmNpbmcgbW9kZWxzIHVzaW5nIGdldFNlcXVlbGl6ZUluc3RhbmNlJ1xuXHRcdFx0KTtcblx0XHRcdGxldCBzZXF1ZWxpemUgPSBnZXRTZXF1ZWxpemVJbnN0YW5jZSgpO1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YXdhaXQgc2VxdWVsaXplLnN5bmMoKTsgLy8gaWYgc3luYyBpc250IHdvcmtpbmcsIHRyeSBhZGRpbmcgeyBmb3JjZTogdHJ1ZSB9XHRmb3Igb25lIHJvdW5kIHRoZW4gcmVtb3ZpbmcgYWdhaW5cblx0XHRcdFx0Y29uc29sZS5pbmZvKCdEYXRhYmFzZSBhbmQgdGFibGVzIGNyZWF0ZWQhJyk7XG5cdFx0XHR9IGNhdGNoIChlcnIpIHtcblx0XHRcdFx0Y29uc29sZS5lcnJvcihcblx0XHRcdFx0XHQnRGF0YWJhc2UgQ29ubmVjdGlvbiBUZXN0IGFuZCBTeW5jOiBTZXJ2ZXIgZXJyb3I6Jyxcblx0XHRcdFx0XHRlcnJcblx0XHRcdFx0KTtcblx0XHRcdFx0dGhyb3cgZXJyO1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdC8vIFN0YXJ0IFdlYiBTZXJ2ZXJcblx0XHRjb25zb2xlLmxvZygnU3RhcnRpbmcgc2VydmVyJyk7XG5cdFx0c2V0dXBIdHRwKGFwcCk7XG5cdFx0Y29uc29sZS5pbmZvKCdTZXJ2ZXIgc3RhcnRlZCBzdWNjZXNzZnVsbHkhJyk7XG5cdH0gY2F0Y2ggKGVycikge1xuXHRcdGNvbnNvbGUuZXJyb3IoJ0ZhaWxlZCB0byBzdGFydCBzZXJ2ZXI6JywgZXJyKTtcblx0XHRwcm9jZXNzLmV4aXQoMSk7IC8vIGV4aXQgcHJvY2VzcyB3aXRoIGZhaWx1cmVcblx0fVxufVxuXG5pbml0aWFsaXplU2VydmVyKCkuY2F0Y2goKGVycikgPT4ge1xuXHRjb25zb2xlLmVycm9yKCdVbmhhbmRsZWQgZXJyb3IgZHVyaW5nIHNlcnZlciBpbml0aWFsaXphdGlvbjonLCBlcnIpO1xuXHRwcm9jZXNzLmV4aXQoMSk7IC8vIGV4aXQgcHJvY2VzcyB3aXRoIGZhaWx1cmVcbn0pO1xuXG5leHBvcnQgZGVmYXVsdCBhcHA7XG4iXX0=