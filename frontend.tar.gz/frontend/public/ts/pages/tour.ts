export function initializeTourPage(): void {
	document.addEventListener('DOMContentLoaded', function (): void {
			
	});
}