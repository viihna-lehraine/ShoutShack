export function initializeResourcesPage(): void {
	document.addEventListener('DOMContentLoaded', function (): void {
			
	});
}