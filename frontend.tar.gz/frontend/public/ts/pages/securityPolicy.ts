export function initializeSecurityPolicyPage(): void {
	document.addEventListener('DOMContentLoaded', function (): void {
			
	});
}