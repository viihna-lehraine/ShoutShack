export function initializeIndexPage(): void {
	document.addEventListener('DOMContentLoaded', function (): void {
			
	});
}