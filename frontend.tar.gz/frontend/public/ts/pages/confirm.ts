export function initializeConfirmPage(): void {
	document.addEventListener('DOMContentLoaded', function (): void {
			
	});
}