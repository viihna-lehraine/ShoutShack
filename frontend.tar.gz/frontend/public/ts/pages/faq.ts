export function initializeFaqPage(): void {
	document.addEventListener('DOMContentLoaded', function (): void {
			
	});
}