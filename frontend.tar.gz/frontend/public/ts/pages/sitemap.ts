export function initializeSitemapPage(): void {
	document.addEventListener('DOMContentLoaded', function (): void {
			
	});
}