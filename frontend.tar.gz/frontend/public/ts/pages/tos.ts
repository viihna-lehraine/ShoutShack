export function initializeTosPage(): void {
	document.addEventListener('DOMContentLoaded', function (): void {
			
	});
}