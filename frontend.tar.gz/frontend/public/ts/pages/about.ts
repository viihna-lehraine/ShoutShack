export function initializeAboutPage(): void {
	document.addEventListener('DOMContentLoaded', function (): void {
			
	});
}