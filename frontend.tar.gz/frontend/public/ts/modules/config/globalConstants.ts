export const globalConstants: {
    PORT: number;
} = {
    PORT: 3000
};
