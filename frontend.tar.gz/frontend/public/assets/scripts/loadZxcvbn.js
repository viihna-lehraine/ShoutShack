import zxcvbn from 'https://cdn.jsdelivr.net/npm/zxcvbn@4.4.2/dist/zxcvbn.js';

window.zxcvbn = zxcvbn;
