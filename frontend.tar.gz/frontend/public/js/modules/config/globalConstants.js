export const globalConstants = {
    PORT: 3000
};
