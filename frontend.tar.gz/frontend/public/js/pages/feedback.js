export function initializeFeedbackPage() {
    document.addEventListener('DOMContentLoaded', function () {
    });
}
