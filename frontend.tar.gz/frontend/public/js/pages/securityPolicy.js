export function initializeSecurityPolicyPage() {
    document.addEventListener('DOMContentLoaded', function () {
    });
}
