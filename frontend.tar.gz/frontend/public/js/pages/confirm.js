export function initializeConfirmPage() {
    document.addEventListener('DOMContentLoaded', function () {
    });
}
