export function initializeFeatureRequestPage() {
    document.addEventListener('DOMContentLoaded', function () {
    });
}
