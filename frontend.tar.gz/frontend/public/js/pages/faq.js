export function initializeFaqPage() {
    document.addEventListener('DOMContentLoaded', function () {
    });
}
