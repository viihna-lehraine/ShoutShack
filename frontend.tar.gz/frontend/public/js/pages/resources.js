export function initializeResourcesPage() {
    document.addEventListener('DOMContentLoaded', function () {
    });
}
