export function initializeHelpPage() {
    document.addEventListener('DOMContentLoaded', function () {
    });
}
