export function initializeTosPage() {
    document.addEventListener('DOMContentLoaded', function () {
    });
}
