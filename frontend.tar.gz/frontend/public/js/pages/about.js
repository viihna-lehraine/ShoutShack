export function initializeAboutPage() {
    document.addEventListener('DOMContentLoaded', function () {
    });
}
