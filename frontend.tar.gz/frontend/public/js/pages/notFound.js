export function initializeNotFoundPage() {
    document.addEventListener('DOMContentLoaded', function () {
    });
}
