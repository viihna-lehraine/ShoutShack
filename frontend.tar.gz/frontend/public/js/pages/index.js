export function initializeIndexPage() {
    document.addEventListener('DOMContentLoaded', function () {
    });
}
