export function initializeSitemapPage() {
    document.addEventListener('DOMContentLoaded', function () {
    });
}
