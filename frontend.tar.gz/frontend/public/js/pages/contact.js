export function initializeContactPage() {
    document.addEventListener('DOMContentLoaded', function () {
    });
}
