export function initializePrivacyPolicyPage() {
    document.addEventListener('DOMContentLoaded', function () {
    });
}
