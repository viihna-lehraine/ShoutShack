export function initializeTourPage() {
    document.addEventListener('DOMContentLoaded', function () {
    });
}
